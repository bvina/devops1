#### KYV-000
<!--- Include the title, content and/or URL to relevant Jira ticket(s) -->
[Link](https://rbcjira.fg.rbc.com/browse/KYV-000)

#### Description
<!--- Provide a brief description the change below, including rationale and design decisions -->

<!--- Is this PR modifying global, regional, subscription or cluster level configurations? -->

#### Test Results
<!--- If no automated tests were ran, what did you do to ensure your changes work? ie. "ran this ARM template deployment - here's the link https://portal.azure.com..." -->

<!-- Include any relevant logs or screenshots here -->
```bash
$ 
```

#### Checklist

- [ ] 1. The acceptance criteria for all associated issues have been completed, tested, and validated.
- [ ] 2. Tests either have been created / updated or are not required. Include manual testing.
- [ ] 3. The README and other relevant documentation either reflects my changes or does not require updates.
- [ ] 4. Jira ticket has been tagged with reviewers and is in `Pending Validation`

cc @AEO0/kyvos
