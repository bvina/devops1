#!/usr/bin/env bash
# Create Application Registration and Service Principals for the integration to AAD for AKS
# The principals are named after the APP Code and Service Tier.
# Create the Azure AD application
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will create app registrations for AKS AAD Integration

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@

aksname="${APPCODE}_${short_tier[${ENVIRONMENT}]^^}_AKS_AAD_"

einfo "Creating application registration for Server Component ${aksname}Server"
serverApplicationId=$(az ad app create \
    --display-name "${aksname}Server" \
    --identifier-uris "https://${aksname}Server" \
    --query appId -o tsv)
edumpvar serverApplicationId

einfo "Update the application group memebership claims"
az ad app update --id $serverApplicationId --set groupMembershipClaims=All

einfo "Create a service principal for the Azure AD Server application"
az ad sp create --id $serverApplicationId

einfo "Get the service principal secret"
serverApplicationSecret=$(az ad sp credential reset \
    --name $serverApplicationId \
    --credential-description "AKSPassword" \
    --query password -o tsv)

# Add permissions for the Azure AD app to read directory data, sign in and read
# user profile, and read directory data
einfo "Add Permissions (ead directory data, sign in and readuser profile, and read directory data"
az ad app permission add \
    --id $serverApplicationId \
    --api 00000003-0000-0000-c000-000000000000 \
    --api-permissions e1fe6dd8-ba31-4d61-89e7-88639da4683d=Scope 06da0dbc-49e2-44d2-8312-53f166ab848a=Scope 7ab1d382-f21e-4acd-a863-ba3e13f7da61=Role

# Grant permissions for the permissions assigned in the previous step
# You must be the Azure AD tenant admin for these steps to successfully complete
einfo "Grant permissions and consent on behalf of the SPN - Elevated Access in AAD required to perform"
az ad app permission grant --id $serverApplicationId --api 00000003-0000-0000-c000-000000000000
az ad app permission admin-consent --id  $serverApplicationId

einfo "Create the Azure AD client application ${aksname}Client"
clientApplicationId=$(az ad app create --display-name "${aksname}Client" --native-app --reply-urls "https://${aksname}Client" --query appId -o tsv)

einfo "Create a service principal for the client application"
az ad sp create --id $clientApplicationId

einfo "Get the oAuth2 ID for the server app to allow authentication flow"
oAuthPermissionId=$(az ad app show --id $serverApplicationId --query "oauth2Permissions[0].id" -o tsv)

einfo "Assign permissions for the client and server applications to communicate with each other"
az ad app permission add   --id $clientApplicationId --api $serverApplicationId --api-permissions $oAuthPermissionId=Scope
az ad app permission grant --id $clientApplicationId --api $serverApplicationId

einfo "Settings for Cluster Creation:"
einfo "Client AppId: ${clientApplicationId}"
einfo "Server AppId: ${serverApplicationId}"
einfo "Server Secret: ${serverApplicationSecret}"
