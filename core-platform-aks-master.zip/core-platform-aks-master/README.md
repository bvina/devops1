# Overview
Repository contains the configuration and deployment scripts to:
* Deploy AKS clusters
* Deploy namespaces

## Prerequisites
- Bash command line access
- Python 3.7.2
- CLI
- git
- jq

A single cluster is deployed using the scripts herein. For multi-cluster deployments, run the script multiple times with different configurations. This provides flexibility if we need to have one cluster per subscription and stay within subscription limits (most are soft).

This deployment performs the following:
* Register required resource providers and preview features
* Azure Firewall (per region)
* Resource Group
* Virtual Network
* AKS Cluster & Configuration

Features enabled on the AKS cluster:
* AAD Integration for RBAC
* Pod Security Policy - Deploys default PodSecurityPolicy objects
* Node Pools using VMSS
* Azure CNI networking & network policy
* Disables `kube-dashboard` addon for security reasons

# Deploying a cluster
## Pre-requisites
* azure-cli
* `kubectl` - use `az aks install-cli`
* `kustomize` - 3.1.0 or later
* `helm` (optional, if performing a chart update)

## Configuration
The configuration file in the `cluster/` folder must have the following defined:
* `ENVIRONMENT` - The service tier. Values in `{eng,dve,nonp,prod}`
* `LOCATION` - Location of the AKS cluster
* `APPCODE` - App Code for billing purposes. This allows clusters to be either shared platform or assigned to an individual team.
* `TRANSIT_CODE` - Transit Code for billing purposes. This allows clusters to be either shared platform or assigned to an individual team.

Private/Public Cluster Configuration
* `AKS_PRIVATE` - type boolean, if set  `true` or not set at all indicates the cluster is private; and if set `false`, indicates public AKS cluster.

Integration with Hashicorp Vault Configuration
* `HCVAULT_SERVICE_ACCOUNT` - Service account used to connect to HC Vault, by default set to `rbc-vault-auth`.
* `HCVAULT_NAMESPACE` -Service account namespace used for connecting to HC Vault, by default set to `default`.
* `HCVAULT_SERVER` - Hashicorp Vault IP address. For appropriate values applicable to a given tier, refer to [Vault Environments](https://rbc-confluence.fg.rbc.com/display/DP/Vault+Environments)
* `HCVAULT_PORT` - HC Vault port number, default value is `8200`.

Network Configuration:
* `dnsServers` - Array of DNS Servers. This can be pointing to the Azure Resolver, on-premise DNS, or eventually the DNS servers in shared services
* `PodVnetAddressPrefix` - The address space in CIDR notation for the Virtual Network used for Pods. Since this VNET will be routable within Azure, must be unique per cluster. See [Azure IP Address Management for assignments](https://rbc-confluence.fg.rbc.com:8443/display/AR/Azure+IP+Address+Management).
* `ServiceAddressPrefix` - The address space in CIDR notation for the Kubernetes services. The range should be a separate non-routable network and must not overlap with PodVnetAddressPrefix. See [IP Address Management section on Confluence for further details](https://rbc-confluence.fg.rbc.com:8443/display/AR/Azure+IP+Address+Management#AzureIPAddressManagement-AKSServiceIPAddressAllocation).
* `dnsServiceIP` - A statically assigned IP address that must be taken from the `ServiceAddressPrefix` above. Typically, it will assign the 10th address in the block, ie. for CIDR 172.16.0.0/16, assign 172.16.0.10 to the `dnsServiceIP`

Managed Identity Cluster
* `AKS_AAD_ENABLED` - type boolean, if set `true` indicates the cluster is based on Managed Identity and AAD groups (`AADADMINGROUPS`); if `false` it uses Service Principal.
* `AADADMINGROUPS` - Members of the groups added here can login to the cluster.

Service Principal Information:
* `clusterServicePrincipalObjectId` - Service Principal (Object Id) used to create/delete managed Resources
* `clusterServicePrincipalAppId` - Service Principal (Application Id) used to create/delete managed Resources
* `clusterServicePrincipalClientSecret` - The Secret for the cluster service principal. This value should come from a credentials store.

AAD Integration Information - Values are from the results of `00-prereq-aad.sh`
* `AAD_ClientAppID` - The Application Id of the **Client** Service Principal for AAD Integration
* `AAD_ServerAppID` - The Application Id of the **Server** Service Principal for AAD Integration
* `AAD_ServerAppSecret` - The secret fo the **Server** Service Principal for AAD Integration. This value should come from a credentials store

Nodepool:
* `NODE_POOL_JSON` - Json string consist of node-pool configs(poolName, workerNodeVMSize, maxPods, workerNodeCount, osDiskSizeGB, workerOsType)

ACR:
* `ACR_SUBSCRIPTION_ID` - The subscription where the ACR is hosted
* `ACR_RESOURCE_GROUP` - The name of the resource group hosting the ACR
* `ACR_NAME` - The name of the ACR the cluster will use


## Secrets
The following secrets are stored in an Azure Keyvault per service tier. The Keyvault is specific to AKS administration:
* Event Hub Connection String - Connection string for the local event hub (they are regional). Key format: `EventHub-${REGION}`. Examples: `EventHub-canadacentral` and `EventHub-canadaeast`
* Azure AD Integration
  * `AADClientAppId` - Application Id for the Client Side integration
  * `AADServerAppId` - Application Id for the Server Side integration
  * `AADServerAppSecret` - Application Secret for the Server Side integration
* Service Principal to for AKS to manage the "managed resources". This is managed per service tier and will eventually be deprecated in favor of Managed Identities.
  * `clusterServicePrincipalAppId` - Application Id
  * `clusterServicePrincipalClientSecret` - Application Secret
  * `clusterServicePrincipalObjectId` - Object Id (used for RBAC)
* Cloudability API key for cloudability deamonset deployment with cluster spin up for chargeback.
  * `cloudability-api-key` - Cloudability api secret (Given by the Cloudability Team)
* Splunk Connect HEC Token for the Splunk Connect daemonset - used to fetch logs and send to Splunk Cloud
  * `AER0-HEC-KYV0-{subscription-name}-{environment}-AKS-01`
* Aqua Splunk HEC Token for Compliance Scanning logs to be sent to Splunk Cloud
  * `AER0-HEC-KYV0-{subscription-name}-{environment}-AQUA-01`

**NOTE:**: Ensure the the following values are _never_ added to the cluster configuration file directly as it contains credentials. If you are testing locally, create a file called `sensitive.conf` (which is ignored by Git) and source it manually before executing any scripts. During pipeline deployments, these values are only allowed to be sourced externally and added as environment variables.

```bash
$ cat sensitive.conf
export AAD_ServerAppSecret="..."
export clusterServicePrincipalClientSecret="..."
```

## Steps:
* Ensure pre-requisites are met for AAD integration. `./00-prereq-aad.sh $APP_CODE $SERVICE_TIER` where `SERVICE_TIER` is in {'E','S','N','P'}. This will create the required service principals and app registrations. This script needs elevated privileges in AAD to grant consent on behalf of the principal. This requires the involvement of the IAM team. If unable to run the script in unattended fashion, an operator can follow the Portal instructions at https://docs.microsoft.com/en-us/azure/aks/azure-ad-integration
* Create a cluster configuration in `cluster/`
* Run the deployment script `./aks-deploy.sh $CONFIG_FILE_PATH`.
* Configure kubectl to the deployed cluster like below `./utils/setup_kubctl_config.sh $CONFIG_FILE_PATH`.

