#!/usr/bin/env bash
# Create VNET for AKS & grant service principal Network Contributor role on the new VNET
# for AKS to manage the NICs, NSGs, etc.
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will deploy networking resources for AKS and add peerings to
    shared services.

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@

einfo "START $0"

# Constants
export GIT_BRANCH=${GIT_BRANCH:-$(git branch | grep \* | cut -d ' ' -f2)}
export GIT_COMMIT=${GIT_COMMIT:-$(git rev-parse HEAD)}
export RELEASED=$(date +%s)

LEAF_VNET_SUBNET_ID=$(az group deployment show -g ${RESOURCE_GROUP} -n vnet_${AKS_NAME} -o json | jq --exit-status --raw-output '.properties.outputs.podSubnetId.value')
edumpvar LEAF_VNET_SUBNET_ID

einfo "Updating Azure KeyVault service endpoint params"
SERVICE_ENDPOINT_CONFIG_FILE="shared-services-kv/params/${ENVIRONMENT}/${LOCATION}/params.json"
python3 configure-service-endpoints.py --params ${SERVICE_ENDPOINT_CONFIG_FILE} \
                                       --subnet ${LEAF_VNET_SUBNET_ID} \
                                       --type "KeyVault"

einfo "Updating ACR service endpoint params"
SERVICE_ENDPOINT_CONFIG_FILE="shared-services-acr/params/${ENVIRONMENT}/params.json"
python3 configure-service-endpoints.py --params ${SERVICE_ENDPOINT_CONFIG_FILE} \
                                       --subnet ${LEAF_VNET_SUBNET_ID} \
                                       --type "ContainerRegistry"

NEW_BRANCH_NAME="${GIT_BRANCH}-aks-sp-${RELEASED}"
./commit-and-push.sh "${GIT_BRANCH}" "${NEW_BRANCH_NAME}"

einfo "END  $0"
