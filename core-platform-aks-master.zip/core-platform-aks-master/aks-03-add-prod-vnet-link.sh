#!/usr/bin/env bash
# Add Private Link to PROD SS Vnet to AKS Private DNS Zone
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will add a vnet link to the Prod SS Vnets

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        1 - Name of the Private DNS Zone
        2 - AKS Resource Group Name
        3 - AKS Cluster Name
        4 - AKS Subscription ID
    """
    exit 1
}

if [ "$#" -ne 4 ]; then
    usage
fi

check_prereq "az"

einfo "START $0"

#Get managed RG 
PRIVATE_DNS_ZONE_NAME=$1
RESOURCE_GROUP=$2
AKS_NAME=$3
SUBSCRIPTION_ID=$4
ZONE_RESOURCE_GROUP="${RESOURCE_GROUP}-managed"

# Job assumes Private DNS Zone is created and ready.

CAC_SS_VNET="/subscriptions/38ed9b78-9fa7-4981-80f4-dab76adfc854/resourceGroups/p-prod-ccoe-sharedservices-network-rg-cac-1/providers/Microsoft.Network/virtualNetworks/p-prod-ccoe-sharedservices-network-vnet-cac-1"
CAE_SS_VNET="/subscriptions/38ed9b78-9fa7-4981-80f4-dab76adfc854/resourceGroups/p-prod-ccoe-sharedservices-network-rg-cae-1/providers/Microsoft.Network/virtualNetworks/p-prod-ccoe-sharedservices-network-vnet-cae-1"

einfo "Configuring Zone: $PRIVATE_DNS_ZONE_NAME"

# Create link to Prod CAC SS if it doesn't exist
VNET_LINK_NAME="${AKS_NAME}-to-prod-cac-ss-dns"
if $(az network private-dns link vnet show --subscription ${SUBSCRIPTION_ID} -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name ${VNET_LINK_NAME} &> /dev/null); then
    einfo "Private Vnet Link \"${VNET_LINK_NAME}\" already exists..."
else
    einfo "Add CAC Vnet Link to Private DNS Zone..."
    az network private-dns link vnet create --subscription ${SUBSCRIPTION_ID} --resource-group ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name ${VNET_LINK_NAME} --virtual-network ${CAC_SS_VNET} --registration-enabled false
fi

# Create link to Prod CAE SS if it doesn't exist
VNET_LINK_NAME="${AKS_NAME}-to-prod-cae-ss-dns"
if $(az network private-dns link vnet show --subscription ${SUBSCRIPTION_ID} -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name ${VNET_LINK_NAME} &> /dev/null); then
    einfo "Private Vnet Link \"${VNET_LINK_NAME}\" already exists..."
else

    einfo "Add CAE Vnet Link to Private DNS Zone..."
    az network private-dns link vnet create --subscription ${SUBSCRIPTION_ID} --resource-group ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name ${VNET_LINK_NAME} --virtual-network ${CAE_SS_VNET} --registration-enabled false

fi

