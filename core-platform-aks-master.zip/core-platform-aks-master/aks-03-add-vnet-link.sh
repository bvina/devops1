#!/usr/bin/env bash
# Add Private Link to SS Vnet to AKS Private DNS Zone
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will create a new AKS cluster or update an existing one
    Pre-Requisites:
        - Must be logged in to Azure run az login
    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@
einfo "START $0"

AKS_PRIVATE=${AKS_PRIVATE:-"true"}
#Only run if deploying a Private AKS Cluster
if [ ${AKS_PRIVATE}  != "true" ]; then
  einfo "This script should only be run for Private AKS Clusters"
  exit 0
fi

# How long to wait in seconds between checks for the Zone
SLEEP_INTERVAL=30

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

#Get managed RG
ZONE_RESOURCE_GROUP="${RESOURCE_GROUP}-managed"

set +o errexit
PRIVATE_DNS_ZONE_NAME=""
# Loop until Private DNZ Zone is created
einfo "Looking for Private DNS Zone..."
while [[ "$PRIVATE_DNS_ZONE_NAME" == "" ]]; do
    einfo "Sleeping ${SLEEP_INTERVAL}s..."
    sleep $SLEEP_INTERVAL

    PRIVATE_DNS_ZONE_NAME=$(az resource list --resource-group ${ZONE_RESOURCE_GROUP} --resource-type "Microsoft.Network/privateDnsZones" --query "[].name" -o tsv 2> /dev/null)
done
einfo "Found Private DNS Zone: ${PRIVATE_DNS_ZONE_NAME}"
set -o errexit

einfo "Verifying Private DNS Zone is ready..."
az network private-dns zone wait --resource-group ${ZONE_RESOURCE_GROUP} --name ${PRIVATE_DNS_ZONE_NAME} --created

LINK_SUBSCRIPTION=${DNS_SS_SUBSCRIPTION_ID:-"$SS_SUBSCRIPTION_ID"}
LINK_RG=${DNS_SS_NETWORK_RG:-"$SS_NETWORK_RG"}
LINK_VNET=${DNS_SS_VNET_NAME:-"$SS_VNET_NAME"}

CAC_SS_VNET="/subscriptions/${LINK_SUBSCRIPTION}/resourceGroups/${LINK_RG/-cae-/-cac-}/providers/Microsoft.Network/virtualNetworks/${LINK_VNET/-cae-/-cac-}"
CAE_SS_VNET="/subscriptions/${LINK_SUBSCRIPTION}/resourceGroups/${LINK_RG/-cac-/-cae-}/providers/Microsoft.Network/virtualNetworks/${LINK_VNET/-cac-/-cae-}"

# Cleanup vnet links with old naming convention
if $(az network private-dns link vnet show -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name "${AKS_NAME}-to-ss-dns" &> /dev/null); then
    einfo "Removing old vnet link: ${AKS_NAME}-to-ss-dns"
    az network private-dns link vnet delete -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name "${AKS_NAME}-to-ss-dns" --yes
fi

# Cleanup vnet links with less old naming convention (Region without ENV)
if $(az network private-dns link vnet show -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name "${AKS_NAME}-to-cac-ss-dns" &> /dev/null); then
    einfo "Removing old vnet link: ${AKS_NAME}-to-ss-dns"
    az network private-dns link vnet delete -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name "${AKS_NAME}-to-cac-ss-dns" --yes
fi
if $(az network private-dns link vnet show -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name "${AKS_NAME}-to-cae-ss-dns" &> /dev/null); then
    einfo "Removing old vnet link: ${AKS_NAME}-to-ss-dns"
    az network private-dns link vnet delete -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name "${AKS_NAME}-to-cae-ss-dns" --yes
fi

# Create link to CAC SS if it doesn't exist
VNET_LINK_NAME="${AKS_NAME}-to-${ENVIRONMENT}-cac-ss-dns"
if $(az network private-dns link vnet show -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name ${VNET_LINK_NAME} &> /dev/null); then
    einfo "Private Vnet Link \"${VNET_LINK_NAME}\" already exists..."
else
    einfo "Add CAC Vnet Link to Private DNS Zone..."
    az network private-dns link vnet create --resource-group ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name ${VNET_LINK_NAME} --virtual-network ${CAC_SS_VNET} --registration-enabled false
fi

# Create link to CAE SS if it doesn't exist
VNET_LINK_NAME="${AKS_NAME}-to-${ENVIRONMENT}-cae-ss-dns"
if $(az network private-dns link vnet show -g ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name ${VNET_LINK_NAME} &> /dev/null); then
    einfo "Private Vnet Link \"${VNET_LINK_NAME}\" already exists..."
else
    # Verify vnet exists since ENG/NONP don't have CAE SS
    einfo "Verify that the VNET exists"
    if $(az network vnet show --ids $CAE_SS_VNET &> /dev/null); then
        einfo "Add CAE Vnet Link to Private DNS Zone..."
        az network private-dns link vnet create --resource-group ${ZONE_RESOURCE_GROUP} --zone-name ${PRIVATE_DNS_ZONE_NAME} --name ${VNET_LINK_NAME} --virtual-network ${CAE_SS_VNET} --registration-enabled false
    else
        einfo "Skipping CAE Vnet Link to Private DNS Zone..."
    fi
fi
