#!/usr/bin/env bash
# Deploy an AKS cluster. All pre-requisite resources must already exist
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will create a new AKS cluster or update an existing one

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@
einfo "START $0"

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

AKS_PRIVATE=${AKS_PRIVATE:-"true"}
# Deploy AKS w/ Network
einfo "Deploying AKS Cluster & Updating networks"
if [ ${AKS_PRIVATE}  == "true" ]; then
  export ARM_TEMPLATE="arm/aks_private_cluster_aad_enabled.json"
else
  export ARM_TEMPLATE="arm/aks_cluster.json"
fi

# Set the Network Policy plugin
NETWORK_POLICY=${NETWORK_POLICY:-"calico"}
# Set AKS SKU
AKS_SKU_TIER=${AKS_SKU_TIER:-"Free"}
# Enable Local Auth if set to false, default disabled
DISABLE_LOCAL_AUTH=${DISABLE_LOCAL_AUTH:-"true"}
# Using CMK for new clusters
ENABLE_CMK=${ENABLE_CMK:-"true"}
if [ ${ENABLE_CMK} == "true" ]; then
  AKS_SUB_NAME=$(az account show --name ${SUBSCRIPTION_ID} --query name -o tsv)
  DES_RG=$(./utils/printVar.sh prereq-aks/disk-encryption/conf/${ENVIRONMENT}/${AKS_SUB_NAME}/${LOCATION}.conf DES_RG)
  [[ $DES_RG =~ ([^-]+)-([^-]+)-([^-]+)-([^-]+)-([^-]+)-([^-]+)-(.+) ]]
  DES_NAME="${BASH_REMATCH[1]}-${BASH_REMATCH[2]}-${BASH_REMATCH[3]}-${BASH_REMATCH[4]}-${BASH_REMATCH[5]}-des-${BASH_REMATCH[7]}"
  export DISK_CMK_SET_ID=$(az disk-encryption-set show -n ${DES_NAME} -g ${DES_RG} --query "[id]" -o tsv)
else
  export DISK_CMK_SET_ID=""
fi
edumpvar AKS_PRIVATE NETWORK_POLICY AKS_SKU_TIER DISABLE_LOCAL_AUTH ENABLE_CMK

# ADMIN groups per ST
if [ ${ENVIRONMENT}  == "eng" ]; then
  export ADMIN_GROUP_ID="['d5b703d2-4b19-4d9f-b5d1-ea2ed33cedeb']" # APP_VK00_KYV0_E_AKS_ADMINS
elif [ ${ENVIRONMENT}  == "nonp" ]; then
  export ADMIN_GROUP_ID="['713574c0-68e6-411a-8c21-b1fd84622b9e']" # APP_VK00_KYV0_N_AKS_ADMINS
elif [ ${ENVIRONMENT}  == "prod" ]; then
  export ADMIN_GROUP_ID="['0d8d4567-ed71-49da-b434-21508e7540a0']" # APP_VK00_KYV0_P_AKS_ADMINS
else
  einfo "${ENVIRONMENT} is not valid for AD group" && exit 1;
fi

# if this is a redeployment, check if any nodepool removed from code and delete it
CLUSTER_EXIST=$(az aks show -n ${AKS_NAME} -g ${RESOURCE_GROUP} --query provisioningState -o tsv 2>/dev/null || true)
if [ ${CLUSTER_EXIST} ]; then
  RUNNING_POOLS=($(az aks show -n ${AKS_NAME} -g ${RESOURCE_GROUP} --query agentPoolProfiles[].name -o tsv))
  VALID_POOLS=($(echo "${NODE_POOL_JSON}" | jq -r '.[].poolName'))

  for pool in ${RUNNING_POOLS[@]};do
    if [[ ! "${VALID_POOLS[*]}" =~ "${pool}" ]]; then
      # remove lock if exists
      LOCK_INFO=($(az group lock list -g ${RESOURCE_GROUP} --query '[].[name,level]' -o tsv))
      az group lock delete --name ${LOCK_INFO[0]} -g ${RESOURCE_GROUP} -o none 2>/dev/null || true
      sleep 15
      einfo "Deleting ${pool} Pool since does not exist in cluster config"
      az aks nodepool delete --cluster-name ${AKS_NAME} \
        --name ${pool} \
        --resource-group ${RESOURCE_GROUP} \
        --no-wait -o none
      # re-add lock if applicable
      az group lock create --lock-type ${LOCK_INFO[1]} -n ${LOCK_INFO[0]} -g ${RESOURCE_GROUP} -o none 2>/dev/null || true
    fi
  done
fi

# Deploy cluster
einfo "Executing AKS deployment"
az group deployment create \
    --subscription ${SUBSCRIPTION_ID} \
    --resource-group ${RESOURCE_GROUP} \
    --template-file ${ARM_TEMPLATE} \
    --verbose \
    --parameters  \
        kubernetesVersion=${kubernetesVersion} \
        clusterName=${AKS_NAME} \
        agentPoolProfiles="${NODE_POOL_JSON}" \
        networkPolicy="${NETWORK_POLICY}" \
        skuTier="${AKS_SKU_TIER}" \
        disableLocalAccounts="${DISABLE_LOCAL_AUTH}" \
        adminGroupObjectIDs="${ADMIN_GROUP_ID}" \
        diskEncryptionSetID="${DISK_CMK_SET_ID}" \
        enableCMK="${ENABLE_CMK}"

einfo "END $0"
