#!/usr/bin/env bash
# Deploy an AKS cluster. All pre-requisite resources must already exist
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will create a new AKS cluster or update an existing one

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@
einfo "START $0"

einfo "Getting ACR ID for $ACR_NAME"
ACR_ID=$(az acr show --subscription $ACR_SUBSCRIPTION_ID --resource-group $ACR_RESOURCE_GROUP --name $ACR_NAME --query id --output tsv)

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

MI_PRINCIPAL_ID=$(az aks show --resource-group $RESOURCE_GROUP --name $AKS_NAME --query identity.principalId -o tsv)
einfo "Granting roles to managed identities on sub level"
az role assignment create --assignee $MI_PRINCIPAL_ID --role "Managed Identity Operator" --output none
az role assignment create --assignee $MI_PRINCIPAL_ID --role "Network Contributor" --output none
az role assignment create --assignee $MI_PRINCIPAL_ID --role "Reader" --output none
az role assignment create --assignee $MI_PRINCIPAL_ID --role "Virtual Machine Contributor" --output none

# -managed id
KUBE_IDENTITY_ID=$(az aks show --resource-group $RESOURCE_GROUP --name $AKS_NAME --query identityProfile.kubeletidentity.clientId -o tsv)
az role assignment create --assignee $KUBE_IDENTITY_ID --role acrpull --scope ${ACR_ID} --output none || true
az role assignment create --assignee $KUBE_IDENTITY_ID --role "Managed Identity Operator" --output none
az role assignment create --assignee $KUBE_IDENTITY_ID --role "Network Contributor" --output none
az role assignment create --assignee $KUBE_IDENTITY_ID --role "Reader" --output none
az role assignment create --assignee $KUBE_IDENTITY_ID --role "Virtual Machine Contributor" --output none
az role assignment create --assignee $KUBE_IDENTITY_ID --role "Contributor" --resource-group $RESOURCE_GROUP-managed --output none

# RBC Operator MI is in KYVOS Subs, for any cluster in different sub rather than kyvos, the following will be applied
# find RBC Operator MI Sub
export RBC_OPERATOR_MI_SUB=$(jq -r '.[].SUBSCRIPTION_ID' shared-services-managed-identity/conf/rbc-operator/${ENVIRONMENT}.json)
if [ ${SUBSCRIPTION_ID}  != ${RBC_OPERATOR_MI_SUB} ]; then
  RBC_OPERATOR_MI_RG=$(jq -r '.[].RESOURCE_GROUP' shared-services-managed-identity/conf/rbc-operator/${ENVIRONMENT}.json)
  einfo "Granting MI role to Cluster ID over RBC Operator MI RG"
  az role assignment create --assignee $KUBE_IDENTITY_ID --role "Managed Identity Operator" --scope "/subscriptions/${RBC_OPERATOR_MI_SUB}/resourcegroups/${RBC_OPERATOR_MI_RG}" --output none
fi

#ASO
export ASO_MI_SUB=$(jq -r '.[].SUBSCRIPTION_ID' shared-services-managed-identity/conf/aso/${ENVIRONMENT}.json)
if [ ${SUBSCRIPTION_ID}  != ${ASO_MI_SUB} ]; then
  ASO_MI_RG=$(jq -r '.[].RESOURCE_GROUP' shared-services-managed-identity/conf/aso/${ENVIRONMENT}.json)
  einfo "Granting MI role to Cluster ID over Azure Operator MI RG"
  az role assignment create --assignee $KUBE_IDENTITY_ID --role "Managed Identity Operator" --scope "/subscriptions/${ASO_MI_SUB}/resourcegroups/${ASO_MI_RG}" --output none
fi

STAGING_ACR_ACCESS=${STAGING_ACR_ACCESS:-"false"}
if [ "${STAGING_ACR_ACCESS}" == "true" ]; then
  einfo "Getting Staging ACR ID for $STAGING_ACR_NAME"
  STAGING_ACR_ID=$(az acr show --subscription $STAGING_ACR_SUBSCRIPTION_ID --resource-group $STAGING_ACR_RESOURCE_GROUP --name $STAGING_ACR_NAME --query id --output tsv)
  az role assignment create --assignee $KUBE_IDENTITY_ID --role acrpull --scope ${STAGING_ACR_ID} --output none || true
fi

# EXTERNAL-DNS MI is in KYVOS Subs, for any cluster in different sub rather than kyvos, the following will be applied
# find External DNS Sub
export EXTERNAL_DNS_MI_SUB=$(jq -r '.[].SUBSCRIPTION_ID' shared-services-managed-identity/conf/external-dns/${ENVIRONMENT}.json)
if [ ${SUBSCRIPTION_ID}  != ${EXTERNAL_DNS_MI_SUB} ]; then
  EXTERNAL_DNS_MI_RG=$(jq -r '.[].RESOURCE_GROUP' shared-services-managed-identity/conf/external-dns/${ENVIRONMENT}.json)
  einfo "Granting MI role to Cluster ID over External DNS MI RG"
  az role assignment create --assignee $KUBE_IDENTITY_ID --role "Managed Identity Operator" --scope "/subscriptions/${EXTERNAL_DNS_MI_SUB}/resourcegroups/${EXTERNAL_DNS_MI_RG}" --output none
fi

einfo "END $0"
