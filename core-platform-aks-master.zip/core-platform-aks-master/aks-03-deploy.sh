#!/usr/bin/env bash
# Deploy an AKS cluster. All pre-requisite resources must already exist
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will create a new AKS cluster or update an existing one

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@
einfo "START $0"

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Retrive credentials from AKV
einfo "Retrieving secrets from ${KV_NAME}"
clusterServicePrincipalAppId=`az keyvault secret show --vault-name ${KV_NAME} --name clusterServicePrincipalAppId --query value -o tsv`
clusterServicePrincipalClientSecret=`az keyvault secret show --vault-name ${KV_NAME} --name clusterServicePrincipalClientSecret --query value -o tsv`

AAD_ClientAppId=`az keyvault secret show --vault-name ${KV_NAME} --name AADClientAppId --query value -o tsv`
AAD_ServerAppId=`az keyvault secret show --vault-name ${KV_NAME} --name AADServerAppId --query value -o tsv`
AAD_ServerAppSecret=`az keyvault secret show --vault-name ${KV_NAME} --name AADServerAppSecret --query value -o tsv`

AKS_PRIVATE=${AKS_PRIVATE:-"true"}

# Deploy AKS w/ Network
einfo "Deploying AKS Cluster & Updating networks"
if [ ${AKS_PRIVATE}  == "true" ]; then
  export ARM_TEMPLATE="arm/aks_private_cluster.json"
else
  export ARM_TEMPLATE="arm/aks_cluster.json"
fi

einfo "NODE_POOL_JSON Json: ${NODE_POOL_JSON}"
edumpvar ARM_TEMPLATE

einfo "Executing AKS deployment"
az group deployment create \
    --subscription ${SUBSCRIPTION_ID} \
    --resource-group ${RESOURCE_GROUP} \
    --template-file ${ARM_TEMPLATE} \
    --verbose \
    --parameters  \
        clusterServicePrincipalAppId=${clusterServicePrincipalAppId} \
        clusterServicePrincipalClientSecret=${clusterServicePrincipalClientSecret} \
        AAD_ClientAppId=${AAD_ClientAppId} \
        AAD_ServerAppId=${AAD_ServerAppId} \
        AAD_ServerAppSecret=${AAD_ServerAppSecret} \
        kubernetesVersion=${kubernetesVersion} \
        clusterName=${AKS_NAME} \
        agentPoolProfiles="${NODE_POOL_JSON}"

einfo "END $0"
