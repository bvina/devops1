#!/usr/bin/env bash
# Add Private Link to SS Vnet to AKS Private DNS Zone
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will create a new AKS cluster or update an existing one

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@
einfo "START $0"

AKS_PRIVATE=${AKS_PRIVATE:-"true"}

#Only run if deploying a Private AKS Cluster
if [ ${AKS_PRIVATE}  != "true" ]; then
  einfo "This script should only be run for Private AKS Clusters"
  exit 0
fi

# How long to wait in seconds between checks for the Zone
SLEEP_INTERVAL=30

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

#Get managed RG
ZONE_RESOURCE_GROUP="${RESOURCE_GROUP}-managed"

set +o errexit
PRIVATE_DNS_ZONE_NAME=""
# Loop until Private DNZ Zone is created
einfo "Looking for Private DNS Zone..."
while [[ "$PRIVATE_DNS_ZONE_NAME" == "" ]]; do
    einfo "Sleeping ${SLEEP_INTERVAL}s..."
    sleep $SLEEP_INTERVAL

    PRIVATE_DNS_ZONE_NAME=$(az resource list --resource-group ${ZONE_RESOURCE_GROUP} --resource-type "Microsoft.Network/privateDnsZones" --query "[].name" -o tsv)
done
einfo "Found Private DNS Zone: ${PRIVATE_DNS_ZONE_NAME}"
set -o errexit

einfo "Verifying Private DNS Zone is ready..."
az network private-dns zone wait --resource-group ${ZONE_RESOURCE_GROUP} --name ${PRIVATE_DNS_ZONE_NAME} --created
