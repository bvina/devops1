#!/usr/bin/env bash
# Whitelisting authorized IP ranges
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will create a new AKS cluster or update an existing one

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@
einfo "START $0"

AKS_PRIVATE=${AKS_PRIVATE:-"true"}
if [ ${AKS_PRIVATE}  == "true" ]; then
  einfo "API whitelisting step is NOT applicable for Private AKS"
  einfo "END $0"
  exit 0
fi

einfo "Setting default subscription to ${SUBSCRIPTION_ID}" \
 && az account set --subscription  ${SUBSCRIPTION_ID}

einfo "Enabling API Whitelisting"
# All firewalls should be whitelisted because the onboarding and deployment API's could move between regions
for fw_pub_ip_id in `az network firewall list --query "[][].ipConfigurations[].publicIpAddress.id" -o tsv`
do
    AZURE_FIREWALL_PUBLIC_IP=`az network public-ip show --ids ${fw_pub_ip_id} -o json |jq -r .ipAddress`"/32"
    AZURE_FIREWALL_PUBLIC_IPS+=(${AZURE_FIREWALL_PUBLIC_IP})
done


AZURE_FIREWALL_PUBLIC_IPS_STRING=`IFS=',';echo "${AZURE_FIREWALL_PUBLIC_IPS[*]// /|}"`
edumpvar AZURE_FIREWALL_PUBLIC_IPS_STRING

# Constants for API Whitelisting
CANADA_CIDR_1="142.245.59.0/24"
CANADA_CIDR_2="142.245.193.0/24"
JENKINS_CIDR_1="198.96.129.146/32"
JENKINS_CIDR_2="198.96.129.145/32"
JENKINS_CIDR_3="198.96.129.150/32"
JENKINS_CIDR_4="198.96.129.151/32"

az --version
set -x
az aks update \
    --resource-group ${RESOURCE_GROUP} \
    --name ${AKS_NAME} \
    --api-server-authorized-ip-ranges ${AZURE_FIREWALL_PUBLIC_IPS_STRING},${CANADA_CIDR_1},${CANADA_CIDR_2},${JENKINS_CIDR_1},${JENKINS_CIDR_2},${JENKINS_CIDR_3},${JENKINS_CIDR_4}
set +x
einfo "END $0"
