#!/usr/bin/env bash
# Apply Hashicorp Vault settings to AKS K8S cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: Apply Hashicorp Vault settings to AKS K8S cluster.

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@
einfo "START $0"

einfo "Setting default subscription to ${SUBSCRIPTION_ID}" \
 && az account set --subscription  ${SUBSCRIPTION_ID}

export AKS_PRIVATE=${AKS_PRIVATE:-"true"}
if [ ${AKS_PRIVATE}  == "false" ]; then
  einfo "Apply Hashicorp Vault settings to AKS K8S cluster step is NOT applicable for Public AKS"
  einfo "END $0"
  exit 0
else
  einfo "Running steps necessary to enable Private AKS deployment."
  source "${BASH_SOURCE%/*}/utils/kube_config/setup_hosts_config.sh"
  edumpvar NO_PROXY
fi

einfo "Start configuring HC Vault settings for Private AKS cluster: ${AKS_NAME}"
# Login by Admin SP
aks_login_admin_sp $@

einfo "Listing k8s nodes" && kubectl get nodes --insecure-skip-tls-verify=true

einfo "Testing access to AKS cluster ${AKS_NAME} by listing the nodes"
kubectl --insecure-skip-tls-verify=true cluster-info || true
kubectl get nodes --insecure-skip-tls-verify=true || true
kubectl get pods -A --insecure-skip-tls-verify=true || true

einfo "Applying RBAC settings for HC Vault service account ${HCVAULT_SERVICE_ACCOUNT} in namespace ${HCVAULT_NAMESPACE} "
kustomize build kubernetes/hc-vault/overlays/${ENVIRONMENT}/${LOCATION} | \
    kubectl apply \
        --insecure-skip-tls-verify=true \
        --force --request-timeout=360s --wait -f -

einfo "**********************************************************************************"
einfo "Generating variables to setup Trust Relationship with Hashicorp Vault instance"
export K8S_HOST=$(echo $(kubectl config view -o jsonpath='{.clusters[*].cluster.server}') | sed 's/:443//g; s/https:\/\///g' )
export K8S_IP=${private_ip}
einfo "**********************************************************************************"
einfo "Step 1: On the HC Vault host, add the following line to the end of /etc/hosts file "
einfo "\t\t $K8S_IP $K8S_HOST"
einfo "**********************************************************************************\n"
einfo "Step 2:"
einfo "\t\t Get Reviewer Token and SA Cert, then push them to Key Vault"
einfo "**********************************************************************************\n"
export SECRET_NAME=$(kubectl -n ${HCVAULT_NAMESPACE} get serviceaccount $HCVAULT_SERVICE_ACCOUNT -o jsonpath='{.secrets[0].name}')
export SA_CERT=$(kubectl get secrets $SECRET_NAME -o jsonpath="{.data['ca\.crt']}")
export REVIEWER_TOKEN=$(kubectl get secret $SECRET_NAME -o jsonpath={.data.token})
einfo "Step 3:"
einfo "Attempting to import SA Reviewer Token to keyvault ${KV_NAME}"
az keyvault secret set --value ${REVIEWER_TOKEN} \
      --name ReviewerToken-${AKS_NAME}-${HCVAULT_SERVICE_ACCOUNT} \
      --vault-name ${KV_NAME} \
      --tags "aks=${AKS_NAME}", "type=token" \
      --description "Reviewer Token for service account: $HCVAULT_SERVICE_ACCOUNT, aks: ${AKS_NAME}"

einfo "Attempting to import SA Cert to keyvault ${KV_NAME}"
az keyvault secret set --value ${SA_CERT} \
      --name Cert-${AKS_NAME}-${HCVAULT_SERVICE_ACCOUNT} \
      --vault-name ${KV_NAME} \
      --tags "aks=${AKS_NAME}", "type=cert" \
      --description "Cert for service account: $HCVAULT_SERVICE_ACCOUNT, aks: ${AKS_NAME}"

einfo "**********************************************************************************"

einfo "END $0"
