#!/usr/bin/env bash
# Deploy an Azure Kubernetes Services Cluster (AKS)

# Set options
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will deploy an AKS Cluster

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        A variable file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

# Constants
export GIT_BRANCH=${GIT_BRANCH:-$(git branch | grep \* | cut -d ' ' -f2)}
export GIT_COMMIT=${GIT_COMMIT:-$(git rev-parse HEAD)}
export RELEASED=$(date +%s)

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

AKS_AAD_ENABLED=${AKS_AAD_ENABLED:-"true"}

if [ ${AKS_AAD_ENABLED}  == "true" ]; then
  # AAD enabled AKS route
  einfo "AKS_AAD_ENABLED flag is set to 'true'."
  ./aks-03-deploy-aad-enabled.sh $@
else
  # regular route
  ./aks-03-deploy.sh $@
fi

./aks-04-api-whitelist.sh $@
