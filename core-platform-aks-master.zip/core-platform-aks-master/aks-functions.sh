#!/usr/bin/env bash
# Functions to help with AKS Deployment

function create_dns_record() {
    RECORD_SET_NAME=$1
    IP_ADDRESS=$2
    set +o errexit
    az network private-dns record-set a show -o json \
        --subscription ${SS_SUBSCRIPTION_ID} \
        --resource-group ${SS_NETWORK_RG} \
        --zone-name ${SS_DNS_ZONE} \
        --name "${RECORD_SET_NAME}" > /dev/null 2>&1
    DNS_EXISTS=$?
    set -o errexit

    if [ $DNS_EXISTS -ne 0 ]; then
        einfo "Creating DNS A record ${RECORD_SET_NAME}.${SS_DNS_ZONE}"
        az network private-dns record-set a add-record \
            --subscription ${SS_SUBSCRIPTION_ID} \
            --resource-group ${SS_NETWORK_RG} \
            --zone-name ${SS_DNS_ZONE} \
            --record-set-name "${RECORD_SET_NAME}" \
            --ipv4-address ${IP_ADDRESS}
    else
        einfo "Record ${RECORD_SET_NAME}.${SS_DNS_ZONE} already exists, updating"
        az network private-dns record-set a update \
            --subscription ${SS_SUBSCRIPTION_ID} \
            --resource-group ${SS_NETWORK_RG} \
            --zone-name ${SS_DNS_ZONE} \
            --name "${RECORD_SET_NAME}" \
            --set "aRecords[0].ipv4Address=${IP_ADDRESS}"
    fi
}
