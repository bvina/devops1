#!/usr/bin/env bash
# Update Azure keyvault parameters for the shared-services-kv/ ARM deployment

# Set options
set -o errexit
set -o pipefail

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will commit any local changes to a new branch and
    push to GitHub for keeping any configurations up-to-date and reproducible.

    Pre-Requisites:
        - git

    Arguments:
        - Original branch name from caller to switch back to after commit & push
        - New branch to commit and push to
    """
    exit 1
}

if [ $# -ne 2 ]; then
    eerror "Must specify original & new branch names as arguments"
    usage
fi

ORGINAL_BRANCH=$1
NEW_BRANCH=$2

einfo "Creating a working branch ${NEW_BRANCH} for this change."
git checkout -b ${NEW_BRANCH}

# Add changed files & commit the changes into a branch before it gets lost
git add .
git commit -m "[${NEW_BRANCH}] config update" || RC=$?

# Push it to a sperate branch
git push `git remote` ${NEW_BRANCH} || RC=$?

# Revert back to previous branch
git checkout $ORGINAL_BRANCH

einfo "Raise a Pull Request from branch ${NEW_BRANCH} against master"
