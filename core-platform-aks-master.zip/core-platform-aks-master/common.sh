#!/usr/bin/env bash
# Common bash utilities, functions, etc.
source "${BASH_SOURCE%/*}/logging.sh"
source "${BASH_SOURCE%/*}/tier-mapping.sh"
source "${BASH_SOURCE%/*}/validate.sh"
source "${BASH_SOURCE%/*}/aks-functions.sh"
source "${BASH_SOURCE%/*}/utils/kube_config/set_noproxy.sh"
source "${BASH_SOURCE%/*}/utils/kube_config/aks-non-interactive-login.sh"
