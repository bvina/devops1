#!/usr/bin/env python3
import json
import sys
import argparse
import os
import subprocess
from typing import List

VALID_TYPES = [
    "KeyVault",
    "ContainerRegistry"
]


def check_file(arg: str) -> str:
    if arg is None or not os.path.exists(arg) or not os.path.isfile(arg):
        raise argparse.ArgumentTypeError(f"{arg} is not a valid file")
    return arg


def check_arm_type(arg: str) -> str:
    if arg not in VALID_TYPES:
        raise argparse.ArgumentTypeError(f"{arg} is not an allowed resource \
            type. Allowed values: {VALID_TYPES}")
    return arg


def parse_args():
    parser = argparse.ArgumentParser(description="Configure ARM params file \
        with new subnets to activate Service Endpoints")
    parser.add_argument(
        "--params",
        "-p",
        type=check_file,
        required=True,
        help="Path to ARM parameters file to update.")
    parser.add_argument(
        "--type",
        "-t",
        type=check_arm_type,
        required=True,
        help="Type of resource used in the ARM parameters")
    return parser.parse_args()

def exec_cmd(cmd: List[str]):
    """Executes terminal code.
    Args:
        cmd: list of strings, which concatenate to a full
            bash command.
    """
    response = subprocess.Popen(cmd, stdout=subprocess.PIPE)

    response.wait()

    if response.returncode is 1:
        error_msg = f'ErrorCode: {response.returncode}'

    return response

def main():
    args = parse_args()
    # new_subnet_id = args.subnet

    with open(args.params, 'r') as f:
        params_json = json.loads(f.read())

    # Get list of clusters and extract their subnet id's. This assumes all clusters reside in a single subscription
    az_cli_cmd = ['az', 'aks', 'list', '-o', 'json','--query', '[].agentPoolProfiles[].vnetSubnetId']
    response = subprocess.Popen(az_cli_cmd, stdout=subprocess.PIPE)

    (response, _) = response.communicate()
    result = json.loads(response)

    unique_ids_only = list(set(result))
    unique_ids_only.sort()
    if args.type == "ContainerRegistry":
        valid_subnets = []
        for subnet_id in unique_ids_only:
            az_cli_cmd = ['az', 'network', 'vnet', 'subnet', 'show','--ids', subnet_id, '-o','json','--query', '"serviceEndpoints[].service"']
            response = subprocess.Popen(" ".join(az_cli_cmd), stdout=subprocess.PIPE, shell=True)
            (response, _) = response.communicate()
            result = json.loads(response)
            if "Microsoft.ContainerRegistry" in result:
                valid_subnets.append({'id': subnet_id, 'action': 'Allow'})
            else:
                print("Skipped " + subnet_id)

        params_json['parameters']['virtualNetworkRules']['value'] = valid_subnets
        # params_json['parameters']['virtualNetworkRules']['value'] = [
        #     {'id': s, 'action': 'Allow'} for s in unique_ids_only]
    else:
        params_json['parameters']['virtualNetworkRules']['value'] = [
            {'id': s} for s in unique_ids_only]
    with open(args.params, 'w') as f:
        f.write(json.dumps(params_json, indent=2, sort_keys=True))
    # Add newline to end of file to make Git happy :)
    with open(args.params, 'a') as f:
        f.write("\n")
    return 0


if __name__ == '__main__':
    sys.exit(main())
