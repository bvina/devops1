# Flux CD GitOps Operator
For every AKS cluster that is created through this repo, many Flux operators must be installed to manage some aspect of the platform's Kubernetes configurations. This includes RBAC, namespace & cluster management (ResourceQuotas, LimitRanges) and other policy related objects (NetworkPolicy, PodSecurityPolicy, OPA).

A corresponding Jenkins job is available, which should be run after every cluster creation to bootstrap Flux installation and begin applying configurations from source code. By default, the Flux operator will  perform manifest generation and apply manifests to a cluster. The [automated deployment of new container images](https://docs.fluxcd.io/en/stable/references/automated-image-update.html) is disabled.

## Manifest Generation
Flux can generate manifests at runtime so that source code repositories can remain "generic" or "templated". This is useful when combined with tools such as Helm or Kustomize as the declared state in source code is exactly applied without needing to generate manifests directly and keep them up-to-date.

Flux can technically work with any tool that performs templating or variable substitution. The result must be a set of valid Kubernetes manifests that can be applied by Flux. Flux includes `kubectl` and `kustomize` by default and is the recommended generation method. If using a different template generation method (such as Jinja & Python), a custom Flux image must be used for the sychronization process. For more advanced and customized execution of manifests, see [documentation](https://docs.fluxcd.io/en/latest/references/fluxyaml-config-files.html#execution-context-of-commands).

By default, Flux will attempt to generate manifests through Kustomize (`kustomize build <relative-path>`) via a repository that follows this directory structure:

```bash
$ tree kustomize/
kustomize/
└── <service_tier>
    └── <region>
        └── <cluster_name>
            ├── kustomization.yaml
            ├── ...
            └── <resource-manifests...>.yaml
```

These settings can be overridden per repository. See [Configuration section](#configuration) for details.

See [Flux documentation on manifest generation for details](https://docs.fluxcd.io/en/latest/references/fluxyaml-config-files.html).

## GitHub Pre-requisite
Pre-requisite: Add the SSH public key to an authorized RBC GitHub service ID to clone the repository with. The private key must be saved in Azure Key Vault so that it can be reused during subsequent Flux installations.

```bash
# Source cluster-specifc variables
$ source ../cluster/conf/path/to/cluster.conf
$ echo ${ENVIRONMENT} # Service tier
$ echo ${KV_NAME}     # platform key vault for storing secrets

# Generate a new SSH key pair for a platform service ID
$ GH_USER="PAEO0SRVGITOPS"
$ GH_PASSWORD="$(vault read -field=password appcodes/AEO0/PROD/SERVICE_ID/${GH_USER})"
$ ssh-keygen -t rsa -f identity -m PEM -q -N ""

# Add new SSH public key to service ID's RBC GitHub profile
$ SSH_PUBLIC_KEY=$(cat identity.pub)
$ GH_SSH_KEY_JSON=$(python3 -c "import json;print(json.dumps({\"title\":\"flux-gitops-${ENVIRONMENT}\",\"key\":\"${SSH_PUBLIC_KEY}\"}))")
$ curl -k -u "${GH_USER}:${GH_PASSWORD}" -d "${GH_SSH_KEY_JSON}" https://rbcgithub.fg.rbc.com/api/v3/user/keys

# Save private & public keys to platform key vault for secure storage and retrieval during Flux installations
$ az keyvault secret set \
    --vault-name ${KV_NAME} \
    --name "flux-github-ssh-key" \
    --file identity
$ az keyvault secret set \
    --vault-name ${KV_NAME} \
    --name "flux-github-pub-key" \
    --file identity.pub
```

## Installation
Installation is bootstrapped through Kustomize and a helper script to generate labels and patches dynamically based on the cluster to target. You must have access to the appropriate platform Azure Key Vault to be able download the SSH private key necessary to clone the repository on the live cluster.

`flux-v2-download` will download the Flux V2 resources based on FLUX_VERSION specified in script.

`flux-v2-install.sh` will install resources for Flux V2.

`flux-v2-deploy.sh` will deploy `gitrepositories.source.toolkit.fluxcd.io` and `kustomizations.kustomize.toolkit.fluxcd.io` resources under `flux-system` namespace for the managed repositories configured in `managed-repos.yaml` file.

# Example
```bash
cd fluxv2/
export GH_USER="PAEO0SRVGITOPS"
export GH_ORG="AEO0"
export GH_EMAIL="PAEO0SRVGITOPS@users.noreply.rbcgithub.fg.rbc.com"
export GH_REPO_NAME="core-platform-aks-rbac"
./flux-v2-install.sh ../cluster/eng/stable/cac.conf

./flux-v2-deploy.sh ../cluster/eng/stable/cac.conf

kubectl get gitrepositories.source.toolkit.fluxcd.io -A
NAMESPACE     NAME                                   URL                                                                           READY STATUS                                                              AGE
flux-system   azure-service-operator-flux            ssh://rbcgithub.fg.rbc.com/AEO0/azure-service-operator-flux.git               True    Fetched revision: eng/a5efba86dd38b9e87ac97e8bb24e7a048654479b      13m
flux-system   cert-manager                           ssh://rbcgithub.fg.rbc.com/AEO0/cert-manager.git                              True    Fetched revision: eng/6197cf7b208183b922bfaf2a4c2abbfd084a69f8      14m
flux-system   core-platform-aks-aad-pod-identity     ssh://rbcgithub.fg.rbc.com/AEO0/core-platform-aks-aad-pod-identity.git        True    Fetched revision: eng/eda43356784e217d76deebb580b4d72ef1c68e3f      16m
flux-system   core-platform-aks-external-dns         ssh://rbcgithub.fg.rbc.com/AEO0/core-platform-aks-external-dns.git            True    Fetched revision: eng/3313fca75c07217fcda882156576b9ee8e9e2066      15m
flux-system   core-platform-aks-ingress              ssh://rbcgithub.fg.rbc.com/AEO0/core-platform-aks-ingress.git                 True    Fetched revision: eng/08cfae4572b24fa368da70e5ae13ae6725a17614      15m
flux-system   core-platform-aks-kube-enforcer        ssh://rbcgithub.fg.rbc.com/AEO0/core-platform-aks-kube-enforcer.git           True    Fetched revision: eng/be7af4986b958489d8aecafb6e8be620b93623bf      14m
flux-system   core-platform-aks-kube-state-metrics   ssh://rbcgithub.fg.rbc.com/AEO0/core-platform-aks-kube-state-metrics.git      True    Fetched revision: master/ed57a46376fb75ea5ce6f6edb8670f2c0af96ae1   16m
flux-system   core-platform-aks-kured                ssh://rbcgithub.fg.rbc.com/AEO0/core-platform-aks-kured.git                   True    Fetched revision: master/8557ee60af485402f874c1fa1c643fb4851428c8   16m
flux-system   core-platform-aks-network-policy       ssh://rbcgithub.fg.rbc.com/KYV0-Shared/core-platform-aks-network-policy.git   True    Fetched revision: master/44ef5375f649afad2c893646fb2579c207172463   14m
flux-system   core-platform-aks-rbac                 ssh://rbcgithub.fg.rbc.com/AEO0/core-platform-aks-rbac.git                    True    Fetched revision: master/429ef45c1c1a7e5d017c222f7e9c9f2f3af67aba   16m
flux-system   core-platform-flux                     ssh://rbcgithub.fg.rbc.com/AEO0/core-platform-flux.git                        True    Fetched revision: eng/3dcd3adfd1820e5ba8fa234d45d89e0701dfa1a7      12m
flux-system   fluent-bit-azure-storage-flux          ssh://rbcgithub.fg.rbc.com/AEO0/fluent-bit-azure-storage-flux.git             True    Fetched revision: eng/7b7e4d1004e669dd0073a3ee8f155aa6d091a595      12m
flux-system   kyvos-config                           ssh://rbcgithub.fg.rbc.com/KYV0-Shared/kyvos-config.git                       True    Fetched revision: master/a265eb4123d6588109d1f2b957786ee87093b92b   14m
flux-system   opa-gatekeeper-flux                    ssh://rbcgithub.fg.rbc.com/AEO0/opa-gatekeeper-flux.git                       True    Fetched revision: eng/b939d1a2300cb71204bf69881573141319ac9dbf      12m
flux-system   rbc-aks-labels-operator-flux           ssh://rbcgithub.fg.rbc.com/AEO0/rbc-aks-labels-operator-flux.git              True    Fetched revision: eng/ff273582878b1756d9f28d40f16c5a574e2d586a      12m
flux-system   rbc-k8s-operator-flux                  ssh://rbcgithub.fg.rbc.com/AEO0/rbc-k8s-operator-flux.git                     True    Fetched revision: eng/686f267381de8b50aa46916943543150e0e8ff0e


kubectl get kustomizations.kustomize.toolkit.fluxcd.io -A
NAMESPACE                                                  NAME                                   READY   STATUS                                                           AGE
flux-system                                                azure-service-operator-flux            True    Applied revision: eng/a5efba86dd38b9e87ac97e8bb24e7a048654479b   13m
flux-system                                                cert-manager                           True    Applied revision: eng/6197cf7b208183b922bfaf2a4c2abbfd084a69f8   14m
flux-system                                                core-platform-aks-aad-pod-identity     True    Applied revision: eng/eda43356784e217d76deebb580b4d72ef1c68e3f   16m
flux-system                                                core-platform-aks-external-dns         True    Applied revision: eng/3313fca75c07217fcda882156576b9ee8e9e2066   15m
flux-system                                                core-platform-aks-ingress              True    Applied revision: eng/08cfae4572b24fa368da70e5ae13ae6725a17614   15m
flux-system                                                core-platform-aks-kube-enforcer        True    Applied revision: eng/be7af4986b958489d8aecafb6e8be620b93623bf   14m
flux-system                                                core-platform-aks-kube-state-metrics   False   kustomize build failed: map[string]interface {}(nil): yaml: unmarshal errors:
  line 47: mapping key "name" already defined at line 39   16m
flux-system                                                core-platform-aks-kured                False   kustomization path not found: stat /tmp/core-platform-aks-kured617959812/kustomize/eng/canadacentral/e-eng-ccoe-sm-aks-aks-cac-1: no such file or directory   16m
flux-system                                                core-platform-aks-network-policy       False   apply failed: error: no objects passed to apply
                                                           14m
flux-system                                                core-platform-aks-rbac                 True    Applied revision: master/429ef45c1c1a7e5d017c222f7e9c9f2f3af67aba                                                                                             16m
flux-system                                                core-platform-flux                     True    Applied revision: eng/3dcd3adfd1820e5ba8fa234d45d89e0701dfa1a7                                                                                                12m
flux-system                                                fluent-bit-azure-storage-flux          True    Applied revision: eng/7b7e4d1004e669dd0073a3ee8f155aa6d091a595                                                                                                12m
flux-system                                                kyvos-config                           True    Applied revision: master/a265eb4123d6588109d1f2b957786ee87093b92b                                                                                             14m
flux-system                                                opa-gatekeeper-flux                    True    Applied revision: eng/b939d1a2300cb71204bf69881573141319ac9dbf                                                                                                12m
flux-system                                                rbc-aks-labels-operator-flux           True    Applied revision: eng/ff273582878b1756d9f28d40f16c5a574e2d586a                                                                                                12m
flux-system                                                rbc-k8s-operator-flux                  True    Applied revision: eng/686f267381de8b50aa46916943543150e0e8ff0e
```


## Configuration
Flux exposes a number of configurations which must be set at deployment time for the Flux operator. In the `conf` subdirectory, you can create a configuration file that specifies how Flux should behave on a per-repository basis. This is useful if there are repositories that require no manifest generation (pure manifests that must be applied to a cluster) or if per-cluster configuration is not required and becomes burdensome for a particular set of manifests. Each value is a Bash-compatible shell variable that will be sourced if the conf file exists for a particular repo.

Supported configuration variables:

| Name | Description | CLI argument | Default Value |
|------|-------------|----------------|---------------|
| FLUX_GIT_PATH | Relative path in the target repo to execute manifest generation or apply manifests from. | `--git-path` | `kustomize/${ENVIRONMENT}/${LOCATION}/${AKS_NAME}` |
| FLUX_GIT_BRANCH | The git branch or tag for Flux to clone & sychronize from the target repo. | `--git-branch` | `master` |

## Reference Documentation
- [How to bootstrap Flux using Kustomize](https://fluxcd.io/docs/installation/)
- [Using a private Git host](https://docs.fluxcd.io/en/latest/guides/use-private-git-host.html)
- [Providing your own SSH key](https://docs.fluxcd.io/en/stable/guides/provide-own-ssh-key.html)
- [Migrate from v1 to v2](https://fluxcd.io/docs/migration/flux-v1-migration/)
