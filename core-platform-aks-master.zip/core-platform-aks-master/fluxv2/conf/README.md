# Valid Config Values

`FLUX_GIT_ORG` Github Organization, example `AEO0`

`FLUX_GIT_PATH` kustomize start path, example `kustomize/${ENVIRONMENT}/${LOCATION}`

`FLUX_GIT_BRANCH` The branch which manifests will be applied from, it can be branch name, such as master, or `"<ServiceTier>"` if we have multi branch deployment

`FLUX_SOURCE_INTERVAL` The interval at which to check for repository updates, default is 5m

`FLUX_KUSTOMIZE_INTERVAL` The interval at which to reconcile the Kustomization, default is 5m

`FLUX_PRUNE` Prunes objects removed from source (garbage collection), default false. If true, when the kustomize crd get removed, the relative applied resources will be terminated
