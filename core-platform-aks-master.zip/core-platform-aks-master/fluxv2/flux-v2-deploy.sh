#!/usr/bin/env bash
# Install Flux GitOps operator onto a cluster
set -o errexit
set -o pipefail
set -o nounset

source "../common.sh"

function usage() {
    echo """Usage: This script will Deploy the Flux GitOps resources on AKS clusters
    Pre-Requisites:
        - azure-cli
        - kubectl
        - kustomize
    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

GIT_BRANCH=${GIT_BRANCH:-$(git branch | grep \* | cut -d ' ' -f2)}
GIT_COMMIT=${GIT_COMMIT:-$(git rev-parse HEAD)}
BUILD_NUMBER=${BUILD_NUMBER:-"1"}

export GH_USER="PAEO0SRVGITOPS"
export GH_EMAIL="PAEO0SRVGITOPS@users.noreply.rbcgithub.fg.rbc.com"

# Set subscription
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

# Allow per-repo settings to override defaults
if [ -f conf/${FLUX_CONFIG_FILE}.conf ]; then
    source conf/${FLUX_CONFIG_FILE}.conf
fi

FLUX_GIT_ORG=${FLUX_GIT_ORG:-"AEO0"}
GH_REPO_NAME=${GH_REPO_NAME:-"${FLUX_CONFIG_FILE}"}
FLUX_GIT_PATH=${FLUX_GIT_PATH:-"kustomize/${ENVIRONMENT}/${LOCATION}/${AKS_NAME}"}
FLUX_GIT_BRANCH=${FLUX_GIT_BRANCH:-"master"}
# Set kustomization name. Required since we have one repo for multiple clusters(kustomizations)
FLUX_KUSTOMIZATION_NAME=${FLUX_KUSTOMIZATION_NAME:-"${GH_REPO_NAME}"}
FLUX_NAMESPACE="flux-system"

edumpvar FLUX_GIT_PATH FLUX_GIT_BRANCH FLUX_GIT_ORG FLUX_KUSTOMIZATION_NAME FLUX_NAMESPACE GH_REPO_NAME

# Set Interval for source controller
if [ -v FLUX_SOURCE_INTERVAL ]; then
  echo "Setting custom poll interval for source controller"
else
  export FLUX_SOURCE_INTERVAL="5m"
fi

# Set Interval for kustomize controller
if [ -v FLUX_KUSTOMIZE_INTERVAL ]; then
  echo "Setting custom poll interval for kustomize controller"
else
  export FLUX_KUSTOMIZE_INTERVAL="5m"
fi

# Prunes objects removed from source (garbage collection), default false: does not terminate the resources deployed
if [ -v FLUX_PRUNE ]; then
  echo "Setting ${FLUX_PRUNE} for prune"
else
  export FLUX_PRUNE="false"
fi

# if the FLUX_GIT_BRANCH has this place-holder then replace it with
# prod service trier always pulls from master
# eng pulls form eng branch
# nonp pulls from nonp branch
if [ ${FLUX_GIT_BRANCH} == "<ServiceTier>" ]; then
  if [ ${ENVIRONMENT} == "prod" ]; then
    einfo "Regular flux deployment"
    FLUX_GIT_BRANCH="master"
  else
     einfo "Branch based deployment pointing to ${ENVIRONMENT} branch"
     FLUX_GIT_BRANCH=${ENVIRONMENT}
  fi
fi

# Setting the directory netpols should be deployed from ${ENVIRONMENT}/${APPNAME}, APPNAME set in cluster config file
if [ ${FLUX_GIT_PATH} == "<APPNAME>" ]; then
  if [ ${GH_REPO_NAME} == "core-platform-aks-network-policy" ]; then
    einfo "Apply netpols from ${APPNAME} dir"
    FLUX_GIT_PATH="kustomize/${ENVIRONMENT}/${APPNAME}"
  # add more repo names if need using APPNAME in its directory structure
  fi
fi

einfo "Generating source and kustomization manifests"
mkdir -p conf/${GH_REPO_NAME}
cat > conf/${GH_REPO_NAME}/flux-resource.yaml <<EOF
apiVersion: source.toolkit.fluxcd.io/v1beta1
kind: GitRepository
metadata:
  name: ${GH_REPO_NAME}
  namespace: ${FLUX_NAMESPACE}
spec:
  interval: ${FLUX_SOURCE_INTERVAL}
  url: "ssh://rbcgithub.fg.rbc.com/${FLUX_GIT_ORG}/${GH_REPO_NAME}.git"
  ref:
    branch: ${FLUX_GIT_BRANCH}
  secretRef:
    name: ssh-credentials
---
apiVersion: kustomize.toolkit.fluxcd.io/v1beta1
kind: Kustomization
metadata:
  name: ${FLUX_KUSTOMIZATION_NAME}
  namespace: ${FLUX_NAMESPACE}
spec:
  interval: ${FLUX_KUSTOMIZE_INTERVAL}
  path: ${FLUX_GIT_PATH}
  prune: ${FLUX_PRUNE}
  sourceRef:
    kind: GitRepository
    name: ${GH_REPO_NAME}
EOF

einfo "Apply new Flux resource called ${FLUX_KUSTOMIZATION_NAME} for ${GH_REPO_NAME} repo"
kubectl apply -f conf/${GH_REPO_NAME}/flux-resource.yaml --force --request-timeout=360s --wait
