#!/usr/bin/env bash
# Download Flux GitOps operator configurations
set -o errexit
set -o pipefail
set -o nounset

FLUX_VERSION="v0.17.1"

source "../common.sh"

function usage() {
    echo """Usage: This script will download the Flux GitOps base configurations via a Git sparse checkout.
    These configurations should act as the Kustomize base resources which further customization can be applied.
    """
    exit 1
}

check_prereq "git"
check_prereq "kustomize"

einfo "Performing sparse checkout & shallow clone of github.com/fluxcd/flux (release ${FLUX_VERSION})"
git init .tmp_flux_clone
cd .tmp_flux_clone
git remote add origin https://github.com/fluxcd/flux2.git
git config core.sparsecheckout true
echo "manifests/bases/kustomize-controller/*" >> .git/info/sparse-checkout
echo "manifests/bases/source-controller/*" >> .git/info/sparse-checkout
git pull --depth=1 origin ${FLUX_VERSION}
cd ..
mv .tmp_flux_clone/manifests/bases/* base/
rm -rf .tmp_flux_clone
