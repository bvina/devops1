#!/usr/bin/env bash
# Install Flux GitOps operator onto a cluster
set -o errexit
set -o pipefail
set -o nounset

source "../common.sh"

function usage() {
    echo """Usage: This script will install the Flux GitOps operator on AKS clusters

    Pre-Requisites:
        - azure-cli
        - kubectl
        - kustomize

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

GIT_BRANCH=${GIT_BRANCH:-$(git branch | grep \* | cut -d ' ' -f2)}
GIT_COMMIT=${GIT_COMMIT:-$(git rev-parse HEAD)}

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

GIT_BRANCH=${GIT_BRANCH} \
GIT_COMMIT=${GIT_COMMIT} \
BUILD_NUMBER=${BUILD_NUMBER:-"1"} \
SERVICE_TIER=${ENVIRONMENT} \

einfo "Obtain SSH private key for GitHub access from AKV"
if [ ! -f base/rbac/files/identity ]; then
  az keyvault secret download --file base/rbac/files/identity \
    --name flux-github-ssh-key \
    --vault-name ${KV_NAME}
fi

FLUX_NAMESPACE="flux-system"
einfo "Creating namespace"
kubectl create namespace ${FLUX_NAMESPACE} -o yaml --dry-run=client | \
    kubectl label --local --dry-run=client -o yaml -f - \
    app=azureoperator \
    cloud.rbc.com/AppCode="KYV0" \
    cloud.rbc.com/TransitCode="09812" \
    cloud.rbc.com/DataClassification="internal" \
    cloud.rbc.com/Compliance="" \
    cloud.rbc.com/Portfolio="ccoe" | kubectl apply --request-timeout=360s --wait -f -

einfo "Create ssh credential"
kubectl --namespace ${FLUX_NAMESPACE} \
    create secret generic ssh-credentials \
    --from-file=base/rbac/files/identity \
    --from-file=base/rbac/files/known_hosts \
    --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -

einfo "Apply new Flux deployment"
kustomize build overlays/${ENVIRONMENT}/${LOCATION} | kubectl apply --force --request-timeout=360s --wait -f -
