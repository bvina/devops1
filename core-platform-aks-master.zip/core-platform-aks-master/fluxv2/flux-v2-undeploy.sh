#!/usr/bin/env bash
# Install Flux GitOps operator onto a cluster
set -o errexit
set -o pipefail
set -o nounset

source "../common.sh"

function usage() {
    echo """Usage: This script will Un-Deploy the Flux GitOps resources on AKS clusters

    Pre-Requisites:
        - azure-cli
        - kubectl

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
check_prereq "kubectl"
validate_conf_file $@

if [ -f conf/${FLUX_CONFIG_FILE}.conf ]; then
    source conf/${FLUX_CONFIG_FILE}.conf
fi

GH_REPO_NAME=${FLUX_CONFIG_FILE}
FLUX_KUSTOMIZATION_NAME=${FLUX_KUSTOMIZATION_NAME:-"${GH_REPO_NAME}"}
FLUX_NAMESPACE="flux-system"

edumpvar FLUX_KUSTOMIZATION_NAME FLUX_NAMESPACE GH_REPO_NAME

# Set subscription
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

einfo "Remove git repository and kustomization called ${FLUX_KUSTOMIZATION_NAME} for ${GH_REPO_NAME} repo if exist"
kubectl delete gitrepositories ${FLUX_KUSTOMIZATION_NAME} -n ${FLUX_NAMESPACE} --force 2>/dev/null || true
kubectl delete kustomizations ${FLUX_KUSTOMIZATION_NAME} -n ${FLUX_NAMESPACE} --force 2>/dev/null || true

