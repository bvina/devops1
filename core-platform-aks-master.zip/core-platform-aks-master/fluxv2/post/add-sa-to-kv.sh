#!/usr/bin/env bash
# Add Service Accounts token managed by Flux to AKV.
# The tokens are used by core-api-server to submit K8s manifests
# to other clusters during onboarding and deployments.
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will add Service Accounts managed by Flux to AKV
    Pre-Requisites:
        - Must be logged in to Azure run az login
    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}
check_prereq "az"
check_prereq "kubectl"

validate_conf_file $@
einfo "START $0"

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

# How long to wait in seconds for the Service Account Token to get created.
SA_TIMEOUT=600
# How long to wait in seconds between checks for the SA
SLEEP_INTERVAL=30

[[ $AKS_NAME =~ ([^-]+)-([^-]+) ]]
TIER=${BASH_REMATCH[1]}
ENV=${BASH_REMATCH[2]}
KV_NAME="${TIER}${ENV}ccoecascac1"

einfo "Checking if the SA exists..."
while ! kubectl -n platform-rbac get sa api-server -o jsonpath='{.secrets[0].name}' > /dev/null; do
    SA_TIMEOUT=$((SA_TIMEOUT-$SLEEP_INTERVAL))
    if (($SA_TIMEOUT <= 0)); then
        eerror "Timed out waiting for Service Account to be created..."
        exit 1
    fi
    einfo "Sleeping ${SLEEP_INTERVAL}s..."
    sleep $SLEEP_INTERVAL
done

einfo "Getting SA Token"
API_SERVER_TOKEN=$(kubectl -n platform-rbac get secret $(kubectl -n platform-rbac get sa api-server -o jsonpath='{.secrets[0].name}') -o jsonpath='{.data.token}' | python3 -c 'import sys;import base64;print(base64.b64decode(bytes(sys.stdin.read(), "utf-8")).decode())')

einfo "Adding SA Token to KV"
az keyvault secret set --vault-name ${KV_NAME} \
    --name "${AKS_NAME}-api-server-sa-token" \
    --value "${API_SERVER_TOKEN}" \
    --expires $(python3 -c 'import datetime as dt;print((dt.datetime.now() + dt.timedelta(days=90)).strftime("%Y-%m-%dT%H:%M:%SZ"))') \
    --tags "aks=${AKS_NAME}" type=token \
    --description "JWT for Kubernetes ServiceAccount platform:api-server" > /dev/null

einfo "END $0"
