#!/usr/bin/env bash
# Checks if flux operators are up and running
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will Checks if flux operators are up and running
    Pre-Requisites:
        - Must be logged in to Azure run az login
    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}
check_prereq "az"
check_prereq "kubectl"

SUBSCRIPTION_ID=$1
RESOURCE_GROUP=$2
AKS_NAME=$3
einfo "START $0"

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

# Check if the core applications are running, the list of namespaces , namespace_list, we need to check the pods in them
get_pods_status() {
    IFS=',' read -r -a namespace_list <<< "$1"
    pods_not_running_all=""
    for ns in "${namespace_list[@]}" ; do
        if [[ "$(kubectl get ns ${ns} 2>/dev/null)" ]]; then
            einfo "checking namespace ${ns} in cluster ${AKS_NAME}"
            pods_not_running="$(kubectl get pods -n ${ns} | grep -v "Run\|Completed" | sed -n '1!p')"
            pods_not_running_all="${pods_not_running_all}${pods_not_running}"
        else
          einfo "${ns} doesn't exist in cluster ${AKS_NAME}"
        fi
    done
}

print_pods_status() {
    IFS=', ' read -r -a namespace_list <<< "$1"
    for ns in "${namespace_list[@]}" ; do
        if [[ "$(kubectl get ns ${ns} 2>/dev/null)" ]]; then
            einfo "NAMESPACE: ${ns}"
            kubectl get pods -n ${ns} | grep -v "Run\|Completed" | awk '{ print $1, $3}' | sed -n '1!p'
        fi
    done
}

COUNTER=0
while [ $COUNTER -lt 5 ]; do
    get_pods_status $4
    if [ "${pods_not_running_all}" == "" ]; then
        einfo "All core pods are running, continue the pipeline"
        break
    else
        einfo "All core pods are not running, already slept ${COUNTER} min --------- "
        print_pods_status $4
        sleep 60s
    fi
    COUNTER=$((COUNTER + 1))
    if [ "$COUNTER" == 5 ]; then
        einfo "Core Pods Verification Failed after ${COUNTER} min"
        exit 1
    fi
done

einfo "END $0"
