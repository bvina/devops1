#!/usr/bin/env bash
# Checks if flux operators are up and running
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will Checks if flux operators are up and running
    Pre-Requisites:
        - Must be logged in to Azure run az login
    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}
check_prereq "az"
check_prereq "kubectl"

validate_conf_file $@
einfo "START $0"

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

# Check if Flux operators are running
COUNTER=0
while [ $COUNTER -lt 21 ]; do
    FLUX_STATUS=$(kubectl get pods --all-namespaces -l name=flux | grep -v Run | awk '{print $4}' | sed -n '1!p')
    if [ "${FLUX_STATUS}" == "" ]; then
        einfo "All operators are running, continue the pipeline"
        break
    else
        einfo "All operators are not running, already slept ${COUNTER} min --------- "
        kubectl get pods --all-namespaces -l name=flux | grep -v Run
        sleep 60s
    fi
    let COUNTER=COUNTER+1
    if [ $COUNTER == 21 ]; then
        einfo "Flux Operator Verification Failed after ${COUNTER} min"
        exit 1
    fi
done

# Sleep for min to let the flux operator to deploy resources
einfo "Sleep for two min to let the flux operators deploy resources"
sleep 120s

# Check if the core applications are running, the list of namespaces , namespace_list, we need to check the pods in them
get_pods_status() {
    namespace_list=("external-dns" "ingress" "aad-pod-identity" "azureoperator-system" "rbc-system" "kyv0-log-retention" "gatekeeper-system")
    pods_not_running_all=""
    for ns in ${namespace_list[@]} ; do
        if [[ "$(kubectl get ns ${ns} 2>/dev/null)" ]]; then
            pods_not_running="$(kubectl get pods -n ${ns} | grep -v "Run\|Completed" | awk '{print $4}' | sed -n '1!p')"
            pods_not_running_all="${pods_not_running_all}${pods_not_running}"
        fi
    done
}

print_pods_status() {
    namespace_list=("external-dns" "ingress" "aad-pod-identity" "azureoperator-system" "rbc-system" "kyv0-log-retention" "gatekeeper-system")
    for ns in ${namespace_list[@]} ; do
        if [[ "$(kubectl get ns ${ns} 2>/dev/null)" ]]; then
            einfo "NAMESPACE: ${ns}"
            kubectl get pods -n ${ns} | grep -v "Run\|Completed" | awk '{ print $1, $3}' | sed -n '1!p'
        fi
    done
}

COUNTER=0
while [ $COUNTER -lt 21 ]; do
    get_pods_status
    if [ "${pods_not_running_all}" == "" ]; then
        einfo "All core pods are running, continue the pipeline"
        break
    else
        einfo "All core pods are not running, already slept ${COUNTER} min --------- "
        print_pods_status
        sleep 60s
    fi
    let COUNTER=COUNTER+1
    if [ $COUNTER == 21 ]; then
        einfo "Core Pods Verification Failed after ${COUNTER} min"
        exit 1
    fi
done

# Check for gatekeeper's 'check-ignore-label' validating webhook availability
# This VWH needs to be in fail-closed state and thus can block the matching operations (namespace create and update) if not available
echo "Waiting for gatekeeper webhook to be ready..."
for i in {0..21}; do
  if kubectl label ns default wait-for-gatekeeper=ready >/dev/null 2>&1; then
    kubectl label ns default wait-for-gatekeeper- >/dev/null 2>&1
    break
  fi
  einfo "Gatekeeper webhook not ready, already slept ${i} min --------- "
  sleep 60s
done

einfo "END $0"
