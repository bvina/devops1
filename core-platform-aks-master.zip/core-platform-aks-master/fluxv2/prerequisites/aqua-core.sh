#!/usr/bin/env bash
# Generate a kubernetes secret from Key Vault data for Aqua web and gateway
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will create ========================================

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

# Getting DB Password from vault
AQUA_DB_PWD=`az keyvault secret show --vault-name ${AQUA_KV_NAME} --name ${AQUA_DB_PWD_KV_SECRET} --query value -o tsv`
CONSOLE_USER_PWD=`az keyvault secret show --vault-name ${AQUA_KV_NAME} --name ${CONSOLE_USER_KV_SECRET}  --query value -o tsv`
SCANNER_USER_PWD=`az keyvault secret show --vault-name ${AQUA_KV_NAME} --name ${SCANNER_USER_KV_SECRET}  --query value -o tsv`

# Aqua namespace creation
kubectl create namespace ${AQUA_NAMESPACE} -o yaml --dry-run=client | kubectl apply --force --request-timeout=360s --wait -f -

# Aqua secret generation for OPS and AUDIT db password used by 'gateway' and 'web' deployments
einfo "Configuring the secret 'aqua-db-ops-audit' for the ops and audit database password"
kubectl create secret generic aqua-db-ops-audit --namespace=${AQUA_NAMESPACE} \
    --from-literal=SCALOCK_DBPASSWORD=${AQUA_DB_PWD} \
    --from-literal=AQUA_PUBSUB_DBPASSWORD=${AQUA_DB_PWD} \
    --from-literal=SCALOCK_AUDIT_DBPASSWORD=${AQUA_DB_PWD} \
    --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -

# Aqua secret generation for scanner password used by 'scanner' deployments
einfo "Configuring the secret 'aqua-scanner-pwd'"
kubectl create secret generic aqua-scanner-pwd --namespace=${AQUA_NAMESPACE} \
    --from-literal=aqua-scanner-pwd=${SCANNER_USER_PWD} \
    --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -

# Aqua secret generation for console password
einfo "Configuring the secret 'aqua-admin-pwd'"
kubectl create secret generic aqua-admin-pwd --namespace=${AQUA_NAMESPACE} \
    --from-literal=ADMIN_PASSWORD=${CONSOLE_USER_PWD} \
    --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -
