#!/usr/bin/env bash
# Insert Secrests for Azure-service operator before flux
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will create nessary service principals as k8s secret from pulling
    Pre-Requisites:
        - Must be logged in to Azure run az login
    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "az"
validate_conf_file $@


einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

AZURE_OPERATOR_NS=azureoperator-system

einfo "Creating ${AZURE_OPERATOR_NS} namespace"
kubectl create namespace ${AZURE_OPERATOR_NS} -o yaml --dry-run=client | \
    kubectl label --local --dry-run=client -o yaml -f - \
    app=azureoperator \
    cloud.rbc.com/AppCode="KYV0" \
    cloud.rbc.com/TransitCode="09812" \
    cloud.rbc.com/DataClassification="internal" \
    cloud.rbc.com/Compliance="" \
    cloud.rbc.com/Portfolio="ccoe" \
    control-plane="controller-manager"| kubectl apply --request-timeout=360s --wait -f -

# Create a secret
kubectl --namespace ${AZURE_OPERATOR_NS} \
    create secret generic azureoperatorsettings \
    --from-literal=AZURE_USE_MI=1 \
    --from-literal=AZURE_SUBSCRIPTION_ID=${SUBSCRIPTION_ID} \
    --from-literal=AZURE_SECRET_NAMING_VERSION=1 \
    --from-literal=AZURE_TENANT_ID=$(az account show --query "tenantId" -o tsv) --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -

einfo "END $0"
