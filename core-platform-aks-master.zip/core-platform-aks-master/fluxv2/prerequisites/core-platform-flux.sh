#!/usr/bin/env bash
# Generate a kubernetes secret from Key Vault data
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will create ingress objects for Kyvos Network Utility

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

# Generate Kustomize configuration on the fly to avoid manual creation
einfo "Generate Kustomize configuration. aks:${AKS_NAME}"
mkdir -p core-platform-flux/kustomize/clusters/${AKS_NAME}/kyvos-network-utility
touch core-platform-flux/kustomize/clusters/${AKS_NAME}/kustomization.yaml

### Ex. RESOURCE_GROUP="e-eng-ccoe-diagnostic-aks-rg-cac-1"
### RG naming convention: {service_tier_short}-{service_tier}-{portfolio}-{component}-aks-rg-{region}-{id}
### Since we captured everything after "app" as one group we simply dump BASH_REMATCH[7] which includes both {locationShort} and {numberIdentifier}
[[ $RESOURCE_GROUP =~ ([^-]+)-([^-]+)-([^-]+)-([^-]+)-([^-]+)-([^-]+)-(.+) ]]
AKS_ID="${BASH_REMATCH[4]}-${BASH_REMATCH[7]}"
einfo "AKS ID: ${AKS_ID}"

einfo "Generate Controller Service file:"
cat << EOF > core-platform-flux/kustomize/clusters/${AKS_NAME}/kyvos-network-utility/patch-kyvos-network-util-ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: kyvos-network-utility-ingress
  namespace: kyvos-network-utility
spec:
  tls:
  - hosts:
    - 'kyvos-network-utility-${AKS_ID}.${LOCATION}.aks.${ENVIRONMENT}.c1.rbc.com'
  rules:
  - host: 'kyvos-network-utility-${AKS_ID}.${LOCATION}.aks.${ENVIRONMENT}.c1.rbc.com'
    http:
      paths:
      - path: /(.*)
        pathType: ImplementationSpecific
        backend:
          service:
            name: kyvos-network-utility-service
            port: 
              number: 80    
EOF

einfo "Adding new resources and pushing to github"
(
  cd core-platform-flux/kustomize/clusters/${AKS_NAME}/
  kustomize edit add resource ../../${ENVIRONMENT}/${LOCATION}/ ;
  kustomize edit add patch --path kyvos-network-utility/patch-kyvos-network-util-ingress.yaml
  git add kyvos-network-utility/patch-kyvos-network-util-ingress.yaml
  git add kustomization.yaml
  git commit -m "[Flux Commit] Added Kyvos Network Utility Ingress for cluster ${AKS_NAME}" || echo \"nothing to commit\"

  # if the FLUX_GIT_BRANCH has this place-holder then replace it with
  # prod service trier always pulls from master
  # eng pulls form eng branch
  # nonp pulls from nonp branch
  if [ ${ENVIRONMENT} == "prod" ]; then
    GIT_BRANCH="master"
  else
    GIT_BRANCH=${ENVIRONMENT}
  fi
  # GIT_BRANCH=$(git branch | grep \* | cut -d ' ' -f2)
  git push origin HEAD:$GIT_BRANCH
)