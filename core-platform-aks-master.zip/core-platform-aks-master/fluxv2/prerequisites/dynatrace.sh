#!/usr/bin/env bash
# Apply Splunk Connect for Kubernetes manifests to AKS cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will apply Splunk manifests for AKS clusters

    Pre-Requisites:
        - Must be logged in to Azure run az login
        - Helm v3.0 or greater

    Arguments:
        - AKS cluster conf file holding all the variables for this deployment
        - Rollout Override flag (yes/no)
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
check_prereq "helm"
validate_conf_file $@

einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

einfo "Create 'dynatrace' namespace"
kubectl create namespace dynatrace --dry-run=client -o yaml | \
   kubectl label --local --dry-run=client -o yaml -f - \
    cloud.rbc.com/PlatformManaged="true" \
    cloud.rbc.com/AppCode=KYV0 \
    cloud.rbc.com/TransitCode="09812" \
    cloud.rbc.com/DataClassification="internal" \
    cloud.rbc.com/Compliance="" \
    cloud.rbc.com/ServiceTier="${SERVICE_TIER}" \
    cloud.rbc.com/Location="${LOCATION}" \
    cloud.rbc.com/Portfolio="ccoe" | kubectl apply -f -

einfo "Create the required secret for Dynatrace DaemonSet"
API_TOKEN=`az keyvault secret show --vault-name ${OPERATOR_KV_NAME} --name dynatraceApiToken --query value -o tsv`
PAAS_TOKEN=`az keyvault secret show --vault-name ${OPERATOR_KV_NAME} --name dynatracePassToken --query value -o tsv`
kubectl -n dynatrace create secret generic oneagent --from-literal=apiToken=$API_TOKEN --from-literal=paasToken=$PAAS_TOKEN \
 --dry-run=client -o yaml | kubectl apply -f -

einfo "END $0"
