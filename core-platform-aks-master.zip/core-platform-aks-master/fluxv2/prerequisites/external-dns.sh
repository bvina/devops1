#!/usr/bin/env bash
# Generate a kubernetes secret from Key Vault data
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will create nessary service principals as k8s secret from pulling

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription "${SUBSCRIPTION_ID}"

# Login by Admin SP
aks_login_admin_sp $@

TENANT_ID=`az account show --query tenantId -o tsv`

NAMESPACE=external-dns
kubectl create namespace ${NAMESPACE} -o yaml --dry-run=client | kubectl apply --force --request-timeout=360s --wait -f -

einfo "Generating azure.json"
cat << EOF > azure.json
{
  "tenantId": "${TENANT_ID}",
  "subscriptionId": "${SS_SUBSCRIPTION_ID}",
  "resourceGroup": "${SS_DNS_RG_NAME}",
  "useManagedIdentityExtension": true
}
EOF

# kubectl create secret generic external-dns --namespace=${NAMESPACE} \
#     --from-literal=AZURE_CLIENT_SECRET=${SECRET} \
#     --from-literal=AZURE_CLIENT_ID=${CLIENT_ID} \
#     --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -

kubectl create secret generic external-dns --namespace=${NAMESPACE} \
    --from-file=azure.json=azure.json \
    --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -

kubectl create configmap cluster-name --namespace=${NAMESPACE} \
    --from-literal=CLUSTER_NAME=${AKS_NAME} --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -
