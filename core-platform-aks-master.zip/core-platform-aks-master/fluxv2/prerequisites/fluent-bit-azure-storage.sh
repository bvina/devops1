#!/usr/bin/env bash
# Create Azure Identiy (User Assigned) required for the rbc-k8s-operator and roles and set up bindings
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will create necessary secret for fluent-bit-pluging to connect to

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

# Collect the variables.
LOGGING_NS=kyv0-log-retention
CONTAINER_NAME=${AKS_NAME}
STORAGE_ACCOUNT_NAME=${RET_STORAGE_ACCOUNT}
NETPOL=overlays/fluent-bit-azure-storage-flux/allow-k8s-apiservr-egress.yaml

# Get all the keys for the storage account
einfo "Fetching storage account keys from Azure"
azStorageAccountKeys=$(az storage account keys list -n ${RET_STORAGE_ACCOUNT}  --subscription ${RET_SUBSCRIPTION_ID} -o json)
# Get the first key
azStorageAccountKey0=$(echo ${azStorageAccountKeys} | jq -r '.[0].value')
einfo "Account key fetched "

end_date=`python -c 'from datetime import timedelta, date; print(date.today() + timedelta(days=90))'`

einfo "SAS key Expires on ${end_date}"

# Generate SAS token that prevents delete/read/list containers + operations only on Blob + resource types only on Containers and Objects + HTTPS_ONLY
sasToken=$(az storage account generate-sas --https-only --permissions acuw --resource-types co --services b --account-name ${RET_STORAGE_ACCOUNT} --expiry ${end_date} --subscription ${RET_SUBSCRIPTION_ID} --account-key ${azStorageAccountKey0})

einfo "Creating Name space"
kubectl create ns ${LOGGING_NS} --dry-run=client -o yaml | kubectl apply -f -

einfo "Creating Secret"
kubectl -n ${LOGGING_NS} create secret generic azure-storage-properties --from-literal=AZURE_STORAGE_ACCOUNT_NAME=${RET_STORAGE_ACCOUNT} \
--from-literal=AZURE_STORAGE_ACCOUNT_KEY=${sasToken} \
--from-literal=AZURE_BLOB_CONTAINER_NAME=${AKS_NAME} --dry-run=client -o yaml | kubectl apply -f -


## Apply Allow aks Network Policy
managed_rg=${RESOURCE_GROUP}-managed
export nic_id=$(az resource show --resource-group ${managed_rg} --name 'kube-apiserver' --resource-type 'Microsoft.Network/privateEndpoints' | jq -r '.properties.networkInterfaces[].id')
echo "nic_id: ${nic_id}"

if [[ ${nic_id} == "" ]]; then
    einfo "Could not find resource named 'kube-apiserver' of resource type 'Microsoft.Network/privateEndpoints' as part of RG '${managed_rg}'"
    exit 1
else
    export private_ip=$(az network nic show --ids $nic_id | jq -r '.ipConfigurations[].privateIpAddress')
fi
echo "private_ip: ${private_ip}"

echo "updating: allow-k8s-apiserver-egress.yaml"
mkdir -p conf/fluent-bit-azure-storage-flux
cat << EOF > conf/fluent-bit-azure-storage-flux/allow-k8s-apiserver-egress.yaml
kind: NetworkPolicy
apiVersion: networking.k8s.io/v1
metadata:
  name: allow-k8s-apiserver-egress
  namespace: ${LOGGING_NS}
spec:
  policyTypes:
  - Egress
  podSelector: {}
  egress:
  - to:
    - ipBlock:
        cidr: ${private_ip}/32
    ports:
    - port: 443
      protocol: TCP
EOF

einfo "Apply netpol allow-k8s-apiserver-egress.yaml"
kubectl apply -f conf/fluent-bit-azure-storage-flux/allow-k8s-apiserver-egress.yaml

einfo "END $0"
