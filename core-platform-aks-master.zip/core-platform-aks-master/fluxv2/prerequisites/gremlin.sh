#!/usr/bin/env bash
# Apply Gremlin secret manifests for Kubernetes manifests to AKS cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will apply Gremlin manifests for AKS clusters

    Pre-Requisites:
        - Must be logged in to Azure run az login
        - Helm v3.0 or greater

    Arguments:
        - AKS cluster conf file holding all the variables for this deployment
        - 'GREMLIN_TEAM_SECRET' - Obtained from the operator AKV
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
check_prereq "helm"
validate_conf_file $@

einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

einfo "Create 'gremlin' namespace"
kubectl create namespace gremlin --dry-run=client -o yaml | \
   kubectl label --local --dry-run=client -o yaml -f - \
    cloud.rbc.com/PlatformManaged="true" \
    cloud.rbc.com/AppCode=KYV0 \
    cloud.rbc.com/TransitCode="09812" \
    cloud.rbc.com/DataClassification="internal" \
    cloud.rbc.com/Compliance="" \
    cloud.rbc.com/ServiceTier="${SERVICE_TIER}" \
    cloud.rbc.com/Location="${LOCATION}" \
    cloud.rbc.com/Portfolio="ccoe" | kubectl apply -f -

einfo "Create the required secret for Gremlin DaemonSet"
GREMLIN_TEAM_SECRET=`az keyvault secret show --vault-name ${OPERATOR_KV_NAME} --name gremlinTeamSecret --query value -o tsv`
kubectl -n gremlin create secret generic gremlin-conf \
    --from-literal=GREMLIN_CLUSTER_ID="$AKS_NAME"  \
    --from-literal=GREMLIN_TEAM_SECRET="$GREMLIN_TEAM_SECRET" \
    --from-literal=GREMLIN_TEAM_ID="90f55029-2096-4649-b550-292096164947" \
    --dry-run=client -o yaml | kubectl apply -f -

einfo "END $0"
