#!/usr/bin/env bash
# Apply Ingress Controller Kubernetes manifests to AKS cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will install certs as secrets for ingress & push loadbalancer IP as patch.
    Pre-Requisites:
        - Must be logged in to Azure run az login
    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

GIT_BRANCH=${GIT_BRANCH:-$(git branch | grep \* | cut -d ' ' -f2)}
GIT_COMMIT=${GIT_COMMIT:-$(git rev-parse HEAD)}
BUILD_NUMBER=${BUILD_NUMBER:-"1"}

# Allow per-repo settings to override defaults
if [ -f conf/${FLUX_CONFIG_FILE}.conf ]; then
    source conf/${FLUX_CONFIG_FILE}.conf
fi

# Constants
certPath="../platform_certs/${ENVIRONMENT}/ingress"
certFile="${certPath}/aks.${ENVIRONMENT}.c1.rbc.com.cer"
keyName=${ENVIRONMENT}"-aks-ingress-tls-key"
keyFile="${certPath}/${keyName}.key"

if [[ ! -f "$keyFile"  || ! -f  "$certFile" ]]; then
einfo "invoking script for preparing certs installation."
  eerror "ERROR: Either Key(${keyFile}) and Cert(${certFile}) are not present for installation as secrets."
  exit 1
fi

CERT_SECRET_NAME="aks-ingress-tls"
RESOURCE_APP_CODE=${RESOURCE_APP_CODE:-"kyv0"}

# set namespace
if [ ${RESOURCE_APP_CODE} == "kyv0" ]; then
  export INGRESS_NAMESPACE="ingress"
else
  export INGRESS_NAMESPACE="ingress-"${RESOURCE_APP_CODE}
fi

# get the ip
for i in $(echo "${INGRESS_IP}" | jq -c '.[]'); do
    _jq() {
        echo ${i} | jq -r ${1}
    }
    if [ $(_jq '.APP_CODE') == "${RESOURCE_APP_CODE}" ]; then
      export INGRESS_FRONT_IP=$(_jq '.IP')
    fi
done

if [ -z ${INGRESS_FRONT_IP} ]; then
  einfo "You have to set IP in cluster config!" && exit 1
fi

# set service name
if [ ${RESOURCE_APP_CODE} == "kyv0" ]; then
  # default svc name, check ingress repo
  export INGRESS_SVC_NAME="cluster-ingress-nginx-controller"
else
  export INGRESS_SVC_NAME="cluster-ingress-nginx-controller-${RESOURCE_APP_CODE}"
fi

einfo "Creating ${INGRESS_NAMESPACE} namespace:"
kubectl create namespace ${INGRESS_NAMESPACE} -o yaml --dry-run=client | kubectl apply --force --request-timeout=360s --wait -f -

einfo "Creating AKS Nginx Ingress secret '${CERT_SECRET_NAME}'. Namespace: ${INGRESS_NAMESPACE}"
kubectl create secret tls ${CERT_SECRET_NAME} \
          --insecure-skip-tls-verify=true \
          --namespace ${INGRESS_NAMESPACE} \
          --key ${keyFile} \
          --cert ${certFile} \
          --dry-run=client -o yaml  | \
          kubectl apply --insecure-skip-tls-verify="true" --request-timeout=360s --wait -f -

# Generate Kustomize configuration on the fly to avoid manual creation
einfo "Generate Kustomize configuration. aks:${AKS_NAME}"
mkdir -p core-platform-aks-ingress/kustomize/clusters/${AKS_NAME}/${RESOURCE_APP_CODE}/
> core-platform-aks-ingress/kustomize/clusters/${AKS_NAME}/${RESOURCE_APP_CODE}/kustomization.yaml

einfo "Generate Controller Service file:"
cat << EOF > core-platform-aks-ingress/kustomize/clusters/${AKS_NAME}/${RESOURCE_APP_CODE}/patch-loadbalancer-ip.yaml
kind: Service
apiVersion: v1
metadata:
  name: ${INGRESS_SVC_NAME}
  namespace: ${INGRESS_NAMESPACE}
spec:
  loadBalancerIP: ${INGRESS_FRONT_IP}
EOF

einfo "Adding new resources and pushing to github"
cd core-platform-aks-ingress/kustomize/clusters/${AKS_NAME}/${RESOURCE_APP_CODE}/
kustomize edit set namespace ${INGRESS_NAMESPACE}
kustomize edit add resource ../../../${ENVIRONMENT}/${RESOURCE_APP_CODE}/${LOCATION}
kustomize edit add patch --path patch-loadbalancer-ip.yaml
git add patch-loadbalancer-ip.yaml
git add kustomization.yaml
git commit -m "[Flux Commit] Added Load Balancer IP for cluster ${AKS_NAME}" || echo \"nothing to commit\"

# if the FLUX_GIT_BRANCH has this place-holder then replace it with
# prod service trier always pulls from master
# eng pulls form eng branch
# nonp pulls from nonp branch
if [ ${ENVIRONMENT} == "prod" ]; then
  GIT_BRANCH="master"
else
  GIT_BRANCH=${ENVIRONMENT}
fi
git push origin HEAD:$GIT_BRANCH

einfo "END $0"
