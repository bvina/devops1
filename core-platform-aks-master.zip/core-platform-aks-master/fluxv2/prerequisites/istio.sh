#!/usr/bin/env bash
# Apply Ingress Controller Kubernetes manifests to AKS cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script adds internal certs as secret in istio namespace.
    Pre-Requisites:
        - Must be logged in to Azure run az login
    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

GIT_BRANCH=${GIT_BRANCH:-$(git branch | grep \* | cut -d ' ' -f2)}
GIT_COMMIT=${GIT_COMMIT:-$(git rev-parse HEAD)}
BUILD_NUMBER=${BUILD_NUMBER:-"1"}

# certs to be installed as secrets.
BASE_PATH="../platform_certs/${ENVIRONMENT}/ingress"
certfile="${BASE_PATH}/aks.${ENVIRONMENT}.c1.rbc.com.cer"
keyName=${ENVIRONMENT}"-aks-ingress-tls-key"
keyfile="${BASE_PATH}/${keyName}.key"
chainfile="${BASE_PATH}/chain.crt"

if [[ ! -f "$keyfile"  || ! -f  "$chainfile" ]]; then
einfo "invoking script for preparing certs installation."
  eerror "ERROR: Either Key(${keyfile}) and Cert(${chainfile}) are not present for installation as secrets."
  exit 1
fi

CERT_SECRET_NAME="aks-ingress-tls"
ISTIO_NAMESPACE=${ISTIO_NAMESPACE:-"istio-system"}

einfo "Creating ${ISTIO_NAMESPACE} namespace:"
kubectl create namespace ${ISTIO_NAMESPACE} -o yaml --dry-run=client | kubectl apply --force --request-timeout=360s --wait -f -

einfo "Creating dafault AKS secret '${CERT_SECRET_NAME}'. Namespace: ${ISTIO_NAMESPACE}"
kubectl create secret tls ${CERT_SECRET_NAME} \
          --insecure-skip-tls-verify=true \
          --namespace ${ISTIO_NAMESPACE} \
          --key ${keyfile} \
          --cert ${chainfile} \
          --dry-run=client -o yaml  | \
          kubectl apply --insecure-skip-tls-verify="true" --request-timeout=360s --wait -f -

# setting up istio self-signed cacerts.
ISTIO_ROOT_CERT_SECRET_NAME="cacerts"

einfo "Downloading Istio CA certs"
ISTIO_CERTS_BASE_PATH="./kubernetes/istio/certs" && mkdir -p $ISTIO_CERTS_BASE_PATH

# setting cert KeyName and certName
cakey=${ENVIRONMENT}-istio-ca-key && export cakeyfile="${ISTIO_CERTS_BASE_PATH}/ca-key.pem"
cacert=${ENVIRONMENT}-istio-ca-cert && export cacertfile="${ISTIO_CERTS_BASE_PATH}/ca-cert.pem"
rootcert=${ENVIRONMENT}-istio-root-cert && export rootcertfile="${ISTIO_CERTS_BASE_PATH}/root-cert.pem"
certchain=${ENVIRONMENT}-istio-cert-chain && export certchainfile="${ISTIO_CERTS_BASE_PATH}/cert-chain.pem"

../platform_certs/download-certs.sh ${KV_NAME} ${cakey} ${cakeyfile}
../platform_certs/download-certs.sh ${KV_NAME} ${cacert} ${cacertfile}
../platform_certs/download-certs.sh ${KV_NAME} ${rootcert} ${rootcertfile}
../platform_certs/download-certs.sh ${KV_NAME} ${certchain} ${certchainfile}

# Hoever, we require for sever cert and private key to exist in form of secret in the vault
#   hence if doest exist, fail the process
test -f ${cakeyfile} || $(eerror "Expecting Key file to be present in ${ISTIO_CERTS_BASE_PATH}" && exit 1)
test -f ${cacertfile} || $(eerror "Expecting Cert file to be present in ${ISTIO_CERTS_BASE_PATH}" && exit 1)
test -f ${rootcertfile} || $(eerror "Expecting Key file to be present in ${ISTIO_CERTS_BASE_PATH}" && exit 1)
test -f ${certchainfile} || $(eerror "Expecting Cert file to be present in ${ISTIO_CERTS_BASE_PATH}" && exit 1)

einfo "Check if istio certificate matches private key"
export key_modulus=$(openssl rsa -modulus -noout -in ${cakeyfile} | openssl md5)
export cert_modulus=$(openssl x509 -noout -modulus -in ${cacertfile} | openssl md5)
export chain_modulus=$(openssl x509 -noout -modulus -in ${certchainfile} | openssl md5)
if [[ "${cert_modulus}" == "${key_modulus}" && "${cert_modulus}" == "${chain_modulus}" && "${key_modulus}" == "${chain_modulus}" ]]
then
  einfo "Info: Key and Cert are match. ${cert_modulus} / ${key_modulus} / ${chain_modulus} "
else
  eerror "ERROR: Key and Cert do NOT match. cert: ${cert_modulus} / key: ${key_modulus} / chain: ${chain_modulus} "
  eerror "Patch Deployment Failed"
  exit 1
fi

einfo "Creating dafault AKS secret '${ISTIO_ROOT_CERT_SECRET_NAME}'. Namespace: ${ISTIO_NAMESPACE}"
kubectl create secret generic ${ISTIO_ROOT_CERT_SECRET_NAME} \
    --namespace ${ISTIO_NAMESPACE} \
    --from-file=${cakeyfile} \
    --from-file=${cacertfile} \
    --from-file=${rootcertfile} \
    --from-file=${certchainfile} \
    --dry-run=client -o yaml  |
    kubectl apply --insecure-skip-tls-verify="true" --request-timeout=360s --wait -f -

# Generate Kustomize configuration on the fly to avoid manual creation
einfo "Generate Kustomize configuration. aks:${AKS_NAME}"
mkdir -p core-platform-aks-service-mesh/kustomize/clusters/${AKS_NAME}
touch core-platform-aks-service-mesh/kustomize/clusters/${AKS_NAME}/kustomization.yaml

KIALI_HOST="kiali-${AKS_NAME}.${LOCATION}.aks.${SS_DNS_ZONE}"
JAEGER_HOST="jaeger-${AKS_NAME}.${LOCATION}.aks.${SS_DNS_ZONE}"

einfo "Generate Kiali ingress patch file:"
cat << EOF > core-platform-aks-service-mesh/kustomize/clusters/${AKS_NAME}/patch-kiali-ingress.yaml
- op: replace
  path: /spec/rules/0/host
  value: ${KIALI_HOST}
- op: replace
  path: /spec/tls/0/hosts
  value:
  - ${KIALI_HOST}
EOF

einfo "Generate Istio-IngressGateway loadbalancer ip patch file:"
cat << EOF > core-platform-aks-service-mesh/kustomize/clusters/${AKS_NAME}/patch-ingress-gateway-loadbalancer-ip.yaml
apiVersion: install.istio.io/v1alpha1
kind: IstioOperator
metadata:
  namespace: istio-system
  name: istiocontrolplane
spec:
  values:
    gateways:
      istio-ingressgateway:
        loadBalancerIP: ${ISTIO_INGRESS_IP}
EOF

# commenting out, since currently no usage of istio tracing feature.
# einfo "Generate Jaeger ingress patch file:"
# cat << EOF > core-platform-aks-service-mesh/kustomize/clusters/${AKS_NAME}/patch-jaeger-ingress.yaml
# - op: replace
#   path: /spec/rules/0/host
#   value: ${JAEGER_HOST}
# - op: replace
#   path: /spec/tls/0/hosts
#   value:
#   - ${JAEGER_HOST}
# EOF

cat << EOF > core-platform-aks-service-mesh/kustomize/clusters/${AKS_NAME}/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
- ../../${ENVIRONMENT}/${LOCATION}/
patchesJson6902:
  - path: patch-kiali-ingress.yaml
    target:
      group: networking.k8s.io
      kind: Ingress
      name: kiali-ingress
      namespace: istio-system
      version: v1beta1
patchesStrategicMerge:
  - patch-ingress-gateway-loadbalancer-ip.yaml
EOF

einfo "Adding new resources and pushing to github"
(
  cd core-platform-aks-service-mesh/kustomize/clusters/${AKS_NAME}/
  git add patch-kiali-ingress.yaml
  git add patch-ingress-gateway-loadbalancer-ip.yaml
#   git add patch-jaeger-ingress.yaml
  git add kustomization.yaml
  git commit -m "[Flux Commit] Added Kiali Ingress & load-balancer IP patch for cluster ${AKS_NAME}" || echo \"nothing to commit\"

  # if the FLUX_GIT_BRANCH has this place-holder then replace it with
  # prod service trier always pulls from master
  # eng pulls form eng branch
  # nonp pulls from nonp branch
  if [ ${ENVIRONMENT} == "prod" ]; then
    GIT_BRANCH="master"
  else
    GIT_BRANCH=${ENVIRONMENT}
  fi
  # GIT_BRANCH=$(git branch | grep \* | cut -d ' ' -f2)
  git push origin HEAD:$GIT_BRANCH
)

einfo "END $0"

