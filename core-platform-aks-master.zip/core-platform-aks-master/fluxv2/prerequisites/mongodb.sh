#!/usr/bin/env bash

# Set options
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
  echo """Usage: This script will deploy mongodb resources.
  Pre-Requisites:
      - Kubectl config must be setup
  Arguments:
        AKS cluster conf file holding all the variables for this deployment
  """
  exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"

validate_conf_file $1

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

einfo "Getting DiskEncyptionSetID for K8s storage class: ${MONGODB_DISK_ENCRYPTION_SETID_NAME}"
DISK_ENCRYPTION_SETID=$(az disk-encryption-set show --name ${MONGODB_DISK_ENCRYPTION_SETID_NAME} --resource-group ${MONGODB_RESOURCE_GROUP} --query id -o tsv )

MONGODB_NAMESPACE=mongodb
einfo "Creating ${MONGODB_NAMESPACE} namespace:"
kubectl create namespace ${MONGODB_NAMESPACE} -o yaml --dry-run=client | kubectl apply --force --request-timeout=360s --wait -f -

einfo "Adding Ops Manager Global adminn secret:"
MONGODB_OM_GLOBAL_ADMIN_USER=${ENVIRONMENT}-mongodb-om-global-admin-user
MONGODB_OM_GLOBAL_ADMIN_PASSWORD=${ENVIRONMENT}-mongodb-om-global-admin-password
USER=$(az keyvault secret show --name ${MONGODB_OM_GLOBAL_ADMIN_USER} --vault ${KV_NAME} --query value -o tsv)
PASSWORD=$(az keyvault secret show --name ${MONGODB_OM_GLOBAL_ADMIN_PASSWORD} --vault ${KV_NAME} --query value -o tsv)
kubectl create secret generic ops-manager-global-admin-secret -n ${MONGODB_NAMESPACE} \
  --from-literal=Username=${USER} \
  --from-literal=Password=${PASSWORD} \
  --from-literal=FirstName="opsmanager" \
  --from-literal=LastName="global-admin" \
  --dry-run=client -o yaml |
  kubectl apply --insecure-skip-tls-verify="true" --request-timeout=360s --wait -f -

kubectl create secret generic  ops-manager-ldap-secrets -n ${MONGODB_NAMESPACE} \
  --from-literal=password=${PASSWORD} \
  --dry-run=client -o yaml |
  kubectl apply --insecure-skip-tls-verify="true" --request-timeout=360s --wait -f -

MONGODB_CERTS_BASE_PATH="./kubernetes/mongodb/certs" && mkdir -p $MONGODB_CERTS_BASE_PATH
# creating ops manager tls certificates
einfo "Creating Ops Manager security tls certs:"
tlsCAkey=${ENVIRONMENT}-mongogdb-om-http-cert-ca-key && export tlsCAkeyFile="${MONGODB_CERTS_BASE_PATH}/mms-ca.crt"
tlsCertkey=${ENVIRONMENT}-mongogdb-om-http-cert-key && export tlsCertkeyFile="${MONGODB_CERTS_BASE_PATH}/server.pem"

./platform_certs/download-certs.sh ${KV_NAME} ${tlsCAkey} ${tlsCAkeyFile}
./platform_certs/download-certs.sh ${KV_NAME} ${tlsCertkey} ${tlsCertkeyFile}

kubectl create configmap om-http-cert-ca -n ${MONGODB_NAMESPACE} --from-file=${tlsCAkeyFile} \
  --dry-run=client -o yaml |
  kubectl apply --insecure-skip-tls-verify="true" --request-timeout=360s --wait -f -

kubectl create secret generic om-http-cert -n ${MONGODB_NAMESPACE} --from-file=${tlsCertkeyFile} \
  --dry-run=client -o yaml |
  kubectl apply --insecure-skip-tls-verify="true" --request-timeout=360s --wait -f -

# creating ops manager appdb certificates
einfo "Creating Ops Manager appdb tls certs:"
export appdbCAkeyFile="${MONGODB_CERTS_BASE_PATH}/ca-pem"
cp ${tlsCAkeyFile} ${appdbCAkeyFile}

appdbPemkey0=${ENVIRONMENT}-mongogdb-om-appdb-pem-key && export appdbPemkey0File="${MONGODB_CERTS_BASE_PATH}/mongodb-ops-manager-db-0-pem"
export appdbPemkey1File="${MONGODB_CERTS_BASE_PATH}/mongodb-ops-manager-db-1-pem"
export appdbPemkey2File="${MONGODB_CERTS_BASE_PATH}/mongodb-ops-manager-db-2-pem"
./platform_certs/download-certs.sh ${KV_NAME} ${appdbPemkey0} ${appdbPemkey0File}
cp ${appdbPemkey0File} ${appdbPemkey1File}
cp ${appdbPemkey0File} ${appdbPemkey2File}

kubectl create configmap rbc-ca --from-file=${appdbCAkeyFile} -n ${MONGODB_NAMESPACE} \
  --dry-run=client -o yaml |
  kubectl apply --insecure-skip-tls-verify="true" --request-timeout=360s --wait -f -

kubectl create -n mongodb secret generic appdb-certs -n ${MONGODB_NAMESPACE} \
    --from-file=${appdbPemkey0File} \
    --from-file=${appdbPemkey1File} \
    --from-file=${appdbPemkey2File} \
    --dry-run=client -o yaml  |
    kubectl apply --insecure-skip-tls-verify="true" --request-timeout=360s --wait -f -

# adding mongo db K8s storage class.
mkdir -p core-platform-fluxkustomize/clusters/${AKS_NAME}
touch core-platform-flux/kustomize/clusters/${AKS_NAME}/kustomization.yaml

einfo "Generating MongoDB storage class mongodb-storage-class.yaml"
mkdir -p core-platform-flux/kustomize/clusters/${AKS_NAME}/mongodb
cat << EOF > core-platform-flux/kustomize/clusters/${AKS_NAME}/mongodb/mongodb-storage-class.yaml
kind: StorageClass
apiVersion: storage.k8s.io/v1
metadata:
  name: mongodb-ops-manager-storage
parameters:
  kind: managed
  fsType: xfs
  skuName: StandardSSD_LRS
  tags: "cloud.rbc.com/AppCode=KYV0,cloud.rbc.com/TransitCode=09812,cloud.rbc.com/PortFolio=ccoe,cloud.rbc.com/DataClassification=internal,cloud.rbc.com/NameSpaceOwnerGroup=owner,cloud.rbc.com/OperatorGroup=owner,cloud.rbc.com/ServiceTier=${ENVIRONMENT},cloud.rbc.com/Location=${LOCATION},cloud.rbc.com/PlatformManaged='true'"
  resourceGroup: ${MONGODB_RESOURCE_GROUP}
  diskEncryptionSetID: ${DISK_ENCRYPTION_SETID}
provisioner: disk.csi.azure.com
reclaimPolicy: Delete
volumeBindingMode: WaitForFirstConsumer
EOF

cat << EOF > core-platform-flux/kustomize/clusters/${AKS_NAME}/mongodb/patch-mongodb-enterprise-operator.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mongodb-enterprise-operator
  namespace: mongodb
spec:
  template:
    spec:
      containers:
        - name: mongodb-enterprise-operator
          image: ${ACR_NAME}.azurecr.io/vendor/mongodb/mongodb-enterprise-operator:1.11.0
          env:
            - name: MONGODB_ENTERPRISE_DATABASE_IMAGE
              value: ${ACR_NAME}.azurecr.io/vendor/mongodb/mongodb-enterprise-database
            - name: INIT_DATABASE_IMAGE_REPOSITORY
              value: ${ACR_NAME}.azurecr.io/vendor/mongodb/mongodb-enterprise-init-database
            - name: OPS_MANAGER_IMAGE_REPOSITORY
              value: ${ACR_NAME}.azurecr.io/vendor/mongodb/mongodb-enterprise-ops-manager
            - name: INIT_OPS_MANAGER_IMAGE_REPOSITORY
              value: ${ACR_NAME}.azurecr.io/vendor/mongodb/mongodb-enterprise-init-ops-manager
            - name: INIT_APPDB_IMAGE_REPOSITORY
              value: ${ACR_NAME}.azurecr.io/vendor/mongodb/mongodb-enterprise-init-appdb
            - name: AGENT_IMAGE
              value: "${ACR_NAME}.azurecr.io/vendor/mongodb/mongodb-agent:10.29.0.6830-1"
            - name: MONGODB_REPO_URL
              value: ${ACR_NAME}.azurecr.io/vendor/mongodb

EOF

### Ex. RESOURCE_GROUP="e-eng-ccoe-diagnostic-aks-rg-cac-1"
### RG naming convention: {service_tier_short}-{service_tier}-{portfolio}-{component}-aks-rg-{region}-{id}
### Since we captured everything after "app" as one group we simply dump BASH_REMATCH[7] which includes both {locationShort} and {numberIdentifier}
[[ $RESOURCE_GROUP =~ ([^-]+)-([^-]+)-([^-]+)-([^-]+)-([^-]+)-([^-]+)-(.+) ]]
AKS_ID="${BASH_REMATCH[4]}-${BASH_REMATCH[7]}"
einfo "AKS ID: ${AKS_ID}"

einfo "Generate Controller Service file:"
cat << EOF > core-platform-flux/kustomize/clusters/${AKS_NAME}/mongodb/patch-ops-manager-ingress.yaml
apiVersion: networking.k8s.io/v1beta1
kind: Ingress
metadata:
  name: ops-manager-ingress
  namespace: mongodb
  annotations:
    kubernetes.io/ingress.class: nginx
    ingress.kubernetes.io/ssl-redirect: "false"
    ingress.kubernetes.io/ssl-passthrough: "true"
    nginx.ingress.kubernetes.io/backend-protocol: "HTTPS"
spec:
  tls:
    - hosts:
        - 'ops-manager-${AKS_ID}.${LOCATION}.aks.${ENVIRONMENT}.c1.rbc.com'
  rules:
    - host: 'ops-manager-${AKS_ID}.${LOCATION}.aks.${ENVIRONMENT}.c1.rbc.com'
      http:
        paths:
          - backend:
              serviceName: mongodb-ops-manager-svc
              servicePort: 8443
            path: /
EOF

source "${BASH_SOURCE%/*}/../../cluster/${ENVIRONMENT}/mongo-ops-manager.conf"
cat << EOF > core-platform-flux/kustomize/clusters/${AKS_NAME}/mongodb/patch-mongodb-ops-manager.yaml
apiVersion: mongodb.com/v1
kind: MongoDBOpsManager
metadata:
  name: mongodb-ops-manager
  namespace: mongodb
spec:
  configuration:
    mms.ignoreInitialUiSetup: '${mms_ignoreInitialUiSetup}'
    mms.adminEmailAddr: ${mms_adminEmailAddr}
    mms.fromEmailAddr: ${mms_fromEmailAddr}
    mms.replyToEmailAddr: ${mms_replyToEmailAddr}
    mms.mail.hostname: ${mms_mail_hostname}
    mms.mail.port: '${mms_mail_port}'
    mms.mail.ssl: '${mms_mail_ssl}'
    mms.mail.transport: ${mms_mail_transport}
    mms.minimumTLSVersion: ${mms_minimumTLSVersion}
    mms.ldap.url: ${mms_ldap_url}
    mms.ldap.ssl.CAFile: ${mms_ldap_ssl_CAFile}
    mms.ldap.bindDn: ${mms_ldap_bindDn}
    mms.ldap.user.baseDn: ${mms_ldap_user_baseDn}
    mms.ldap.user.searchAttribute: ${mms_ldap_user_searchAttribute}
    mms.ldap.group.member: ${mms_ldap_group_member}
    mms.ldap.user.group: ${mms_ldap_user_group}
    mms.ldap.global.role.owner: ${mms_ldap_global_role_owner}
EOF

einfo "Saving storage class manifest to git"
(
  cd core-platform-flux/
  git add kustomize/clusters/${AKS_NAME}/mongodb/mongodb-storage-class.yaml
  git add kustomize/clusters/${AKS_NAME}/mongodb/patch-ops-manager-ingress.yaml
  git add kustomize/clusters/${AKS_NAME}/mongodb/patch-mongodb-enterprise-operator.yaml
  git add kustomize/clusters/${AKS_NAME}/mongodb/patch-mongodb-ops-manager.yaml
)
(
  cd core-platform-flux/kustomize/clusters/${AKS_NAME}/
  kustomize edit add resource mongodb/mongodb-storage-class.yaml ../../${ENVIRONMENT}/${LOCATION}/ ../../global/mongodb/ ;
  kustomize edit add resource mongodb/patch-ops-manager-ingress.yaml
  kustomize edit add patch --path mongodb/patch-mongodb-enterprise-operator.yaml
  kustomize edit add patch --path mongodb/patch-mongodb-ops-manager.yaml
  git add kustomization.yaml
  git commit -m "[FLUX-AUTOMATED] Added mongodb-storage-class for cluster ${AKS_NAME}" || echo \"nothing to commit\"

# if the FLUX_GIT_BRANCH has this place-holder then replace it with
# prod service trier always pulls from master
# eng pulls form eng branch
# nonp pulls from nonp branch
if [ ${ENVIRONMENT} == "prod" ]; then
  GIT_BRANCH="master"
else
  GIT_BRANCH=${ENVIRONMENT}
fi
#  GIT_BRANCH=$(git branch | grep \* | cut -d ' ' -f2)
  git push origin HEAD:$GIT_BRANCH
)

einfo "END $0"