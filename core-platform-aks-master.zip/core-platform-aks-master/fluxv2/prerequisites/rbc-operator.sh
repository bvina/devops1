#!/usr/bin/env bash
# Create Azure Identiy (User Assigned) required for the rbc-k8s-operator and roles and set up bindings
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/../../common.sh"

function usage() {
    echo """Usage: This script will create Azure Identities required for the Secrets Operator (if not present) and bind it to the secrets operator

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

OPERATOR_NAMESPACE=rbc-system

mkdir -p rbc-k8s-operator-flux/kustomize/clusters/${AKS_NAME}
touch rbc-k8s-operator-flux/kustomize/clusters/${AKS_NAME}/kustomization.yaml

einfo "Generating general configmap-config.yaml"
cat << EOF > rbc-k8s-operator-flux/kustomize/clusters/${AKS_NAME}/rbc-k8s-operator-configs.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: rbc-k8s-operator-configs
  namespace: ${OPERATOR_NAMESPACE}
  labels:
    app.kubernetes.io/managed-by: flux
data:
  location: ${LOCATION}
  networkCIDR: ${VnetAddressPrefix}
  clustername: ${AKS_NAME}
  servicetier: ${ENVIRONMENT}
  resourceGroup: ${RESOURCE_GROUP}
  subscriptionID: ${SUBSCRIPTION_ID}
  dnsresourcegroupname: ${SS_DNS_RG_NAME}
  dnssubscritpionid: ${SS_SUBSCRIPTION_ID}
EOF

einfo "Saving new configurations to git"
(
  cd rbc-k8s-operator-flux/
  git add kustomize/clusters/${AKS_NAME}/rbc-k8s-operator-configs.yaml
)
(
  cd rbc-k8s-operator-flux/kustomize/clusters/${AKS_NAME}/
  kustomize edit add resource rbc-k8s-operator-configs.yaml ../../${ENVIRONMENT}/${LOCATION}/ ;
  kustomize edit set namespace ${OPERATOR_NAMESPACE}
  git add kustomization.yaml
  git commit -m "[FLUX-AUTOMATED] Added configs rbc-k8s-operator-configs for cluster ${AKS_NAME}" || echo \"nothing to commit\"

# if the FLUX_GIT_BRANCH has this place-holder then replace it with
# prod service trier always pulls from master
# eng pulls form eng branch
# nonp pulls from nonp branch
if [ ${ENVIRONMENT} == "prod" ]; then
  GIT_BRANCH="master"
else
  GIT_BRANCH=${ENVIRONMENT}
fi
  git push origin HEAD:$GIT_BRANCH
)

einfo "END $0"
