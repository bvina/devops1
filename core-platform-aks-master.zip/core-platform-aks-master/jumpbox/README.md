# JumpBox Automation
This allows us to create and tear-down jumpboxes, so that teams can test their apps deployed in AKS.  This creates a
VMSS (without loadbalancer) and autoscalesettings.

## Where do they live?
  * Sub - Shared Services
  * Subnet - *ccoe-sharedservices-jumpbox-subnet-cac-1
  * NSG - *ccoe-sharedservices-jumpbox-nsg-cac-1

## How to create a Jumpboxes
```
./deploy_jumpbox.sh params/eng
```

## How to teardown a JumpBoxes
```
./teardown_jumpbox.sh params/eng
```

## How to add more instance
Use the `INSTANCE_COUNT` to control the number jumpbox instances, change the value and re-run `deploy_jumpbox.sh`,
When you update the number of instances the already provisioned may be deleted and re-created.

## Steps to produce JumpBox image
1) Create a VM from "CIS Microsoft Windows Server 2016 Benchmark L1" available in MarketPlace.
1) Create the VM in SOE's resource group "e-eng-ccoe-sharedservices-soeshared-rg-cac-1".
   (jumpbox RG has no internet access)
2) Install software such as Google Chrome, PostMan and git for windows.
3) Capture the image (after the VMS is prepared) into e-eng-ccoe-sharedservices-jumpbox-rg-cac-1.
4) Supply the image base name in param/<CONFIG> file.

## Schedule
The Jumpboxes are automatically created at 9:00 and deleted at 18:00 from Monday through Friday.

## Getting Jumpbox private IPs
Since we delete and re-create jumpboxes every day, please run the below script to get their Private IPs for the day.
```
./get_jumpbox_privateIPs.sh params/eng
```
