#!/usr/bin/env bash
# Deploy a jumpbox for testing apps managed by AKS cluster

# Set options
set -o errexit
set -o pipefail
set -o nounset

source ../common.sh

check_prereq "az"
validate_conf_file $@

# Contains variables that should not be in source control
# Eg: Adminpassword for the windows host
source ./sensitive.conf

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

einfo "Lookup for subnet ID"
subnet_id=`az network vnet subnet show -n ${JUMPBOX_SUBNET_NAME} -g ${SHAREDSERVICE_VNET_RESOURCE_GROUP_NAME} \
--vnet-name ${SHAREDSERVICE_VNET_NAME} --query "id" -o tsv`

einfo "Looking up for NSG ID"
nsg_id=`az network nsg show -n ${JUMPBOX_NSG_NAME} -g ${SHAREDSERVICE_VNET_RESOURCE_GROUP_NAME} --query "id" -o tsv`

edumpvar subnet_id nsg_id

einfo "Creating the jumpbox..."
az group deployment create --name ${JUMPBOX_NAME} --resource-group ${SHAREDSERVICE_JUMPBOX_RESOURCE_GROUP_NAME} \
                           --template-file ./VMSS.json \
                           --parameters \
                           location=${LOCATION} \
                           networkSecurityGroupId=${nsg_id} \
                           subnetId=${subnet_id} \
                           vmssName=${JUMPBOX_NAME} \
                           adminUsername=${ADMIN_USER} \
                           instanceCount=${INSTANCE_COUNT} \
                           adminPassword=${ADMIN_PASSWORD}
