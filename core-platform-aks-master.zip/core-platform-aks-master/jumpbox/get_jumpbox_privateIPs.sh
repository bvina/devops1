#!/usr/bin/env bash
# Gets the private ips of the VMSS instances.

# Set options
set -o errexit
set -o pipefail
set -o nounset

source ../common.sh

validate_conf_file $@

az vmss nic list --resource-group ${SHAREDSERVICE_JUMPBOX_RESOURCE_GROUP_NAME} \
   --subscription ${SUBSCRIPTION_ID} --vmss-name ${JUMPBOX_NAME} \
   --query "[*].ipConfigurations[*].privateIpAddress" -o tsv
