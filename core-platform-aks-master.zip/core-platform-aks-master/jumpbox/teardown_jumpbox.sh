#!/usr/bin/env bash
# Teardown Jumpbox

# Set options
set -o errexit
set -o pipefail
set -o nounset

source ../common.sh

check_prereq "az"
validate_conf_file $@

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# All the resources created by the deployment are tagged, its easy to delete VM, its NicCard and its disk togather.
einfo "Delete the resources of the deployment.."
az resource delete --ids $(az resource list --tag JumpBoxName=${JUMPBOX_NAME} -o table --query "[].id" -otsv)

einfo "Deleting the deployment jumpbox..."
az group deployment delete --name ${JUMPBOX_NAME} --resource-group ${SHAREDSERVICE_JUMPBOX_RESOURCE_GROUP_NAME}
