#!/usr/bin/env bash
# Apply DaemonSets and cluster services
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will install various controllers and other cluster-wide services for AKS

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
validate_conf_file $@

einfo "START $0"

einfo "Applying PodSecurityPolicy"
kustomize build kubernetes/podsecuritypolicy/overlays/${ENVIRONMENT} | kubectl apply --force --request-timeout=360s --wait -f -


einfo "END $0"



