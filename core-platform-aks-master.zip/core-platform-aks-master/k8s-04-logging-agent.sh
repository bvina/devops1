#!/usr/bin/env bash
# Apply Ingress Controller Kubernetes manifests to AKS cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will apply RBAC manifests for AKS clusters

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
# Test to ensure we can connect to an AKS cluster
kubectl cluster-info

einfo "Applying cluster logging agent resources for ${AKS_NAME}"
kubectl create namespace ${APPCODE,,}-${PORTFOLIO}-fluentd -o yaml --dry-run=client | \
    kubectl label --local --dry-run=client -o yaml -f - \
    app=fluentd \
    cloud.rbc.com/AppCode=${APPCODE} \
    cloud.rbc.com/TransitCode=${TRANSIT_CODE} \
    cloud.rbc.com/DataClassification="internal" \
    cloud.rbc.com/Compliance="" \
    cloud.rbc.com/ServiceTier="${ENVIRONMENT}" \
    cloud.rbc.com/Location="${LOCATION}" \
    cloud.rbc.com/Portfolio="${PORTFOLIO}" | kubectl apply --force --request-timeout=360s --wait -f -

# Retrieve Secret from AKV as EventHub-${LOCATION}
EVENTHUB_CONNECTION_STRING=`az keyvault secret show --vault-name ${KV_NAME} --name EventHub-${LOCATION} --query value -o tsv`

kubectl --namespace=${APPCODE,,}-${PORTFOLIO}-fluentd create secret generic fluentd-secret \
   --from-literal=connection-string=${EVENTHUB_CONNECTION_STRING}

kustomize build kubernetes/daemonsets/fluentd/overlays/${ENVIRONMENT}/${APPCODE}/${PORTFOLIO} | \
    kubectl apply --force --request-timeout=360s --wait -f -

einfo "END $0"
