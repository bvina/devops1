#!/usr/bin/env bash
# Apply Clouability metric agent manifests to AKS cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"
function usage() {
    echo """Usage: This script will apply Clouability metric agent to AKS clusters

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
# Test to ensure we can connect to an AKS cluster
kubectl cluster-info

einfo "Applying cluster logging agent resources for ${AKS_NAME}"
kubectl create namespace cloudability -o yaml --dry-run=client | \
    kubectl label --local --dry-run=client -o yaml -f - \
    app=cloudability \
    cloud.rbc.com/AppCode=${APPCODE} \
    cloud.rbc.com/TransitCode=${TRANSIT_CODE} \
    cloud.rbc.com/DataClassification="internal" \
    cloud.rbc.com/Compliance="" \
    cloud.rbc.com/ServiceTier="${ENVIRONMENT}" \
    cloud.rbc.com/Location="${LOCATION}" \
    cloud.rbc.com/Portfolio="${PORTFOLIO}" | kubectl apply --force --request-timeout=360s --wait -f -

CLOUDABILITY_API_KEY=`az keyvault secret show --vault-name ${KV_NAME} --name cloudability-api-key --query value -o tsv`

# Fetch Cloudability API Key
kubectl --namespace=cloudability create secret generic cloudability-secret \
   --from-literal=api-key="${CLOUDABILITY_API_KEY}" --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -

# Fetch Current Cluster Name
kubectl --namespace=cloudability create secret generic cloudability-cluster \
   --from-literal=cluster-name="${AKS_NAME}" --dry-run=client -o yaml | kubectl apply --force --request-timeout=360s --wait -f -

kustomize build kubernetes/daemonsets/cloudability/overlays/${ENVIRONMENT}/${LOCATION} | \
    kubectl apply --force --request-timeout=360s --wait -f -

einfo "END $0"
