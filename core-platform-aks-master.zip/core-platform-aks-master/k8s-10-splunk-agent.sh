#!/usr/bin/env bash
# Apply Splunk Connect for Kubernetes manifests to AKS cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will apply Splunk manifests for AKS clusters

    Pre-Requisites:
        - Must be logged in to Azure run az login
        - Helm v3.0 or greater

    Arguments:
        - AKS cluster conf file holding all the variables for this deployment
        - Rollout Override flag (yes/no)
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
check_prereq "helm"
validate_conf_file $@

einfo "START $0"
redeploy_splunk=${2:-"no"} # default behavior
edumpvar redeploy_splunk

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

einfo "Adding internal Registry ${ACR_NAME}"
helm repo add internal https://${ACR_NAME}.azurecr.io/helm/v1/repo/ \
    --username ${ARM_CLIENT_ID} \
    --password ${ARM_CLIENT_SECRET}
helm repo update

# Splunk variables
SPLUNK_VERSION=${SPLUNK_VERSION:-"1.4.0"}
SPLUNK_NAMESPACE="splunk"
SPLUNK_DIR=kubernetes/splunk

# Retreive Splunk HEC token from keyvault
einfo "Retrieving Splunk HEC token from keyvault"
SPLUNK_HEC_TOKEN=`az keyvault secret show --vault-name ${KV_NAME} --name ${SPLUNK_SECRET_NAME} --query value -o tsv`

# Render Helm charts
einfo "Rendering Helm charts"
helm template cluster --namespace ${SPLUNK_NAMESPACE} \
    --values ${SPLUNK_DIR}/values.yaml \
    --set global.kubernetes.clusterName="${AKS_NAME}" \
    --set global.splunk.hec.host="${short_tier[${ENVIRONMENT}]}${ENVIRONMENT}splunk1.${ENVIRONMENT}.c1.rbc.com" \
    --set global.splunk.hec.token=${SPLUNK_HEC_TOKEN} \
    --set splunk-kubernetes-logging.splunk.hec.indexName="kyvos_kyv0_azure-events" \
    --set splunk-kubernetes-logging.containers.logFormatType="cri" \
    --set splunk-kubernetes-logging.image.registry=${ACR_NAME}.azurecr.io \
    --set splunk-kubernetes-logging.image.name=aeo0/vendor/splunk-fluentd-hec \
    --set splunk-kubernetes-logging.image.tag="1.2.4" \
    --set splunk-kubernetes-objects.splunk.hec.indexName="kyvos_kyv0_azure-objects" \
    --set splunk-kubernetes-objects.image.registry=${ACR_NAME}.azurecr.io \
    --set splunk-kubernetes-objects.image.name=aeo0/vendor/splunk-kube-objects \
    --set splunk-kubernetes-objects.image.tag="1.1.4" \
    --set splunk-kubernetes-metrics.splunk.hec.indexName="kyvos_kyv0_azure-metrics" \
    --set splunk-kubernetes-metrics.image.registry=${ACR_NAME}.azurecr.io \
    --set splunk-kubernetes-metrics.image.name=aeo0/vendor/splunk-k8s-metrics \
    --set splunk-kubernetes-metrics.image.tag="1.1.4" \
    --set splunk-kubernetes-metrics.imageAgg.registry=${ACR_NAME}.azurecr.io \
    --set splunk-kubernetes-metrics.imageAgg.name=aeo0/vendor/splunk-k8s-metrics-aggr \
    --set splunk-kubernetes-metrics.imageAgg.tag="1.1.4" \
    --set splunk-kubernetes-metrics.kubernetes.serviceTier="${ENVIRONMENT}" \
    --output-dir ${SPLUNK_DIR}/base \
    --version ${SPLUNK_VERSION} \
    internal/rbc-splunk-connect-for-kubernetes

(cd ${SPLUNK_DIR}/base ; find . -type f -iname "*.yaml" ! -name "kustomization.yaml" ! -name "global-labels.yml" -exec kustomize edit add resource {} \;)
cat ${SPLUNK_DIR}/base/kustomization.yaml

## Apply Network Policy
sed "s#{clusterCidr}#${VnetAddressPrefix}#g" ${SPLUNK_DIR}/allow-apiserver-egress.yaml > ${SPLUNK_DIR}/overlays/${ENVIRONMENT}/${LOCATION}/allow-apiserver-egress.yaml

echo "updated: allow-apiserver-egress.yaml"

kustomize build ${SPLUNK_DIR}/overlays/${ENVIRONMENT}/${LOCATION} | \
    kubectl apply --namespace ${SPLUNK_NAMESPACE} --force --request-timeout=360s --wait -f -

echo "kubectl applied"

if [ "${redeploy_splunk}" == "yes" ]; then
    einfo "Override detected - Initiating Rollout"
    kubectl rollout restart deployment splunk-kubernetes-metrics-agg -n ${SPLUNK_NAMESPACE}
    kubectl rollout restart deployment splunk-kubernetes-objects -n ${SPLUNK_NAMESPACE}
    kubectl rollout restart daemonset splunk-kubernetes-logging -n ${SPLUNK_NAMESPACE}
    kubectl rollout restart daemonset splunk-kubernetes-metrics -n ${SPLUNK_NAMESPACE}
fi

einfo "END $0"
