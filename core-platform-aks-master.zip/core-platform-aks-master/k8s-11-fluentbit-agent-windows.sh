#!/usr/bin/env bash
# Apply Ingress Controller Kubernetes manifests to AKS cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"
function usage() {
    echo """Usage: This script will apply RBAC manifests for AKS clusters

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"

az aks nodepool list --cluster-name ${AKS_NAME} -g ${RESOURCE_GROUP} --query "[].{OS:osType}" --output tsv|
while read -r OS; do
if [[ "$OS" == "Windows" ]]
then
# Get Subscription name from subscription ID
SUBSCRIPTION_NAME=$(az account show -s "${SUBSCRIPTION_ID}" -o json | jq --exit-status --raw-output '.name')

# Retreive Splunk HEC token from keyvault
einfo "Retrieving Splunk HEC token from keyvault"
SPLUNK_HEC_TOKEN=`az keyvault secret show --vault-name ${KV_NAME} --name ${SPLUNK_SECRET_NAME} --query value -o tsv`

# Deploying Fluent-Bit Agent
einfo "Deploying Fluent-bit Windows agent to ${AKS_NAME}"
kubectl create namespace logging-win -o yaml --dry-run=client | \
kubectl label --local --dry-run=client -o yaml -f - \
app=fluentbit \
cloud.rbc.com/AppCode=${APPCODE} \
cloud.rbc.com/TransitCode=${TRANSIT_CODE} \
cloud.rbc.com/DataClassification="internal" \
cloud.rbc.com/Compliance="" \
cloud.rbc.com/ServiceTier="${ENVIRONMENT}" \
cloud.rbc.com/PlatformManaged="true" \
cloud.rbc.com/Location="${LOCATION}" \
cloud.rbc.com/Portfolio="${PORTFOLIO}" | kubectl apply --force --request-timeout=360s --wait -f -
kustomize build kubernetes/daemonsets/fluentbit/Windows/overlays/${ENVIRONMENT}/${LOCATION} | \
kubectl apply --force --request-timeout=360s --wait -f -
cat << EOF > configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: fluent-bit-config
  namespace: logging-win
  labels:
    k8s-app: fluent-bit
    app: fluentbit
    cloud.rbc.com/AppCode: ${APPCODE}
    cloud.rbc.com/TransitCode: "${TRANSIT_CODE}"
    cloud.rbc.com/DataClassification: internal
    cloud.rbc.com/Compliance: ""
    cloud.rbc.com/ServiceTier: ${ENVIRONMENT}
    cloud.rbc.com/PlatformManaged: "true"
    cloud.rbc.com/Location: ${LOCATION}
    cloud.rbc.com/Portfolio: ${PORTFOLIO}
data:
  fluent-bit.conf: |
      [SERVICE]
        Parsers_File      C:\\fluent-bit\\conf\\parsers.conf

      [INPUT]
        Name               tail
        Tag                kube.*
        Path               C:\\var\\log\\containers\\*.log
        Parser             docker
        Mem_Buf_Limit      100MB
        Refresh_Interval   10

      [INPUT]
        Name               tail
        Tag                tail.kubeproxy.*
        Path               C:\\k\\kubeproxy*.log
        Parser             docker
        DB                 C:\\fluent-bit\\tail_docker.db
        Mem_Buf_Limit      100MB
        Refresh_Interval   10

      [INPUT]
        Name               tail
        Tag                tail.kubelet.err
        Parser             docker
        Path               C:\\k\\kubelet.err.log
        DB                 C:\\fluent-bit\\tail_kubelet.db
        Mem_Buf_Limit      100MB
        Refresh_Interval   10

      [FILTER]
        Name             kubernetes
        Match            kube.*
        Kube_URL         https://kubernetes.default.svc.cluster.local:443
        Kube_CA_File     C:\\var\\run\\secrets\\kubernetes.io\\serviceaccount\\ca.crt
        Kube_Token_File  C:\\var\\run\\secrets\\kubernetes.io\\serviceaccount\\token
        Kube_Tag_Prefix  kube.c.var.log.containers.
        Merge_Log        Off
        tls.debug        4
        tls.verify       Off
        K8S-Logging.Parser On
        K8S-Logging.Exclude On
        Keep_Log Off
        Labels On
        Annotations On

      [FILTER]
        Name nest
        Match *
        Operation nest
        Wildcard *
        Nest_under event

      [FILTER]
        Name      modify
        Match     *
        Add index kyvos_kyv0_azure-events
        Add host $HOSTNAME
        Add source ${SUBSCRIPTION_NAME}

      [FILTER]
        Name      lua
        Match     kube.*
        script    C:\\fluent-bit\\bin\\lua-filter.config.yaml\\fluent-bit-lua.lua
        call      fluent_bit_lua

      [OUTPUT]
        Name  splunk
        Match *
        Host ${short_tier[${ENVIRONMENT}]}${ENVIRONMENT}splunk1.${ENVIRONMENT}.c1.rbc.com
        port 8088
        Format json
        Splunk_Token ${SPLUNK_HEC_TOKEN}
        TLS On
        TLS.Verify Off
        Splunk_Send_Raw On

  parsers.conf: |
    [PARSER]
        Name         docker
        Format       json
        Time_Key     time
        Time_Format  %Y-%m-%dT%H:%M:%S.%L
        Time_Keep    On
        # Command      |  Decoder | Field | Optional Action
        # =============|==================|=================
        Decode_Field_As    json     log
EOF
kubectl apply -f configmap.yaml --force --request-timeout=360s

fi
done



einfo "END $0"
