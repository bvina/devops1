#!/usr/bin/env bash
# Apply SignalFxAgent Kubernetes manifests to AKS cluster
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"
function usage() {
    echo """Usage: This script will apply SignalFX Agent manifests for AKS clusters

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
        Rollout Override flag (yes/no)
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
redeploy_signalfx=${2:-"no"} # default behavior
edumpvar redeploy_signalfx

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Splunk HEC variable
SIGNALFX_DIR=kubernetes/daemonsets/signalfx

# Retreive Splunk HEC token from keyvault
einfo "Retrieving Splunk HEC token from keyvault"
SPLUNK_HEC_TOKEN=`az keyvault secret show --vault-name ${KV_NAME} --name ${SPLUNK_SECRET_NAME} --query value -o tsv`
SIGNALFX_NAMESPACE="signalfx"

az aks nodepool list --cluster-name ${AKS_NAME} -g ${RESOURCE_GROUP} --query "[].{OS:osType}" --output tsv|
while read -r OS; do
  if [[ "$OS" == "Windows" ]]
  then
  einfo "Deploying signalfx Windows agent to ${AKS_NAME}"
  kubectl create namespace signalfx -o yaml --dry-run=client | \
  kubectl label --local --dry-run=client -o yaml -f - \
  app=signalfx-agent \
  cloud.rbc.com/AppCode=${APPCODE} \
  cloud.rbc.com/TransitCode=${TRANSIT_CODE} \
  cloud.rbc.com/DataClassification="internal" \
  cloud.rbc.com/Compliance="" \
  cloud.rbc.com/ServiceTier="${ENVIRONMENT}" \
  cloud.rbc.com/PlatformManaged="true" \
  cloud.rbc.com/Location="${LOCATION}" \
  cloud.rbc.com/Portfolio="${PORTFOLIO}" | kubectl apply --force --request-timeout=360s --wait -f -

  sed "s#{AKS_NAME}#${AKS_NAME}#g; s#{SPLUNK_HEC_TOKEN}#${SPLUNK_HEC_TOKEN}#g; s#{shortenv}#${short_tier[${ENVIRONMENT}]}#g; s#{fullenv}#${ENVIRONMENT}#g" ${SIGNALFX_DIR}/configmap.yaml > ${SIGNALFX_DIR}/base/configmap.yaml

  echo "updated: configmap.yaml"

  kustomize build kubernetes/daemonsets/signalfx/overlays/${ENVIRONMENT}/${LOCATION} | \
    kubectl apply --namespace ${SIGNALFX_NAMESPACE} --force --request-timeout=360s --wait -f -
    kubectl rollout restart daemonsets signalfx-agent -n ${SIGNALFX_NAMESPACE}

    if [ "${redeploy_signalfx}" == "yes" ]; then
        einfo "Override detected - Initiating Rollout"
        kubectl rollout restart daemonsets signalfx-agent -n ${SIGNALFX_NAMESPACE}
    fi

  fi
  done


einfo "END $0"
