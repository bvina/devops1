#!/usr/bin/env bash
# Deploy an Azure Kubernetes Services Cluster (AKS)

# Set options
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will deploy an AKS Cluster

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        A variable file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "az"
check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

# Constants
export GIT_BRANCH=${GIT_BRANCH:-$(git branch | grep \* | cut -d ' ' -f2)}
export GIT_COMMIT=${GIT_COMMIT:-$(git rev-parse HEAD)}
export RELEASED=$(date +%s)
export INGRESS_NAMESPACE="ingress"

einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

# Login by Admin SP
aks_login_admin_sp $@

./k8s-03-cluster-services.sh $@

# Disabled 11/15/2019 since the code is not ready for automation. Further work required
# ./k8s-04-logging-agent.sh $@

./k8s-10-splunk-agent.sh $@  "no" # second parameter indicates whether or not override deploy of splunk connect

./k8s-11-fluentbit-agent-windows.sh $@ #Deploying fluentbit on windows nodes

./wrapper-scripts/extension-win-deploy.sh $@ # install services required for win nodes, including Aqua Enforcers

./k8s-12-signalfx-agent.sh $@

# Install gpu ds, this will be applied on nodes which we have gpu taint enabled
kustomize build kubernetes/daemonsets/nvidia/overlays/${ENVIRONMENT}/${LOCATION} | \
    kubectl apply --force --request-timeout=360s --wait -f -

einfo "Deployment Complete"
