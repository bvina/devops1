#!/usr/bin/env bash
# Deploy Descheduler object to the cluster.
set -o errexit
set -o pipefail
set -o nounset

source "${BASH_SOURCE%/*}/common.sh"

function usage() {
    echo """Usage: This script will deploy Descheduler K8s object

    Pre-Requisites:
        - Must be logged in to Azure run az login

    Arguments:
        AKS cluster conf file holding all the variables for this deployment
    """
    exit 1
}

check_prereq "kubectl"
check_prereq "kustomize"
validate_conf_file $@

einfo "START $0"
einfo "Setting default subscription to ${SUBSCRIPTION_ID}"
az account set --subscription ${SUBSCRIPTION_ID}

einfo "Kubernetes configuration for AKS cluster ${AKS_NAME} started"
# Login by Admin SP
aks_login_admin_sp $@

einfo "Deploying Descheduler objects to ${AKS_NAME}"

kustomize build kubernetes/descheduler/overlays/${ENVIRONMENT} | \
    kubectl apply --force --request-timeout=360s --wait -f -

einfo "END $0"