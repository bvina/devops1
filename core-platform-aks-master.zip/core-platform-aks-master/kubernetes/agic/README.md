# Application Gateway Ingress Controller

The Application Gateway Ingress Controller allows Azure Application Gateway to be used as the ingress for an Azure Kubernetes Service aka AKS cluster. The ingress controller runs as a pod within the AKS cluster. It consumes Kubernetes Ingress Resources and converts them to an Azure Application Gateway configuration which allows the gateway to load-balance traffic to Kubernetes pods.

## Pre-Requisites

1. Kubernetes resources

A helper bash script has been created to fetch a specified version of the ingress-azure chart & render it out to the global kustomize directory. Since we don't want upstream issues to propagate to our own nginx deployments, we do this to pin the chart to a specific version and only upgrade when we need to.

By following bellow steps you are able to export the resources for ingress controller from its helm chart. You need to have the `values-azure.yaml` file modified based on needs and requirements. The `all-in-one-resources.yml` file has all the resources.

```bash
./update-agic-helm-chart.sh values-azure.yaml
```
2. AAD Pod Identity

Since we use managed identity for authentication purposes, an AAD Pod Identity is required for the AGIC pod to make HTTP requests to ARM. One Azure identity required to be created in the same resource group as the AKS nodes.
The folloeing roles required for this identity:
    - `Contributor access to App Gateway`
    - `Reader access to the App Gateway resource group`
    - `Operator access over App Gateway identity`

3. Runing Application Gateway

## AGIC Configuration

Bellow settings have been applied to AGIC during its deployment, these settings have been set in ConfigMap resource definition:

```yaml
verbosityLevel: 3
appgw:
    subscriptionId: ${SUBSCRIPTION_ID}
    resourceGroup: ${APPGW_RESOURCE_GROUP}
    name: ${APPGW_NAME}
    # specify whether to expose this endpoint on Private IP of Application Gateway.
    usePrivateIP: true
    shared: false
# Ingress Controller observing all acessible namespaces.
kubernetes:
  watchNamespace: ""
# authentication method is through managed identity
armAuth:
    type: aadPodIdentity
    identityResourceID: ${identityId}
    identityClientID:  ${clientId}
rbac:
    enabled: true
```

## Deployment pipeline

If the Application Gateway flag is true, the AGIC will be deployed theorugh the cluster build pipeline.

## Annotations

All Ingress resources needs to have the following annotation in their defenition:
`kubernetes.io/ingress.class: azure/application-gateway`

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: somename
  namespace: somenamespace
  annotations:
    kubernetes.io/ingress.class: azure/application-gateway
spec:
  rules:
  - host: somename
    http:
      paths:
      - backend:
          serviceName: someservicename
          servicePort: 80
```
## SSL configuration

By using `appgw.ingress.kubernetes.io/appgw-ssl-certificate: "rbccert"` annotation, we are able to refer to the installed certificate on Application Gateway:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: somename
  namespace: somenamespace
  annotations:
    kubernetes.io/ingress.class: azure/application-gateway
    appgw.ingress.kubernetes.io/appgw-ssl-certificate: "rbccert"
spec:
  rules:
  - host: somename
    http:
      paths:
      - backend:
          serviceName: someservicename
          servicePort: 80
```
Using `appgw.ingress.kubernetes.io/ssl-redirect: "true"` we can enable SSL redirection.

For the complete list of available annotations refer to [AGIC Annotation](https://github.com/Azure/application-gateway-kubernetes-ingress/blob/master/docs/annotations.md)

## Upgrade Process

When there is a [new version to upgrade](https://github.com/Azure/application-gateway-kubernetes-ingress/releases), other than updating the image tags, you need to follow bellow steps:

1. Update CHART_VERSION in [update-agic-helm-chart.sh](update-agic-helm-chart.sh)
2. Update values-azure.yaml if required
3. Run
```bash
./update-agic-helm-chart.sh values-azure.yaml
```
4. This script generates all manifest from helm chart. Please note to remove the following resources, since we are generating them during cluster build
  `aadpodidentity`
  `configmap`
  `aadpodidbinding`

5.  Note that for the update to AGIC 1.5.2 from 1.4.0 the script did not generate additional settings needed in the clusterrole.yaml and deployment.yaml files. Ensure you do a comparison on the old file(s) for this.