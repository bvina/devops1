#!/usr/bin/env bash
# Pulls the Helm chart from GitHub for deploying ingress-azure and writes out
# the manifests to kustomize global for further customization
set -o errexit
set -o pipefail

CHART_NAME="ingress-azure"
CHART_VERSION="1.5.2"
REPO_NAME="application-gateway-kubernetes-ingress"
REPO_ADDRESS="https://appgwingress.blob.core.windows.net/ingress-azure-helm-package/"
NAMESPACE="ingress-azure"

function usage() {
    echo """Pulls the Helm chart from GitHub for deploying ingress-azure and
writes out the manifests to kustomize/global to allow for further
customization.

To obtain a specific version of ingress-azure, set the
CHART_VERSION environment variable or specify directly:

Default version: ${CHART_VERSION}"""
    exit 1
}

if [ "$1" == "-h" ]; then
    usage
fi

function check_prereq() {
    COMMAND=$1
    which $COMMAND >/dev/null 2>&1 || export EXIT_CODE=$? && true
    if [ ${EXIT_CODE:-0} -ne 0 ]; then
        eerror "You need to install ${COMMAND}"
        usage
    fi
}

check_prereq "helm"

echo "Verifying Helm client"
set +o errexit
HELM_VERSION_OUTPUT=$(helm version --short)
set -o errexit

if ! echo ${HELM_VERSION_OUTPUT} | grep -E -q '^v3(.*)'; then
    echo "Only Helm version 3 is supported by this script. Please update your helm client"
fi

echo "Updating Helm repo"
helm repo add ${REPO_NAME} ${REPO_ADDRESS}
helm repo update > /dev/null 2>&1

echo "Fetching and extracting chart locally"
helm fetch ${REPO_NAME}/${CHART_NAME} --version ${CHART_VERSION} --untar

echo "Rendering Helm chart version: ${CHART_VERSION}"
helm template cluster ${CHART_NAME}  \
    --namespace ${NAMESPACE} \
    -f values-azure.yml > kustomize/global/all-in-one-resources.yml

rm -rf ${CHART_NAME}/

