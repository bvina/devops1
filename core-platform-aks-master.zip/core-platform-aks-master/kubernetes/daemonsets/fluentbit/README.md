# Fluent-bit Logging Agent
This directory contains all the configurations necessary to deploy Fluent-bit Logging Agent for windows nodes as a DaemonSet for AKS clusters.

For more details about how fluent-bit works: https://docs.fluentbit.io/manual/installation/windows

## Configuration
Use overlay kustomization file to create custom configurations per cluster. The agent also requires a HEC token, which is pulled down during deployment and updated in the configmap. 

```
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: fluent-bit
  labels:
    k8s-app: fluentbit-win
spec:
  selector:
    matchLabels:
      k8s-app: fluentbit-win
  template:
    metadata:
      labels:
        k8s-app: fluentbit-win
      name: fluentbit-win
      annotations: {}
    spec:
      containers:
      - image: eengccoelabacrcac1.azurecr.io/kyv0/centralized-logging/fluent-bit:1.5.0-nano
        imagePullPolicy: Always
        name: fluentbit-win
        command:
          - "fluent-bit.exe"
        args:
          - "-c"
          - "C:\\fluent-bit\\conf\\fluent-bit.conf"
        ports:
          - containerPort: 8088
```

## How to deploy fluentd?

Fluent-bit gets installed during AKS cluster deployment in its own namespace which is set in kustomization file. If you need to deploy it directly then you can run this script to install it:

```
./k8s-11-fluentbit-agent-windows.sh cluster/eng/stable/cac.conf
```

