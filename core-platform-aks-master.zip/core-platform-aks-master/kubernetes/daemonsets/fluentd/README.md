# Fluentd Logging Agent
This directory contains all the configurations necessary to deploy Fluentd Logging Agent as a DaemonSet for AKS clsuters.

For more details about how fluentd works: https://rbc-confluence.fg.rbc.com/display/AR/Node+level+logging+with+fluentd?focusedCommentId=65806090#comment-65806090

## Configuration
Use overlay kustomization file to create custom confiurations per cluster. The main configuration is related to the connectivity information to eventhub in `eventhub-connection.yaml`:

```
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: fluentd
spec:
  template:
    spec:
      containers:
        - name: fluentd
          env:
            - name:  connection_string
              valueFrom:
                secretKeyRef:
                  key: connection-string  <<--------- Secret is created in deployment script. It's the connection string to the eventhub namespace which can be found on the portal.
                  name: fluentd-secret
            - name: hub_name
              value: aks-central-logging-tets
```

## How to deploy fluentd?

Fluentd gets installed during AKS cluster deployment in its own namespace which is set in kustomization file. The deployment creates a secret for holding the connection string to the eventhub namespace. If you need to deploy it seperately then you can run this script to install it:

```
./k8s-04-logging-agent.sh cluster/eng/canadacentral/01.conf
```

