# Postgresflex Server Design

This is the design for the Postgresflex Server Core Pipeline Terraform module

# Requirements
See [Requirements](./REQUIREMENTS.md) for more information on the inputs to this design

# Resiliency
The module meets [resiliency requirements](./REQUIREMENTS.md#resiliency) as follows:

## Virtual Network 
 * The Virtual network in which the postgresflexible server needs to be deployed.

## Subnet deligated to postgres
* The subnet in which the postgresflexserver needs to be deployed. 
      Our flexible server must be in a subnet that's delegated. That is, only Azure Database for PostgreSQL - Flexible Server instances can use that subnet. No other Azure resource types can be in the delegated subnet. You delegate a subnet by assigning its delegation property as Microsoft.DBforPostgreSQL/flexibleServers. 

## HA and Failover
* Azure Database for PostgreSQL - Flexible Server offers high availability configurations with automatic failover capabilities.
When high availability is configured, flexible server automatically provisions and manages a standby replica.
There are two high availability architectural models: 
* Zone-redundant HA: This option provides a complete isolation and redundancy of infrastructure across multiple availability zones within a region. It provides the highest level of availability, but it requires us to configure application redundancy across zones.

* Same-zone HA: This option is preferred for infrastructure redundancy with lower network latency because the primary and standby servers will be in the same availability zone. It provides high availability without the need to configure application redundancy across zones.

## Failover modes
There are two failover modes.
* With planned failovers: 
(example: During maintenance window) where the failover is triggered with a known state in which the primary connections are drained, a clean shutdown is performed before the replication is severed. You can also use this to bring the primary server back to your preferred AZ.

* With unplanned failover (example: Primary server node crash), the primary is immediately fenced and hence any in-flight transactions are lost and to be retried by the application.

## Dns private zone 
 * When using private network access with Azure virtual network, providing the private DNS zone information is mandatory across various interfaces, including API, ARM, and Terraform. Therefore, for new Azure Database for PostgreSQL Flexible Server creation using private network access with API, ARM, or Terraform, create private DNS zones and use them while configuring flexible servers with private access
       ![dnslink] (https://docs.microsoft.com/en-us/azure/postgresql/flexible-serverconcepts-networking)

# Resources the module creates and manages
| Resources | Name | 
|------|--------|
| <a name="module_resource_group_server"></a> [Postgres\_flexserver\_resourcegroup](#module\Postgres\_flexserver\_resourcegroup) |e-dev-ccoe-frm0-shared-pgserver-server-rg-cac-1 | 
| <a name="module_resource_group_server"></a> [Postgressql server](#module\Postgres\_flexserver\_resourcegroup) | frm0-shared-dev-[random string] or user specified | 
| <a name="module_resource_group_server"></a> [Postgressql database](#module\Postgres\_flexserver\_resourcegroup) | user specified|
| <a name="module_resource_group_server"></a> [Log analytics workspace](#module\Postgres\_flexserver\_resourcegroup) | frm0-shared-dev-fjkyq6-log | 
| <a name="module_resource_group_server"></a> [Diagnostic settings for Postgresflex server](#module\Postgres\_flexserver\_resourcegroup) | frm0-shared-dev-[random string]-diagnostics or user specified| 

# Providers

| Name | Version |
|------|---------|
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | n/a |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.5.0 |
| <a name="provider_azurerm.dns_zone"></a> [azurerm.dns\_zone](#provider\_azurerm.dns\_zone) | ~>3.5.0 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | ~>2.0.0 |

# Modules Consumed

| Name | Source |  
|------|--------|
| <a name="module_resource_group"></a> [resource_group](#module\Postgres\_flexserver\_resourcegroup) | ./SHARED/common/azurerm//modules/resource_group | n/a |

# Variables
## Input Variables

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_postgresql_server_name"></a> [postgresql_server_name](#input\_aad\_admin\_enable) | The name of PG Server instance. | `string` | " " | Yes|
| <a name="input_Tier"></a> [Tier](#input\_aad\_admin\_login) |Tier for PostgreSQL Flexible server., <br>e.g., Possible values are: GeneralPurpose, Burstable, MemoryOptimized. ![sku] (https://docs.microsoft.com/en-us/azure/postgresql/flexible-server/concepts-compute-storage) | `string` | n/a | yes |
| <a name="input_size"></a> [Size](#input\_aad\_admin\_object\_id) | Size for PostgreSQL Flexible server. ![sku] (https://docs.microsoft.com/en-us/azure/postgresql/flexible-server/concepts-compute-storage) | `string` | n/a | yes |
| <a name="input_admin"></a> [Admin](#input\_aad\_admin\_tenant\_id) | PostgreSQL administrator login and password. | `string` | n/a | yes |
| <a name="input_storage_mb"></a> [storage_mb](#input\_akv\_user\_object\_ids) | Max storage allowed for a server. Possible values are between 5120 MB(5GB) and 1048576 MB(1TB)  for the Basic SKU <br> Between 5120 MB(5GB) and 4194304 MB(4TB) for General Purpose/Memory Optimized SKUs.| `int` | `[n\a]` | Yes |
| <a name="input_postgresql_version"></a> [postgresql_version](#input\_app\_code) | Valid values are 9.5, 9.6, 10, 10.0, and 11 | `int` | n/a | yes |
| <a name="input_backup_retention_days"></a> [backup_retention_days](#input\_app\_name) | Backup retention days for the server, supported values are between 7 and 35 days | `int` | n/a | yes |
| <a name="input_geo_redundant_backup_enabled"></a> [geo_redundant_backup_enabled](#input\_branch) | Turn Geo-redundant server backups on/off. Not available for the Basic tier | `bool` | `""` | no |
| <a name="input_zone"></a> [zone](#input\_data\_classification) | Specific availability-zone for PostgreSQL Flexible main Server. | `string` | n/a | yes |
<a name="input_standby_zone"></a> [standby_zone](#input\_aad\_admin\_enable) |Specify availability-zone to enable high_availability and create standby PostgreSQL Flexible Server. | `string` | "n/a" | Yes|
| <a name="input_maintenance_window"></a> [maintenance_window](#input\_deployment\_number) | Map of maintenance window configuration.  | `int` | `n/a` | yes |
| <a name="input_Tags"></a> [Tags](#input\_deployment\_number) | Tags for all resources.  | `string` | `n/a` | yes |
| <a name="input_portfolio"></a> [portfolio](#input\_deployment\_number) | The AKV portfolio..  | `string` | `n/a` | yes |
| <a name="input_service_tier"></a> [service_tier](#input\_deployment\_number) | The service tier where AKV deployed.  | `string` | `n/a` | yes |
| <a name="input_environment"></a> [environment](#input\_deployment\_number) | The environment where AKV deployed.  | `string` | `n/a` | yes |
| <a name="input_app_code"></a> [app_code](#input\_deployment\_number) | The App Code for AKV.  | `string` | `n/a` | yes |
| <a name="input_app_name"></a> [app_name](#input\_deployment\_number) | The App Name for AKV.  | `string` | `n/a` | yes |
| <a name="input_branch"></a> [branch](#input\_deployment\_number) |  The branch name for AKV.  | `string` | `n/a` | yes |
| <a name="input_postgresql_configurations"></a> [postgresql_configurations](#input\_deployment\_number) | PostgreSQL configurations to enable.  | `string` | `n/a` | yes |
| <a name="input_postresql_resource_group_name"></a> [postresql_resource_group_name](#input\_deployment\_number) | The name of postgres rg name. | `string` | `n/a` | yes |
| <a name="input_postresql_resource_group_location"></a> [postresql_resource_group_location](#input\_deployment\_number) |  The name of postgres rg location.  | `string` | `n/a` | yes 
| <a name="input_databases_names"></a> [databases_names](#input\_database\_names) | List of databases names to create| `string` | `n/a` | yes |
| <a name="input_databases_charset"></a> [databases_charset](#input\_databases\_charset_) |Valid PostgreSQL charset : https://www.postgresql.org/docs/current/multibyte.html#CHARSET-TABLE.  | `string` | `n/a` | yes |
| <a name="input_databases_collation"></a> [databases_collation](#input\_databases\_collation) | Valid PostgreSQL collation : http://www.postgresql.cn/docs/13/collation.html - be careful about https://docs.microsoft.com/en-us/windows/win32/intl/locale-names?redirectedfrom=MSDN. | `string` | `n/a` | yes |
| <a name="postgresql_metric_settings"></a> [postgresql_metric_settings](#input\_postgresql_\metric_\settings) | A list of valid diagnostic metric categories and associated settings to enable for the instance. See Logging and Monitoring in the README.md file for more information. | `string` | `n/a` | yes |
| <a name="input_postgresql_log_settings"></a> [postgresql_postgresql_log_settings](#input\_postgresql\_log\_settings) | A list of valid diagnostic log categories and associated settings to enable for the instance. See Logging and Monitoring in the README.md file for more information. | `string` | `n/a` | yes |
| <a name="input_postgresql_log_name"></a> [postgresql_log_name](#input\_postgresql_log_name) | The name of PG log analytics| `string` | `n/a` | yes |
| <a name="input_leaf_resources"></a> [leaf\_resources](#input\_leaf\_resources) | This module requires certain resources to be created outside of the module<br>and requires some address information.<br>In particular, it requires the VNET resource group, VNET, and one subnet<br>to be created. This is currently done by the FRM0-Shared/core-pipeline-Gient-networking component.<br>   - **network\_rg\_name** Name of the resource group containing the VNET<br>   - **network\_name** Name of the VNET<br>   - **postgresql_subnet_name** <br> | <pre>object({<br> main_resource_group_name = string<br>virtual_network_resource_group_name = string<br> virtual_network_name = string<br>  postgresql_subnet_name = string<br>  })</pre> | n/a   | yes |


## Output Variables

| Name | Description |
|------|-------------|
| <a name="output_postgresql_server_id"></a> [postgresql_server_id](#output\_admin\_key\_vault\_id) | The ID of PG Server |
<br>

# Architecture Diagram
Work with Tim to create one or more architecture diagrams to be used in the design doc
Issue a PR to review it.

Preference is for such diagrams to be part of the formal [Core Pipeline ArchiMate model](https://rbcgithub.fg.rbc.com/FRM0/core-pipeline-model), so we can have consistent, source-controlled diagrams like the one in the [SQL MI module's README.md](https://rbcgithub.fg.rbc.com/FRM0-Shared/terraform-azurerm-sql-managed-instance/blob/master/README.md#89-architecture-overview)
