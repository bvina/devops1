# Requirements for module Postgresflex Server 

These are the known requirements for the Postgresflex server module. Generally, these consist of a combination of requirements coming from the product, security and SRE teams, plus any requirements specific to the platform team.

# Product Requirements

See [Azure Postgresflex server  Product Requrements](https://rbc-confluence.fg.rbc.com/display/AR/Azure+PostgreSQL+DB+Requirements) for the list of product requirements.

# Security Requirements

See [Azure Postgresflex Server  Security Requirements](https://rbc-confluence.fg.rbc.com:8443/pages/viewpage.action?pageId=36112610) for the GCS review of Postgresflex server.

> Note, you must be a member of the APP_CQF0_CQF1_CLOUDSEC_SHARED AD group to access the GCS security pages.

# SRE Requirements
The SRE requirements generally consist of ensuring that the items in the [SRE Checklist template ](https://rbc-confluence.fg.rbc.com:8443/pages/viewpage.action?pageId=427384892)are met by the module. When a module commences SRE review, the SRE team will create a new checklist from the template, just for the new module. These can be found [here](https://rbc-confluence.fg.rbc.com:8443/display/AR/SRE+Score+Card)


## Other SRE requirements to consider
* [Public Cloud Resiliency Principals](https://rbc-confluence.fg.rbc.com:8443/display/AR/Public+Cloud+Resiliency+Principles)
