package test

import (
	"fmt"
	"github.com/gruntwork-io/terratest/modules/files"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"os"
	"testing"
	"time"
)

func TestModule(t *testing.T) {
	t.Parallel()

	testFolder, err := files.CopyTerraformFolderToTemp("./resources/main", t.Name())
	if err != nil {
		t.Fatal(err)
	}
	options := &terraform.Options{
		TerraformDir: testFolder,
		EnvVars: map[string]string{
			"TF_CLI_CONFIG_FILE":  "./terraform.tfrc",
			"PORTFOLIO":           os.Getenv("PORTFOLIO"),
			"APP_CODE":            os.Getenv("APP_CODE"),
			"APP_NAME":            os.Getenv("APP_NAME"),
			"BRANCH":              os.Getenv("BRANCH"),
			"SERVICE_TIER":        os.Getenv("SERVICE_TIER"),
			"ENVIRONMENT":         os.Getenv("ENVIRONMENT"),
			"API_HOSTNAME":        os.Getenv("API_HOSTNAME"),
			"ARM_TENANT_ID":       os.Getenv("ARM_TENANT_ID"),
			"ARM_SUBSCRIPTION_ID": os.Getenv("ARM_SUBSCRIPTION_ID"),
			"ARM_CLIENT_ID":       os.Getenv("ARM_CLIENT_ID"),
			"ARM_CLIENT_SECRET":   os.Getenv("ARM_CLIENT_SECRET"),
			"ONBOARD_AUTH_ID":     os.Getenv("ONBOARD_AUTH_ID"),
			"TF_LOG":              os.Getenv("TF_LOG"),
			"TF_CLI_ARGS":         os.Getenv("-plugin-dir=/home/jenkins2/.terraform.d/plugins"),
		},
		NoColor: true,
	}
	_mainOpts := terraform.WithDefaultRetryableErrors(t, options)
	print("\n\n\n\t***** Terraform PLAN Phase. *****\n\n\n")
	fmt.Printf("\n\n\nTF_LOG set as %v\n\n\n", os.Getenv("TF_LOG"))
	terraform.InitAndPlan(t, _mainOpts)

	runApplyOnly := os.Getenv("APPLY_ONLY")
	if len(runApplyOnly) != 0 && runApplyOnly == "true" {
		print("\n\n\t***** WARNING: Terraform Destroy phase is disabled. *****\n\n")
	} else {
		defer print("\n\n\n\t***** Terraform DESTROY Phase. *****\n\n\n")
		defer terraform.Destroy(t, _mainOpts)
	}
	print("\n\n\n\t***** Terraform APPLY Phase. *****\n\n\n")
	terraform.Apply(t, _mainOpts)

	time.Sleep(100)

	// Collect output and run assertions.
	output := make(map[string]interface{})
	terraform.OutputStruct(t, options, "", &output)

	assert.NotNil(t, output)
	
	assert.NotEmpty(t, output["location"])

}
