# CosmosDB Terraform Custom Module

This Terraform module creates an [Azure Cosmos DB](https://docs.microsoft.com/en-us/azure/cosmos-db/).

## Usage Guide

For sample deployment refer to the [Terratest module](test/resources/main) that deploys a Storage account using the terraform-azurerm-storage-account module.

## Resources

| Name                                                                                                                                                                              | Type        |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| [azurerm_key_vault.storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account)                                              | resource    |
| [azurerm_key_vault_access_policy.storage_key](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key)                                      | resource    |
| [azurerm_storage_account.storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account)                                        | resource    |
| [azurerm_storage_account_customer_managed_key.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/azurerm_storage_account_customer_managed_key) | resource    |
| [azurerm_storage_container.container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/azurerm_storage_container)                                  | resource    |
| [random_string.string](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string)                                                                     | resource    |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config)                                                 | data source |
| corepipeline_client_registry.app_data                                                                                                                                             | data source |


<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.18 |
| <a name="requirement_corepipeline"></a> [corepipeline](#requirement\_corepipeline) | 2.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >=3.18 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | 2.0.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [random_string.string](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_key_vault.keyvault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault) | data source |
| [azurerm_resource_group.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/resource_group) | data source |
| [azurerm_subnet.pep](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |
| corepipeline_client_registry.client_data | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_code"></a> [app\_code](#input\_app\_code) | The App Code for storage account. | `string` | `""` | no |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | The App Name for storage account. | `string` | `""` | no |
| <a name="input_branch"></a> [branch](#input\_branch) | The branch name (Optional). | `string` | `""` | no |
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | App Code data classfication. | `string` | n/a | yes |
| <a name="input_deployment_number"></a> [deployment\_number](#input\_deployment\_number) | Deployment number. | `string` | `"1"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment where storage account will be deployed. | `string` | `"dev"` | no |
| <a name="input_key_vault_name"></a> [key\_vault\_name](#input\_key\_vault\_name) | The name of the existing application key vault to manage Customer-managed-Encryption Key. | `string` | n/a | yes |
| <a name="input_keyvault_resource_group_name"></a> [keyvault\_resource\_group\_name](#input\_keyvault\_resource\_group\_name) | The name of the resource group of the existing key vault for storing the Customer-managed-Encryption Key. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The Azure region to deploy resources. e.g. canadacentral | `string` | n/a | yes |
| <a name="input_portfolio"></a> [portfolio](#input\_portfolio) | The Application portfolio. | `string` | `"ccoe"` | no |
| <a name="input_private_endpoint_subnet_name"></a> [private\_endpoint\_subnet\_name](#input\_private\_endpoint\_subnet\_name) | The name of the virtual network private endpoint subnet. Defaults to "pep". (Optional) | `string` | `"pep"` | no |
| <a name="input_service_tier"></a> [service\_tier](#input\_service\_tier) | The service tier where storage account will be deployed. | `string` | `"e"` | no |
| <a name="input_shared_access_key_enabled"></a> [shared\_access\_key\_enabled](#input\_shared\_access\_key\_enabled) | Enable Shared Access Key on Storage account. (Optional) Default: false | `bool` | `true` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for all resources. | `map(string)` | `{}` | no |
| <a name="input_virtual_network_name"></a> [virtual\_network\_name](#input\_virtual\_network\_name) | The name of the existing virtual network with private endpoint subnet. | `string` | n/a | yes |
| <a name="input_virtual_network_resource_group_name"></a> [virtual\_network\_resource\_group\_name](#input\_virtual\_network\_resource\_group\_name) | The name of the existing resource group of the virtual network with Private endpoint subnet. | `string` | n/a | yes |
| <a name="input_whitelist_subnet_ids"></a> [whitelist\_subnet\_ids](#input\_whitelist\_subnet\_ids) | List of Virtual network Subnet IDs that need direct access to the PaaS in the Vnet. (Optional). | `list(string)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_storage_rg_name"></a> [storage\_rg\_name](#output\_storage\_rg\_name) | Resource Group name for the Storage account. |
<!-- END_TF_DOCS -->