# Azure Cosmos DB Design

This is the design for the Azure Cosmos DB Core Pipeline Terraform module

> Author: Ronen Rotstain

# Requirements
See [Requirements](./REQUIREMENTS.md) for more information on the inputs to this design

# Resiliency
The module meets [resiliency requirements](./REQUIREMENTS.md#resiliency) in the following ways.

Cosmos DB is a managed multi-tenant service that manages each compute node's specifics in a transparent manner. Users don't need to worry about any sort of planned maintenance or patching. With regard to P99 latency and availability, Cosmos DB provides SLAs for both through all routine system maintenance procedures.

The Cosmos DB service built through this module uses zone redundancy, and due to availability zones' physical separation and provision of independent power sources, networks, and cooling, this increases SLAs.

## Zonal Redundency

This module enforces zonal redundancy for production environments. Additionally, it also allows users to specify zonal redundancy for pre-production environments via a Terraform variable. Note that zonal redundancy allows for RTO = 0 and RPO = 0 even in a zone outage.

More information about Cosmos DB zonal redundancy can be found [here](https://learn.microsoft.com/en-us/azure/cosmos-db/high-availability#replica-outages).

## Data Replication

Azure Cosmos DB transparently replicates data to all the regions associated with your Cosmos account. This adds a distinct benefit to production workloads since geo-redundancy is enforced.

## DNS updates 
The Azure Cosmos DB module allows for applications to call it via an internal IP address. Specifically, a private endpoint is created for the Cosmos DB resource. This private endpoint is assigned an internal IP address. Of course, callers would prefer to use a friendly FQDN name to connect to Cosmos DB. To that end, an `A` record is inserted into the Private DNS Zone resource `privatelink.mongo.cosmos.azure.com` that is passed into the module via the `private_dns_zone_resource_group_name` attribute (this resource group must host a Private DNS Zone resource with the name `privatelink.mongo.cosmos.azure.com`).  As a result, after the DNS entry, callers can use the name `<cosmos_db_account_name>.privatelink.mongo.cosmos.azure.com` to access Cosmos (Mongo) DB.

## Recovery Times (RTO and RPO)
By assuring at least three replicas of your data in each Azure region for your account within a quorum of four replicas, Cosmos DB automatically reduces replica outages. As a result, no modifications to the application or configurations are needed to achieve RTO = 0 and RPO = 0 for individual node failures.

## Logging Source and Sink
This module creates a dedicated Azure Log Analytics Workspace resource to collect Cosmos DB logs.  The number of days for log retention and the quota per day are both configurable via terraform variables. A diagnostic setting is also created to actually ship logs to the Log Analytics Workspace.  The categories that are included for log collection are `DataPlaneRequests`, `MongoRequests`, `PartitionKeyStatistics`, and `ControlPlaneRequests`.

# Resources the module creates and manages
| Resource        | Name (example)           | Notes |
| ------------- |:-------------:| -----:|
| Azure Resource Group| `n-nonp-ccoe-abc0-myapp-app-rg-cac-1`  | Contains the X, Y and Z resources. Creates using the Core Pipeline Resource Group module |
| Azure Resource Group| `n-nonp-ccoe-abc0-myapp-app-myresource-cac-1`  | single instance of MyResource |

# Modules Consumed
This module does not consume any other modules.

# Variables
## Input Variables
> Author: List the input variables. Don't bother formatting these much, because this will be done 
> by Terradoc (triggered by running `make`) when the module's README.md file is processed and the variable docs are injected.
 
| Variable      | Description
| ------------- |------------- | 
| leaf_resources| Information about the destination VNET and Subnet for resources this module creates |

## Output Variables
> Author: Same story as for input variables

# Architecture Diagram
Work with Tim to create one or more architecture diagrams to be used in the design doc
Issue a PR to review it.

Preference is for such diagrams to be part of the formal [Core Pipeline ArchiMate model](https://rbcgithub.fg.rbc.com/FRM0/core-pipeline-model), so we can have consistent, source-controlled diagrams like the one in the [SQL MI module's README.md](https://rbcgithub.fg.rbc.com/FRM0-Shared/terraform-azurerm-sql-managed-instance/blob/master/README.md#89-architecture-overview)