# Requirements for module Azure Cosmos DB

These are the known requirements for the Azure Cosmos DB module. Generally, these consist of a combination of requirements coming from the product, security and SRE teams, plus any requirements specific to the platform team.

> Author: Ronen Rotstain

# Product Requirements

See [Azure Cosmos DB Product Requrements](https://rbc-confluence.fg.rbc.com/display/AR/Azure+Cosmos+DB+API+for+MongoDB++Requirements) for the list of product requirements.

# Security Requirements

See [Azure Cosmos DB Security Requirements](https://rbc-confluence.fg.rbc.com/display/AR/Azure+Cosmos+DB+API+for+MongoDB++Requirements) for the GCS review of Azure Cosmos DB. 

> Note, you must be a member of the APP_CQF0_CQF1_CLOUDSEC_SHARED AD group to access the GCS security pages.

# SRE Requirements
The SRE requirements generally consist of ensuring that the items in the [SRE Checklist template ](https://rbc-confluence.fg.rbc.com:8443/pages/viewpage.action?pageId=427384892)are met by the module. When a module commences SRE review, the SRE team will create a new checklist from the template, just for the new module. These can be found [here](https://rbc-confluence.fg.rbc.com:8443/display/AR/SRE+Score+Card)

# Resiliency
The module meets [resiliency requirements](./REQUIREMENTS.md#resiliency) in the following ways.

Cosmos DB is a managed multi-tenant service that manages each compute node's specifics in a transparent manner. Users don't need to worry about any sort of planned maintenance or patching. With regard to P99 latency and availability, Cosmos DB provides SLAs for both through all routine system maintenance procedures.

The Cosmos DB service built through this module uses zone redundancy, and due to availability zones' physical separation and provision of independent power sources, networks, and cooling, this increases SLAs.

## ...

## Other SRE requirements to consider
* [Public Cloud Resiliency Principals](https://rbc-confluence.fg.rbc.com:8443/display/AR/Public+Cloud+Resiliency+Principles)

# Other requirements
> Author: Capture any other requirements here
