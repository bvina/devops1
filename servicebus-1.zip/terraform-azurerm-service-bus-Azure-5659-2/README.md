# Azure Service Bus
This Terraform module creates an [Azure Service Bus](https://docs.microsoft.com/en-us/azure/service-bus/).

## Requirements

| Name | Version |
|------|---------|
| [azurerm](#requirement\_azurerm) | >=3.4.0 |
| [corepipeline](#requirement\_corepipeline) | >=1.0.0 |

## Version compatibility

| Module version | Terraform version | AzureRM version |
| -------------- | ----------------- | --------------- |
| >= 5.x.x       | 0.15.x & 1.0.x    | >= 2.0          |
| >= 4.x.x       | 0.13.x            | >= 2.0          |
| >= 3.x.x       | 0.12.x            | >= 2.0          |
| >= 2.x.x       | 0.12.x            | < 2.0           |
| <  2.x.x       | 0.11.x            | < 2.0           |

## Usage

You can use this reference for the module: 
[Terratest module](https://rbcgithub.fg.rbc.com/FRM0-Shared/terraform-azurerm-service-bus/blob/Azure-5659/test/resources/main/main.tf)

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.5.0 |
| <a name="requirement_corepipeline"></a> [corepipeline](#requirement\_corepipeline) | 2.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >=3.5.0 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | 2.0.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_required_tags"></a> [required\_tags](#module\_required\_tags) | ./common_modules/modules/required_tags | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_access_policy.sb](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_key.sb_key](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key) | resource |
| [azurerm_private_dns_a_record.servicebus](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_a_record) | resource |
| [azurerm_private_endpoint.pe_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_servicebus_namespace.servicebus_namespace_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace) | resource |
| [azurerm_servicebus_queue.queue_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue) | resource |
| [azurerm_servicebus_queue_authorization_rule.manage_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue_authorization_rule) | resource |
| [azurerm_servicebus_queue_authorization_rule.reader_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue_authorization_rule) | resource |
| [azurerm_servicebus_queue_authorization_rule.sender_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue_authorization_rule) | resource |
| [azurerm_servicebus_subscription.subscriptions](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_subscription) | resource |
| [azurerm_servicebus_topic.topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic) | resource |
| [azurerm_servicebus_topic_authorization_rule.manage_topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic_authorization_rule) | resource |
| [azurerm_servicebus_topic_authorization_rule.reader_topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic_authorization_rule) | resource |
| [azurerm_servicebus_topic_authorization_rule.sender_topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic_authorization_rule) | resource |
| [azurerm_user_assigned_identity.sb](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_key_vault.keyvault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault) | data source |
| [azurerm_subnet.sb](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| [azurerm_subscription.primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |
| corepipeline_client_registry.client_data | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_code"></a> [app\_code](#input\_app\_code) | Client name/account used in naming | `string` | n/a | yes |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | The App Name for storage account. | `string` | `""` | no |
| <a name="input_branch"></a> [branch](#input\_branch) | The branch name (Optional). | `string` | `""` | no |
| <a name="input_compliance"></a> [compliance](#input\_compliance) | RBC data compliance. | `string` | `"N/A"` | no |
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | App data classfication. | `string` | `"internal"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Project environment | `string` | n/a | yes |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | Extra tags to add | `map(string)` | `{}` | no |
| <a name="input_location"></a> [location](#input\_location) | Azure location for Servicebus. | `string` | n/a | yes |
| <a name="input_location_short"></a> [location\_short](#input\_location\_short) | Short string for Azure location. | `string` | n/a | yes |
| <a name="input_portfolio"></a> [portfolio](#input\_portfolio) | The Application portfolio. | `string` | `"ccoe"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Name of the resource group | `string` | n/a | yes |
| <a name="input_service_tier"></a> [service\_tier](#input\_service\_tier) | The service tier where storage account will be deployed. | `string` | `"e"` | no |
| <a name="input_servicebus_namespaces_queues"></a> [servicebus\_namespaces\_queues](#input\_servicebus\_namespaces\_queues) | Map to handle Servicebus creation. It supports the creation of the queues, authorization\_rule associated with each namespace you create | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_manages"></a> [manages](#output\_manages) | Service Bus "managers" authorization rules map |
| <a name="output_namespaces"></a> [namespaces](#output\_namespaces) | Service Bus namespaces map |
| <a name="output_queues"></a> [queues](#output\_queues) | Service Bus queues map |
| <a name="output_readers"></a> [readers](#output\_readers) | Service Bus "readers" authorization rules map |
| <a name="output_senders"></a> [senders](#output\_senders) | Service Bus "sender" authorization rules map |
<!-- END_TF_DOCS -->
