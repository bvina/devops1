# Azure Core Common feature

A Terraform modules composition (feature) which includes services needed for Core/Terraform Pipeline.

It includes:
* Azure Regions module
* Resource Group module with locking mechanism

## Requirements

* [PowerShell with Az module](https://docs.microsoft.com/en-us/powershell/azure/install-Az-ps?view=azps-3.6.1) >= 3.6 is mandatory and is used to configure IIS logs collect in Azure Monitor

## Using sub-modules

### Regions

See `regions` sub-module [README](modules/regions/README.md).


### Resource Group

See `resource_group` sub-module [README](./modules/resource_group/README.md).


### Tags

See `tags` sub-module [README](./modules/required_tags/README.md).

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_regions"></a> [regions](#module\_regions) | modules/regions | n/a |
| <a name="module_required_tags"></a> [required\_tags](#module\_required\_tags) | modules/required_tags | n/a |
| <a name="module_resource_group"></a> [resource\_group](#module\_resource\_group) | ./modules/resource_group | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_code"></a> [app\_code](#input\_app\_code) | The App Code for RG. | `string` | `""` | no |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | The App Name for RG. | `string` | `""` | no |
| <a name="input_azure_region"></a> [azure\_region](#input\_azure\_region) | Azure Region standard name, CLI name or slug format | `string` | `"can-central"` | no |
| <a name="input_compliance"></a> [compliance](#input\_compliance) | RBC data compliance. | `string` | `"N/A"` | no |
| <a name="input_custom_rg_name"></a> [custom\_rg\_name](#input\_custom\_rg\_name) | Optional custom resource group name | `string` | `""` | no |
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | RBC data classification. | `string` | `"internal"` | no |
| <a name="input_default_tags_enabled"></a> [default\_tags\_enabled](#input\_default\_tags\_enabled) | Option to enable or disable default tags. | `bool` | `true` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment where RG deployed. | `string` | `"dev"` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | Extra tags to add. | `map(string)` | `{}` | no |
| <a name="input_location"></a> [location](#input\_location) | Azure region to use | `string` | `"can-central"` | no |
| <a name="input_lock_level"></a> [lock\_level](#input\_lock\_level) | Specifies the Level to be used for this RG Lock. Possible values are Empty (no lock), CanNotDelete and ReadOnly. | `string` | `""` | no |
| <a name="input_name_prefix"></a> [name\_prefix](#input\_name\_prefix) | Optional prefix for the generated name | `string` | `""` | no |
| <a name="input_name_suffix"></a> [name\_suffix](#input\_name\_suffix) | Optional suffix for the generated name | `string` | `""` | no |
| <a name="input_service_tier"></a> [service\_tier](#input\_service\_tier) | The service tier where RG deployed. | `string` | `"e"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_location"></a> [location](#output\_location) | Azure region in standard format |
| <a name="output_location_cli"></a> [location\_cli](#output\_location\_cli) | Azure region in Azure CLI name format |
| <a name="output_location_short"></a> [location\_short](#output\_location\_short) | Azure region in short format for resource naming purpose |
| <a name="output_location_slug"></a> [location\_slug](#output\_location\_slug) | Azure region in slug format |
| <a name="output_required_tags"></a> [required\_tags](#output\_required\_tags) | required tags value |
| <a name="output_resource_group_id"></a> [resource\_group\_id](#output\_resource\_group\_id) | Resource group generated id |
| <a name="output_resource_group_location"></a> [resource\_group\_location](#output\_resource\_group\_location) | Resource group location (region) |
| <a name="output_resource_group_name"></a> [resource\_group\_name](#output\_resource\_group\_name) | Resource group name |
<!-- END_TF_DOCS -->
## Related documentation
