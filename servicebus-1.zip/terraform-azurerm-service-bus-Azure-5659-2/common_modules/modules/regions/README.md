# Azure regions module

This Terraform module is designed to help in using the AzureRM terraform provider.


Please refer to the [regions.tf](regions.tf) file for available regions.
Complete regions mapping is also available in [REGIONS.md](REGIONS.md) documentation.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.18 |

## Providers

No providers.

## Modules

No modules.

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_azure_region"></a> [azure\_region](#input\_azure\_region) | Azure Region standard name, CLI name or slug format | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_location"></a> [location](#output\_location) | Azure region in standard format |
| <a name="output_location_cli"></a> [location\_cli](#output\_location\_cli) | Azure region in Azure CLI name format |
| <a name="output_location_short"></a> [location\_short](#output\_location\_short) | Azure region in short format for resource naming purpose |
| <a name="output_location_slug"></a> [location\_slug](#output\_location\_slug) | Azure region in slug format |
<!-- END_TF_DOCS -->

## Related documentation

Azure regions: [azure.microsoft.com/en-us/global-infrastructure/regions/](https://azure.microsoft.com/en-us/global-infrastructure/regions/)
