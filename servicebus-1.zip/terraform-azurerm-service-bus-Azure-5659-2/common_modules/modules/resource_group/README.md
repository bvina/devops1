# Azure resource group module

Common Azure terraform module to create a Resource Group with optional lock.


<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.18 |
| <a name="requirement_corepipeline"></a> [corepipeline](#requirement\_corepipeline) | 2.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >=3.18 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | 2.0.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_required_tags"></a> [required\_tags](#module\_required\_tags) | ../required_tags | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_management_lock.resource_group_level_lock](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/management_lock) | resource |
| [azurerm_resource_group.main_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |
| corepipeline_client_registry.client_info | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_code"></a> [app\_code](#input\_app\_code) | App Code for RG. | `string` | `""` | no |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | App Name for RG. | `string` | `""` | no |
| <a name="input_branch"></a> [branch](#input\_branch) | The deployment branch. | `string` | `"master"` | no |
| <a name="input_compliance"></a> [compliance](#input\_compliance) | Application data compliance. | `string` | `"N/A"` | no |
| <a name="input_custom_rg_name"></a> [custom\_rg\_name](#input\_custom\_rg\_name) | Optional custom resource group name | `string` | `""` | no |
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | Application data classification. | `string` | `"internal"` | no |
| <a name="input_deployment_number"></a> [deployment\_number](#input\_deployment\_number) | The deployment number. | `number` | `1` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Environment where RG deployed. | `string` | `"dev"` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | Extra tags to add. | `map(string)` | `{}` | no |
| <a name="input_location"></a> [location](#input\_location) | Azure full name region. | `string` | n/a | yes |
| <a name="input_location_short"></a> [location\_short](#input\_location\_short) | Short Azure region. | `string` | n/a | yes |
| <a name="input_lock_level"></a> [lock\_level](#input\_lock\_level) | Specifies the Level to be used for this RG Lock. Possible values are Empty (no lock), CanNotDelete and ReadOnly. | `string` | `""` | no |
| <a name="input_name_prefix"></a> [name\_prefix](#input\_name\_prefix) | Optional prefix for the generated name | `string` | `""` | no |
| <a name="input_name_suffix"></a> [name\_suffix](#input\_name\_suffix) | Optional suffix for the generated name | `string` | `""` | no |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | The Namespace for RG. | `string` | `"rg"` | no |
| <a name="input_portfolio"></a> [portfolio](#input\_portfolio) | RG portfolio. | `string` | `"ccoe"` | no |
| <a name="input_service_tier"></a> [service\_tier](#input\_service\_tier) | Service tier where RG deployed. | `string` | `"e"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_resource_group_id"></a> [resource\_group\_id](#output\_resource\_group\_id) | Resource group generated id |
| <a name="output_resource_group_location"></a> [resource\_group\_location](#output\_resource\_group\_location) | Resource group location (region) |
| <a name="output_resource_group_name"></a> [resource\_group\_name](#output\_resource\_group\_name) | Resource group name |
| <a name="output_tags"></a> [tags](#output\_tags) | n/a |
<!-- END_TF_DOCS -->

## Related documentation

