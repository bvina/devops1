
# Azure service bus Design

# Table of Contents <!-- omit in toc -->
- [1.Overview](#overview)
- [2.Requirements](#requirements)
- [3.Features and Capabilities](#features-and-capabilities)
    * [3.1 servicebus](#servicebus)
    * [3.2 queues](#queues)
    * [3.3 toipcs](#topics)
- [4.Providers](#providers)
- [5.Modules consumed](#modules-consumed)
- [6.Resources](#resources)
- [7.Resources-the-module-creates-and-manages](#resources-the-module-creates-and-manages)
- [8.Input variables](#input-variables)
- [9.Output variables](#output-variables)
- [10.Architecture Overview](#architecture-diagram)


# Azure Service Bus Overview 
This Terraform module creates an [Azure Service Bus](https://docs.microsoft.com/en-us/azure/service-bus/).

# Features and Capabilities
## ServiceBus
Azure Service Bus is a fully managed enterprise message broker with message queues and publish-subscribe topics (in a namespace). Service Bus is used to decouple applications and services from each other.
Data is transferred between different applications and services using messages.

## Queues
Messages are sent to and received from queues. Queues store messages until the receiving application is available to receive and process them.

## Topics
 we can also use topics to send and receive messages. Topics are useful in publish/subscribe scenarios.

## Version compatibility

| Module version | Terraform version | AzureRM version |
| -------------- | ----------------- | --------------- |
| >= 5.x.x       | 0.15.x & 1.0.x    | >= 2.0          |
| >= 4.x.x       | 0.13.x            | >= 2.0          |
| >= 3.x.x       | 0.12.x            | >= 2.0          |
| >= 2.x.x       | 0.12.x            | < 2.0           |
| <  2.x.x       | 0.11.x            | < 2.0           |

<!-- BEGIN_TF_DOCS -->

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | n/a |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.5.0 |
| <a name="provider_azurerm.dns_zone"></a> [azurerm.dns\_zone](#provider\_azurerm.dns\_zone) | ~>3.5.0 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | ~>2.0.0 |

### Modules consumed

| Name | Source |  
|------|--------|
| <a name="module_resource_group"></a> [resource_group](#module\Postgres\_flexserver\_resourcegroup) | qat.canadacentral.tfe.nonp.c1.rbc.com/SHARED/common/azurerm//modules/resource_group | n/a |
| <a name="module_resource_group"></a> [key_vault](#module\Postgres\_flexserver\_resourcegroup) | qat.canadacentral.tfe.nonp.c1.rbc.com/SHARED/keyvault/azurerm | n/a |

## Resources the module creates and manages
| Name | Type |
|------|------|
| [azurerm_key_vault_access_policy.sb](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_key.sb_key](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key) | resource |
| [azurerm_private_dns_a_record.servicebus](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_a_record) | resource |
| [azurerm_private_endpoint.pe_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_servicebus_namespace.servicebus_namespace_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace) | resource |
| [azurerm_servicebus_queue.queue_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue) | resource |
| [azurerm_servicebus_queue_authorization_rule.manage_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue_authorization_rule) | resource |
| [azurerm_servicebus_queue_authorization_rule.reader_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue_authorization_rule) | resource |
| [azurerm_servicebus_queue_authorization_rule.sender_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue_authorization_rule) | resource |
| [azurerm_servicebus_topic.topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic) | resource |
| [azurerm_servicebus_topic_authorization_rule.manage_topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic_authorization_rule) | resource |
| [azurerm_servicebus_topic_authorization_rule.reader_topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic_authorization_rule) | resource |
| [azurerm_servicebus_topic_authorization_rule.sender_topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic_authorization_rule) | resource |
| [azurerm_user_assigned_identity.sb](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [corepipeline_client_registry.client_data](corepipeline_client_registry.client_data)| data source |

## Input variables

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| [private\_endpoint\_subnet\_name](#input\_private\_endpoint\_subnet\_name) | The name of the virtual network, for private endpoint | `string` | `"pep"` | no |
| [virtual\_network\_name](#input\_virtual\_network\_name) | The name of the virtual network, for private endpoint | `string` | n/a | yes |
| [virtual\_network\_resource\_group\_name](#input\_virtual\_network\_resource\_group\_name) | The name of the resource group of the virtual network | `string` | n/a | yes |
| [servicebus\_namespaces\_queues](#input\_servicebus\_namespaces\_queues) | Map to handle Servicebus creation. It supports the creation of the queues, authorization\_rule associated with each namespace you create | `any` | n/a | yes |
| [location](#input\_location) | Azure location for Servicebus | `string` | `"canadacentral"` | no |
| [resource\_group\_name](#input\_resource\_group\_name) | Name of the resource group | `string` | n/a | yes |
| [sku](#input\_sku) | Defines which tier to use. Options are Basic, Standard or Premium. Please note that setting this field to Premium will force the creation of a new resource. | `string` | `"Premium"` | no |
| [capacity](#input\_capacity) | Specifies the capacity. When sku is Premium, capacity can be 1, 2, 4, 8 or 16. When sku is Basic or Standard, capacity can be 0 only | `number` | `2` | no |
| [zone\_redundant](#input\_zone\_redundant) | Whether or not this resource is zone redundant. sku needs to be Premium. Defaults to false | `bool` | `true` | no |
| [local\_auth\_enabled](#input\_local\_auth\_enabled) | Whether or not SAS authentication is enabled for the Service Bus namespace. | `bool` | `false` | no |
| [extra\_tags](#input\_extra\_tags) | Extra tags to add | `map(string)` | `{}` | no |
| [app\_code](#input\_app\_code) | Client name/account used in naming | `string` | n/a | yes |
| [environment](#input\_environment) | Project environment | `string` | n/a | yes |
| [data\_classification](#input\_data\_classification) | App data classfication. | `string` | `"internal"` | no |
| [service\_tier](#input\_service\_tier) | The service tier where AKV deployed. | `string` | `"n"` | no |
| [keyvault\_resource\_group\_name](#input\_keyvault\_resource\_group\_name) | The name of the resource group of the existing key vault for storing the Customer-managed-Encryption Key. | `string` | n/a | yes |
| [key\_vault\_name](#input\_key\_vault\_name) | The name of the existing application key vault to manage Customer-managed-Encryption Key. | `string` | n/a | yes |
| [key\_vault\_id](#input\_key\_vault\_id) | The ID of the Key Vault Key which should be used to Encrypt the data in this ServiceBus Namespace. | `string` | n/a | yes |
| [sb\_identity](#input\_sb\_identity) | Service bus Managed Identity. Defaults to SystemAssigned. Possible types are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both) | identity_type = string | "identity_type": "SystemAssigned" | no |
| [portfolio](#input\_portfolio) | The AKV portfolio. | `bool` | `false` | no |
| [app\_name](#input\_app\_name) | The App Name for AKV| `string` | n/a | yes |
| [branch](#input\_app\_code) | The branch name for AKV | `string` | n/a | yes |

## Output variables

| Name | Description |
|------|-------------|
| <a name="output_namespaces_primary"></a> [namespaces\_primary](#output\_namespaces\_primary) | Service Bus namespaces map |
| <a name="output_queues_primary"></a> [queues\_primary](#output\_queues\_primary) | Service Bus queues map |
| <a name="output_senders_primary"></a> [senders\_primary](#output\_senders\_primary) | Service Bus "sender" authorization rules map |
| <a name="output_readers_primary"></a> [readers\_primary](#output\_readers\_primary) | Service Bus "readers" authorization rules map |
| <a name="output_manages_primary"></a> [manages\_primary](#output\_manages\_primary) | Service Bus "managers" authorization rules map |
| <a name="output_topics_primary"></a> [topics\_primary](#output\_topics\_primary) | Service Bus topics |

# Architecture Diagram
Work with Tim to create one or more architecture diagrams to be used in the design doc.

Issue a PR to review it.

Preference is for such diagrams to be part of the formal [Core Pipeline ArchiMate model](https://rbcgithub.fg.rbc.com/FRM0/core-pipeline-model), so we can have consistent, source-controlled diagrams like the one in the [SQL MI module's README.md](https://rbcgithub.fg.rbc.com/FRM0-Shared/terraform-azurerm-sql-managed-instance/blob/master/README.md#89-architecture-overview)

