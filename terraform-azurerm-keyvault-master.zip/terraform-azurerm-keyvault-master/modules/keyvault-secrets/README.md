# Azure Key Vault Secrets

Create Key Vault Secrets.

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Providers

| Name | Version |
|------|---------|
| azurerm | n/a |
| random | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:-----:|
| keyvault\_id | Id of the Keyvault to place resources in. | `any` | n/a | yes |
| secrets | Secrets to save to the Azure Key Vault. | <pre>list(object({<br>    name         = string<br>    content_type = 

## Outputs

| Name | Description |
|------|-------------|
| keyvault | Key vault secrets configuration. |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
