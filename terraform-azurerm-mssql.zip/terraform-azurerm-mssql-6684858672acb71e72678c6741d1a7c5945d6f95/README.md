# terraform-azurerm-mssql
Azure MSSQL terraform module.

## Usage Guide
For sample deployment refer to the [Terratest module](test/resources/main) that deploys a MSSQL using the terraform-azurerm-mssql module.

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=2.97.0 |
| <a name="requirement_corepipeline"></a> [corepipeline](#requirement\_corepipeline) | >=1.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >=2.97.0 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | >=1.0.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_audit"></a> [audit](#module\_audit) | ./modules/audit | n/a |
| <a name="module_mssql"></a> [mssql](#module\_mssql) | ./modules/mssql | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_mssql_database.db](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_database) | resource |
| [azurerm_resource_group.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [random_string.unique-suffix](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| corepipeline_client_registry.app_data | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_mssql_server_name"></a> [mssql\_server\_name](#input\_mssql\_server\_name) | The name of the MSSQL server. | `string` |   {service_tier}-{environment}-{portfolio}-{app_code}-{app_name}-{branch}-az-sql-{location_short}-{deployment_number} | no |
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | App data classfication. | `string` | n/a | yes |
| <a name="input_databases"></a> [databases](#input\_databases) | Database config. | <pre>list(object({<br>    name        = string<br>    sku         = string<br>    max_size_gb = number<br>  }))</pre> | n/a | yes |
| <a name="input_deployment_number"></a> [deployment\_number](#input\_deployment\_number) | The deployment number. | `number` | `1` | no |
| <a name="input_location"></a> [location](#input\_location) | Azure region. | `string` | `"canadacentral"` | no |
| <a name="input_managed_identity_object_id"></a> [managed\_identity\_object\_id](#input\_managed\_identity\_object\_id) | The object ID of the managed identity used to run this module. | `string` | n/a | yes |
| <a name="input_mssql_server_config"></a> [mssql\_server\_config](#input\_mssql\_server\_config) | MSSQL Server config. | <pre>object({<br>    admin_username               = string<br>    admin_aad_group_display_name = string<br>    admin_aad_group_object_id    = string<br>    security_alert_emails        = list(string)<br>  })</pre> | n/a | yes |
| <a name="input_virtual_network_name"></a> [virtual\_network\_name](#input\_virtual\_network\_name) | The name of the virtual network, for private endpoint. | `string` | n/a | yes |
| <a name="input_virtual_network_resource_group_name"></a> [virtual\_network\_resource\_group\_name](#input\_virtual\_network\_resource\_group\_name) | The name of the resource group of the virtual network. | `string` | n/a | yes |
| <a name="input_key_vault_name"></a> [key\_vault\_name](#input\_key\_vault\_name) | The name of the keyvault for saving the administrator's password. | `string` | n/a | yes |
| <a name="input_key_vault_resource_group_name"></a> [key\_vault\_resource\_group\_name](#input\_key\_vault\_resource\_group\_name) | The name of the keyvault Resource Group. | `string` | n/a | yes |
| <a name="input_storage_account_name"></a> [storage\_account\_name](#input\_storage\_account\_name) | The name of the Storage Account. | `string` | n/a | yes |
| <a name="input_storage_resource_group_name"></a> [storage\_resource\_group\_name](#input\_storage\_resource\_group\_name) | The name of the Storage Account Resource Group. | `string` | n/a | yes |
| <a name="input_key_vault_resource_group_name"></a> [key\_vault\_resource\_group\_name](#input\_key\_vault\_resource\_group\_name) | The name of the keyvault Resource Group. | `string` | n/a | yes |
| <a name="input_private_endpoint_subnet_name"></a> [private\_endpoint\_subnet\_name](#input\_private\_endpoint\_subnet\_name) | The private endpoint subnet name . | `string` | n/a | no |


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_fqdn"></a> [fqdn](#output\_fqdn) | The FQDN of the MSSQL server. |
| <a name="output_id"></a> [id](#output\_id) | The ID of the MSSQL server. |
| <a name="output_ip_address"></a> [ip\_address](#output\_ip\_address) | The IP address of the MSSQL server. |
| <a name="output_name"></a> [name](#output\_name) | The name of the MSSQL server. |
