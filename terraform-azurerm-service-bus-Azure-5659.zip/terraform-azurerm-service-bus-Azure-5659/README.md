# Azure Service Bus
This Terraform module creates an [Azure Service Bus](https://docs.microsoft.com/en-us/azure/service-bus/).

## Requirements

| Name | Version |
|------|---------|
| [azurerm](#requirement\_azurerm) | >=3.4.0 |
| [corepipeline](#requirement\_corepipeline) | >=1.0.0 |

## Version compatibility

| Module version | Terraform version | AzureRM version |
| -------------- | ----------------- | --------------- |
| >= 5.x.x       | 0.15.x & 1.0.x    | >= 2.0          |
| >= 4.x.x       | 0.13.x            | >= 2.0          |
| >= 3.x.x       | 0.12.x            | >= 2.0          |
| >= 2.x.x       | 0.12.x            | < 2.0           |
| <  2.x.x       | 0.11.x            | < 2.0           |

## Usage

You can use this reference for the module: 
[Terratest module](https://rbcgithub.fg.rbc.com/FRM0-Shared/terraform-azurerm-service-bus/blob/Azure-5659/test/resources/main/main.tf)

<!-- BEGIN_TF_DOCS -->
## Providers

| Name    | Version |
|---------|---------|
| [azurerm](#provider\_azurerm) | >=3.4.0 |

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_access_policy.sb](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_key.sb_key](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key) | resource |
| [azurerm_private_dns_a_record.servicebus](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_a_record) | resource |
| [azurerm_private_endpoint.pe_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_role_assignment.example](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_servicebus_namespace.servicebus_namespace_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace) | resource |
| [azurerm_servicebus_namespace_network_rule_set.sbus_net_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace_network_rule_set) | resource |
| [azurerm_servicebus_queue.queue_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue) | resource |
| [azurerm_servicebus_queue_authorization_rule.manage_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue_authorization_rule) | resource |
| [azurerm_servicebus_queue_authorization_rule.reader_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue_authorization_rule) | resource |
| [azurerm_servicebus_queue_authorization_rule.sender_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_queue_authorization_rule) | resource |
| [azurerm_servicebus_subscription.subscriptions](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_subscription) | resource |
| [azurerm_servicebus_topic.topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic) | resource |
| [azurerm_servicebus_topic_authorization_rule.manage_topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic_authorization_rule) | resource |
| [azurerm_servicebus_topic_authorization_rule.reader_topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic_authorization_rule) | resource |
| [azurerm_servicebus_topic_authorization_rule.sender_topics](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_topic_authorization_rule) | resource |
| [azurerm_user_assigned_identity.sb](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_key_vault.keyvault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault) | data source |
| [azurerm_subnet.sb](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| [azurerm_subscription.primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |
| corepipeline_client_registry.client_data | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| [app\_code](#input\_app\_code) | Client name/account used in naming | `string` | n/a | yes |
| [application](#input\_application) | Project application name | `string` | n/a | yes |
| capacity](#input\_capacity) | Specifies the capacity. When sku is Premium, capacity can be 1, 2, 4, 8 or 16. When sku is Basic or Standard, capacity can be 0 only | `number` | `2` | no |
| [data\_classification](#input\_data\_classification) | App data classfication. | `string` | `"internal"` | no |
| [environment](#input\_environment) | Project environment | `string` | n/a | yes |
| [extra\_tags](#input\_extra\_tags) | Extra tags to add | `map(string)` | `{}` | no |
| [key\_vault\_id](#input\_key\_vault\_id) | The ID of the Key Vault Key which should be used to Encrypt the data in this ServiceBus Namespace. | `string` | n/a | yes |
| [key\_vault\_name](#input\_key\_vault\_name) | The name of the existing application key vault to manage Customer-managed-Encryption Key. | `string` | n/a | yes |
| [keyvault\_resource\_group\_name](#input\_keyvault\_resource\_group\_name) | The name of the resource group of the existing key vault for storing the Customer-managed-Encryption Key. | `string` | n/a | yes |
| [local\_auth\_enabled](#input\_local\_auth\_enabled) | Whether or not SAS authentication is enabled for the Service Bus namespace. | `bool` | `false` | no |
| [location](#input\_location) | Azure location for Servicebus | `string` | `"canadacentral"` | no |
| [private\_endpoint\_subnet\_name](#input\_private\_endpoint\_subnet\_name) | The name of the virtual network, for private endpoint | `string` | `"pep"` | no |
| [public\_ip\_allow\_list](#input\_public\_ip\_allow\_list) | A list of public ip addresses to allow access to the service bus | `list(string)` | `[]` | no |
| [resource\_group\_name](#input\_resource\_group\_name) | Name of the resource group | `string` | n/a | yes |
| [sb\_identity](#input\_sb\_identity) | Service bus Managed Identity. Defaults to SystemAssigned. Possible types are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both) | identity_type = string | "identity_type": "SystemAssigned" | no |
| [service\_tier](#input\_service\_tier) | The service tier where AKV deployed. | `string` | `"n"` | no |
| [servicebus\_namespaces\_queues](#input\_servicebus\_namespaces\_queues) | Map to handle Servicebus creation. It supports the creation of the queues, authorization\_rule associated with each namespace you create | `any` | n/a | yes |
| [sku](#input\_sku) | Defines which tier to use. Options are Basic, Standard or Premium. Please note that setting this field to Premium will force the creation of a new resource. | `string` | `"Premium"` | no |
| [virtual\_network\_name](#input\_virtual\_network\_name) | The name of the virtual network, for private endpoint | `string` | n/a | yes |
| [virtual\_network\_resource\_group\_name](#input\_virtual\_network\_resource\_group\_name) | The name of the resource group of the virtual network | `string` | n/a | yes |
| [whitelist\_subnet\_ids](#input\_whitelist\_subnet\_ids) | List of Virtual network Subnet IDs that need direct access to the PaaS in the Vnet.(Optional) | `string` | n/a | yes |
| [zone\_redundant](#input\_zone\_redundant) | Whether or not this resource is zone redundant. sku needs to be Premium. Defaults to false | `bool` | `true` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_manages_primary"></a> [manages\_primary](#output\_manages\_primary) | Service Bus "managers" authorization rules map |
| <a name="output_namespaces_primary"></a> [namespaces\_primary](#output\_namespaces\_primary) | Service Bus namespaces map |
| <a name="output_queues_primary"></a> [queues\_primary](#output\_queues\_primary) | Service Bus queues map |
| <a name="output_readers_primary"></a> [readers\_primary](#output\_readers\_primary) | Service Bus "readers" authorization rules map |
| <a name="output_senders_primary"></a> [senders\_primary](#output\_senders\_primary) | Service Bus "sender" authorization rules map |
| <a name="output_topics_primary"></a> [topics\_primary](#output\_topics\_primary) | Service Bus topics |
