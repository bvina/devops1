# Azure Service Bus

This Terraform module creates an [Azure Service Bus](https://docs.microsoft.com/en-us/azure/service-bus/).

## Version compatibility

| Name        |  version    | 
| ---------   | ---------   | 
| azurerm     |  >=2.90.0   | 
| corepipeline|  >=1.0.0    |           

## Providers
| Name        |  version    | 
| ---------   | ---------   | 
| azurerm     |  >=2.90.0   | 
| corepipeline|  >=1.0.0    | 

## Resources
| Name                                            |  Type        | 
| ---------                                       | ---------    | 
| azurerm_servicebus_namespace                    |  resource    | 
| azurerm_servicebus_queue                        |  resource    |
| azurerm_servicebus_queue_authorization_rule     |  resource    | 
| azurerm_servicebus_namespace_network_rule_set   |  resource    |
| azurerm_servicebus_topic                        |  resource    |
| azurerm_servicebus_topic_authorization_rule     |  resource    |
| azurerm_servicebus_subscription                 |  resource    |
| ip_rules                                        |  resource    |
| azurerm_private_endpoint                        |  resource    | 
| azurerm_subnet                                  |  datasource  |

## Inputs
| Name                               | Description                                                    |Type           |
|------------------------------------|----------------------------------------------------------------|---------------|         
| Namespaces                         | Name of the Namespace                                          | String        |                       
| location                           | Name of the Azure region                                       | String        |                                      
| resource_group_name                | Name of the Resource group                                     | String        |               
| tfe_subnet_id                      | The ID of the TFE subnet	                                      | String	      | 
| sku                                | The SKU of the key vault                                       | String        | 
| public_ip_allow_list               | A list of public ip addresses to allow access to the key vault	| list(string)	|                                                   
| virtual_network_name               | The name of the virtual network for private endpoint           | string	      |
| virtual_network_resource_group_name| The name of the resource group of virtual network              | string	      |
| queues                             | The name of the queue                                          | string	      |
| queue_authorization_rule           | The name of the queue_authorization_rule                       | string	      |
| topics                             | The name of the topic                                          | string	      | 
| topic_authorization_rule           | The name of the queue_authorization_rule                       | string	      |
| topic subscriptions                | The name of the topic subscription                             | string	      | 
| azurerm_private_endpoint           | The name of the private endpoint                               | string        |

## Outputs
| Name               | Description               |
|--------------------|---------------------------|    
| namespaces         | Name of the namespace     | 
| resource_group_name| Name of the Resource Group|
| queues             | Name of the queue         |
| topics             | Name of the topic         |


You can use this module by including it this way:

```hcl
terraform {
  required_providers {
    azurerm = {
      version = ">=2.90.1"
      source  = "hashicorp/azurerm"
    }

    corepipeline = {
      version = ">=1.0.0"
      source  = "rbc.com/api/corepipeline"
    }
  }
}

provider "corepipeline" {}

provider "azurerm" {
  features {}
}

resource "random_id" "id" {
	  byte_length = 4
}

resource "azurerm_resource_group" "primary" {
  name     = "primary_nonp_ccoe_frm_terraform_demo"
  location = var.location
}

module "service-bus" {
  source = "localterraform.com/SHARED/service-bus/azurerm"

  location                      = var.location
  location_short                = var.location_short
  app_code                      = var.app_code
  environment                   = var.environment
  application                   = var.application
  resource_group_name_primary   = "primary_nonp_ccoe_frm_terraform_demo"
  virtual_network               = var.virtual_network
  address_space                 = var.address_space


  servicebus_namespaces_queues = {
    
    servicebus6 = {
      sku         = "Premium"
      capacity    = 2

      queues = {
        queue100 = {
          reader = true
          sender = true
          manage = true
        }
        queue200 = {
          dead_lettering_on_message_expiration = true
          default_message_ttl                  = "PT10M"
          reader                               = true
        }
        queue300 = {
          duplicate_detection_history_time_window = "PT30M"
          sender                                  = true
        }
        queue400 = {
          requires_duplicate_detection = true
          manage                       = true
        }
      }
    }
    servicebus7 = {
      sku      = "Premium"
      capacity = 2

      topics = {
        testtopic1 = {
        enable_partitioning = true
        default_message_ttl = "PT10M"
        reader = true
        sender = true
        }
        testtopic2 = {
        enable_partitioning = true
        default_message_ttl = "PT10M"
        reader = true
        sender = true
        manage = true
        }
      }
      subscriptions = {
          name = "topics1"
          forward_to = "destination"
          max_delivery_count = 1
        }
    }
  }
}

output "namespaces" {
  value = module.servicebus
  sensitive = true
}

output "location" {
  value = module.servicebus
  sensitive = true
}
output "resource_group_name_primary" {
  value = module.servicebus
  sensitive = true
}
output "queues" {
  value = module.servicebus.queues_primary
  sensitive = true
}
output "topics" {
  value = module.servicebus.topics_primary
  sensitive = true
}

```

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| azurerm | >= 1.32 |

## Modules

No modules.
