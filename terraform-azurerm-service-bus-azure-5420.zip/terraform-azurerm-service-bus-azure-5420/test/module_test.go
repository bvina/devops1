package test

import (
	"context"
	"fmt"
	"log"
	"testing"
	"time"

	"github.com/Azure/azure-sdk-for-go/sdk/messaging/azservicebus"
)

func TestModule(t *testing.T) {
	t.Parallel()

	// testFolder, err := files.CopyTerraformFolderToTemp("./resources/main", t.Name())
	// if err != nil {
	// 	t.Fatal(err)
	// }
	// options := &terraform.Options{
	// 	TerraformDir: testFolder,
	// 	EnvVars: map[string]string{
	// 		"TF_CLI_CONFIG_FILE":  "./terraform.tfrc",
	// 		"PORTFOLIO":           os.Getenv("PORTFOLIO"),
	// 		"APP_CODE":            os.Getenv("APP_CODE"),
	// 		"APP_NAME":            os.Getenv("APP_NAME"),
	// 		"BRANCH":              os.Getenv("BRANCH"),
	// 		"SERVICE_TIER":        os.Getenv("SERVICE_TIER"),
	// 		"ENVIRONMENT":         os.Getenv("ENVIRONMENT"),
	// 		"API_HOSTNAME":        os.Getenv("API_HOSTNAME"),
	// 		"ARM_TENANT_ID":       os.Getenv("ARM_TENANT_ID"),
	// 		"ARM_SUBSCRIPTION_ID": os.Getenv("ARM_SUBSCRIPTION_ID"),
	// 		"ARM_CLIENT_ID":       os.Getenv("ARM_CLIENT_ID"),
	// 		"ARM_CLIENT_SECRET":   os.Getenv("ARM_CLIENT_SECRET"),
	// 		"ONBOARD_AUTH_ID":     os.Getenv("ONBOARD_AUTH_ID"),
	// 		"TF_LOG":              os.Getenv("TF_LOG"),
	// 	},
	// 	NoColor: true,
	// }
	// _mainOpts := terraform.WithDefaultRetryableErrors(t, options)

	// print("\n\n\n\t***** Terraform PLAN Phase. *****\n\n\n")
	// fmt.Printf("\n\n\nTF_LOG set as %v\n\n\n", os.Getenv("TF_LOG"))
	// terraform.InitAndApply(t, _mainOpts)

	// runApplyOnly := os.Getenv("APPLY_ONLY")
	// if len(runApplyOnly) != 0 && runApplyOnly == "true" {
	// 	print("\n\n\t***** WARNING: Terraform Destroy phase is disabled. *****\n\n")
	// } else {
	// 	defer print("\n\n\n\t***** Terraform DESTROY Phase. *****\n\n\n")
	// 	defer terraform.Destroy(t, _mainOpts)
	// }
	// print("\n\n\n\t***** Terraform APPLY Phase. *****\n\n\n")
	// terraform.Apply(t, _mainOpts)

	// time.Sleep(100)

	// Collect output and run assertions.
	// output := make(map[string]interface{})
	// terraform.OutputStruct(t, options, "", &output)

	// assert.NotNil(t, output)
	// assert.NotEmpty(t, output["namespaces"])

	// assert.NotEmpty(t, output["location"])
	// assert.NotEmpty(t, output["resource_group_name_primary"])

	// assert.NotEmpty(t, output["queues"])

	// assert.NotEmpty(t, output["topics"])

	// stdout, err := exec.Command("az", "servicebus", "queue", "authorization-rule", "keys", "list", "--resource-group", "primary_nonp_ccoe_frm_terraform_demo45", "--namespace-name", "servicebus-frm0-cac-dev-servicebus8-bus", "--queue-name", "queue100", "--name", "queue100-manage", "--query", "primaryConnectionString", "--output", "tsv").Output()

	// if err != nil {
	// 	log.Fatal(err)
	// }

	// fmt.Println(string(stdout))

	// fmt.Println(b) // print the content as 'bytes'

	// str := string(stdout) // convert content to a 'string'

	// fmt.Println(str) // print the content as a 'string'

	///////////////// USing connection string ////////////////
	// See here for instructions on how to get a Service Bus connection string:
	// https://docs.microsoft.com/azure/service-bus-messaging/service-bus-quickstart-portal#get-the-conection-string
	client, err := azservicebus.NewClientFromConnectionString("Endpoint=sb://servicebus-frm0-cac-qat-servicebus14-bus.servicebus.windows.net/;SharedAccessKeyName=queue100-reader;SharedAccessKey=/p9EGWx38eRRzn096u4or53M3BQb4811GsTbdpazYbw=;EntityPath=queue100", nil)
	if err != nil {
		panic(err)
	}

	// Sender //

	sender, err := client.NewSender("queue100", nil)
	log.Print("Sending Message..", sender)
	if err != nil {
		log.Fatalf("Sending failure: %+v", err)
	}

	err = sender.SendMessage(context.TODO(), &azservicebus.Message{
		Body: []byte("Test Messages Send from Sai!"),
	})

	log.Print("Sending Success", err)
	// defer terraform.Destroy(t, _mainOpts)

	////////Receving Messages////////////

	receiver, err := client.NewReceiverForQueue(
		"queue100",
		nil,
	)

	ctx, cancel := context.WithTimeout(context.TODO(), 60*time.Second)
	defer cancel()

	messages, err := receiver.ReceiveMessages(ctx,
		1,
		nil,
	)

	if err != nil {
		panic(err)
	}

	for _, message := range messages {
		// For more information about settling messages:
		// https://docs.microsoft.com/azure/service-bus-messaging/message-transfers-locks-settlement#settling-receive-operations
		err = receiver.CompleteMessage(context.TODO(), message)

		body, err := message.Body()

		if err != nil {
			log.Fatalf("Failed to parse message body: %s", err.Error())
		}

		fmt.Println("Recevied Message --->", string(body))

		if err != nil {
			panic(err)
		} // defer terraform.Destroy(t, terraformOptions)

		fmt.Printf("Received and completed the message\n")
	}
}
