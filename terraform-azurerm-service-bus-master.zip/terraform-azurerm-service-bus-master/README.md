# Azure Service Bus

This Terraform module creates an [Azure Service Bus](https://docs.microsoft.com/en-us/azure/service-bus/).

## Version compatibility

| Module version | Terraform version | AzureRM version |
| -------------- | ----------------- | --------------- |
| >= 5.x.x       | 0.15.x & 1.0.x    | >= 2.0          |
| >= 4.x.x       | 0.13.x            | >= 2.0          |
| >= 3.x.x       | 0.12.x            | >= 2.0          |
| >= 2.x.x       | 0.12.x            | < 2.0           |
| <  2.x.x       | 0.11.x            | < 2.0           |

## Usage

You can use this module by including it this way:

```hcl
terraform {
  required_providers {
    azurerm = {
      version = ">=2.79.1"
      source  = "hashicorp/azurerm"
    }

    corepipeline = {
      version = ">=1.0.0"
      source  = "rbc.com/api/corepipeline"
    }
  }
}

provider "corepipeline" {}

provider "azurerm" {
  features {}
}

resource "azurerm_resource_group" "rg" {
  name     = var.resource_group_name
  location = var.location
}

module "servicebus" {
  source = "./module"

  location       = var.location
  location_short = var.location_short
  app_code       = var.app_code
  environment    = var.environment
  stack          = var.application
  resource_group_name = var.resource_group_name

  servicebus_namespaces_queues = {
    # You can just create a servicebus_namespace
    servicebus0 = {}

    # Or create a servicebus_namespace with some queues with default values
    servicebus1 = {
      queues = {
        queue1 = {}
        queue2 = {}
      }
    }

    # Or customize everything
    servicebus2 = {
      custom_name = format("%s-%s-%s-custom", var.stack, var.client_name, module.azure-region.location_short)
      sku         = "Premium"
      capacity    = 2

      queues = {
        queue100 = {
          reader = true
          sender = true
          manage = true
        }
        queue200 = {
          dead_lettering_on_message_expiration = true
          default_message_ttl                  = "PT10M"
          reader                               = true
        }
        queue300 = {
          duplicate_detection_history_time_window = "PT30M"
          sender                                  = true
        }
        queue400 = {  
          requires_duplicate_detection = true
          manage                       = true
        }
      }
    }
  }
}

```

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| azurerm | >= 1.32 |

## Modules

No modules.
