package test

import (
	"os"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestModule(t *testing.T) {
	t.Parallel()

	// Create the workspace.
	workspaceOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "./resources/workspace",
		NoColor:      true,
	})

	defer terraform.Destroy(t, workspaceOptions)
	terraform.InitAndApply(t, workspaceOptions)

	// Deploy the module.
	mainOpts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir:  "./resources/main",
		BackendConfig: map[string]interface{}{"token": os.Getenv("TF_VAR_tfe_token")},
		NoColor:       true,
	})

	defer terraform.Destroy(t, mainOpts)
	terraform.InitAndApply(t, mainOpts)

	// Collect output and run assertions.
	output := make(map[string]interface{})
	terraform.OutputStruct(t, mainOpts, "", &output)

	assert.NotNil(t, output)
	assert.NotEmpty(t, output["namespaces"])

}
