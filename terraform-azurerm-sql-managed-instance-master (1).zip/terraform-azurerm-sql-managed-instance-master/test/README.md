Due to the time taken to deploy SQL MI (2-4 hours for one region, 4-8 for two), the module does not yet have conventional Terratest tests. Instead, and for now, 
copy the sample code in resources/main to an onboarded test repo and run it like a regular application.

Prior to prod, this situation should be improved. Potential solutions include using Terratest stages, with an 'inflate' stage that takes several hours (if the Go timeout can handle that) and subsequent test and teardown stages, selectable from the Jenkins job.

