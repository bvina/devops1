## Infrastructure Requirements
Target network for the Key Vault private endpoint must be accessible from the Terraform Enterprise subnet.


## Usage Guide
For sample deployment refer to the [Terratest module](test/resources/main) that deploys a Key Vault using the terraform-azurerm-keyvault module.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=2.79.1 |
| <a name="requirement_corepipeline"></a> [corepipeline](#requirement\_corepipeline) | >=1.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >=2.79.1 |
| <a name="provider_azurerm.dns_zone"></a> [azurerm.dns\_zone](#provider\_azurerm.dns\_zone) | >=2.79.1 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | >=1.0.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Sub-modules

The integrated services can be used separately with the same inputs and outputs when it's a sub module.

### KeyVault Secrets

See `keyvault-secrets` sub-module [README](./modules/keyvault-secrets/README.md).


## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault.key_vault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault) | resource |
| [azurerm_key_vault_access_policy.automation_access](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_access_policy.user_access](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_private_dns_a_record.keyvault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_a_record) | resource |
| [azurerm_private_endpoint.pep](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_resource_group.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [random_string.string](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_subnet.pep](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| corepipeline_client_registry.app_data | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | App data classfication. | `string` | n/a | yes |
| <a name="input_deployment_number"></a> [deployment\_number](#input\_deployment\_number) | The deployment number. | `number` | `1` | no |
| <a name="input_location"></a> [location](#input\_location) | Azure region. | `string` | `"canadacentral"` | no |
| <a name="input_managed_identity_access_policy"></a> [managed\_identity\_access\_policy](#input\_managed\_identity\_access\_policy) | Access Policy for the Client Deploymnt MSI. | `list(object)` | n/a | yes |
| <a name="input_private_dns_zone_name"></a> [private\_dns\_zone\_name](#input\_private\_dns\_zone\_name) | The name of the Azure Key Vault private dns zone. | `string` | `"privatelink.vaultcore.azure.net"` | no |
| <a name="input_private_dns_zone_resource_group_name"></a> [private\_dns\_zone\_resource\_group\_name](#input\_private\_dns\_zone\_resource\_group\_name) | The name of the resource group of the private dns zone. | `string` | `"p-prod-ccoe-dnszones-dns-rg-glb-1"` | no |
| <a name="input_whitelist_subnet_ids"></a> [whitelist\_subnet\_ids](#input\_whitelist\_subnet\_ids) | A list of Subnet IDs to allow access to the key vault. | `list(string)` | `[]` | no |
| <a name="input_sku"></a> [sku](#input\_sku) | The SKU of the key vault. | `string` | `"standard"` | no |
| <a name="input_tfe_subnet_id"></a> [tfe\_subnet\_id](#input\_tfe\_subnet\_id) | The ID of the TFE subnet. | `string` | `"/subscriptions/3823da9a-f968-433c-aa9c-1b623a79c44e/resourceGroups/n-nonp-ccoe-frm0-tfe-uat-vnet-rg-cac-1/providers/Microsoft.Network/virtualNetworks/n-nonp-ccoe-frm0-tfe-uat-vnet-cac-1/subnets/tfe-subnet"` | no |
| <a name="input_user_access_policies"></a> [user\_access\_policies](#input\_user\_access\_policies) | A list of user access policies. | `list(object)` | `[]` | no |
| <a name="input_virtual_network_name"></a> [virtual\_network\_name](#input\_virtual\_network\_name) | The name of the virtual network, for private endpoint. | `string` | n/a | yes |
| <a name="input_virtual_network_resource_group_name"></a> [virtual\_network\_resource\_group\_name](#input\_virtual\_network\_resource\_group\_name) | The name of the resource group of the virtual network. | `string` | n/a | yes |
| <a name="reader_objects_ids"></a> [reader_objects_ids](#input_reader_objects_ids) | A list of onject IDs to allow read access to the key vault. | `list(string)` | `[]` | no |


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | The id of the key vault. |
| <a name="output_ip_address"></a> [ip\_address](#output\_ip\_address) | Key vault private endpoint ip address. |
| <a name="output_name"></a> [name](#output\_name) | The name of the key vault. |
| <a name="output_resource_group_name"></a> [resource_group_name](#output\resource_group_name) | The Resource Group name of the key vault. |

<!-- END_TF_DOCS -->
