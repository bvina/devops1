# Storage Terraform Custom Module

This Terraform module creates an [Azure Storage Account](https://docs.microsoft.com/en-us/azure/storage/common/storage-account-overview).

## Usage Guide

For sample deployment refer to the [Terratest module](test/resources/main) that deploys a Storage account using the terraform-azurerm-storage-account module.

## Resources

| Name                                                                                                                                                                              | Type        |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| [azurerm_key_vault.storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account)                                              | resource    |
| [azurerm_key_vault_access_policy.storage_key](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key)                                      | resource    |
| [azurerm_storage_account.storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account)                                        | resource    |
| [azurerm_storage_account_customer_managed_key.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/azurerm_storage_account_customer_managed_key) | resource    |
| [azurerm_storage_container.container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/azurerm_storage_container)                                  | resource    |
| [random_string.string](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string)                                                                     | resource    |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config)                                                 | data source |
| corepipeline_client_registry.app_data                                                                                                                                             | data source |

## Input Variables

| Name                                | Type         | Required | Description                                                                                                                                                                                                                                                                                                                                                                                       |
| ----------------------------------- | ------------ | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| storage_account_name                | string       | false    | Name of the storage account 3-24 characters. Lowercase letters and numbers.                                                                                                                                                                                                                                                                                                                       |
| storage_resource_group_name         | string       | yes      | Storage Account resource group name. Must be created before calling this module.                                                                                                                                                                                                                                                                                                                  |
| storage_retention_config            | object       | no       | Storage Account Retention settings.                                                                                                                                                                                                                                                                                                                                                               |
| storage_account_config              | object       | no       | Storage Account Azure settings, as an object with four mandatory properties: `account_tier` (string), `account_kind` (string), `account_replication_type` (string), and `is_hns_enabled` (boolean). Hierarchical namespace is enabled when `is_hns_enabled` is set to "true", and the storage account can be used as Azure Data Lake Storage Gen2. Please see below for detailed validation rules |
| storage_identity                    | object       | no       | Storage Account Managed Identity. Possible types are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both).                                                                                                                                                                                                                                                                 |
| container_name                      | list(string) | yes      | List of container names to be created.                                                                                                                                                                                                                                                                                                                                                            |
| location                            | string       | yes      | Azure region to create stroage account. e.x canadacentral                                                                                                                                                                                                                                                                                                                                         |
| private_endpoint_subnet_name        | string       | yes      | Private endpoint subnet name. default is `pep`.                                                                                                                                                                                                                                                                                                                                                   |
| private_endpoint_subresources       | list(string) | no       | Storage Account Private Endpoint subresoruces, default to `["blob"]`. Needs to have at least one value and the allowed candidate options are: `blob`, `file`, `queue`, `table`, and `web`                                                                                                                                                                                                         |
| virtual_network_name                | string       | yes      | Existing Virtual network name to create private endpoint.                                                                                                                                                                                                                                                                                                                                         |
| shared_access_key_enabled           | bool         | no       | Enable Shared Access Key. Default is `false`.                                                                                                                                                                                                                                                                                                                                                     |
| virtual_network_resource_group_name | string       | yes      | Existing Virtual network Resource Group name to create private endpoint.                                                                                                                                                                                                                                                                                                                          |
| tags                                | map          | no       | Some additional tags to apply to all resources.                                                                                                                                                                                                                                                                                                                                                   |
| deployment_number                   | string       | now      | Deployment number.                                                                                                                                                                                                                                                                                                                                                                                |
| container_name                      | string       | yes      | Name of the storage account 3-24 characters. Lowercase letters and numbers.                                                                                                                                                                                                                                                                                                                       |
| public_ip_allowlist                 | list(string) | no       | List of public IPs that need direct access to the PaaS in the Vnet (Optional).                                                                                                                                                                                                                                                                                                                    |
| data_classification                 | string       | no       | App data classfication.                                                                                                                                                                                                                                                                                                                                                                           |

## Output Variables

| Name                     | Type        | Description                                                                                                                                                                                                                    |
| ------------------------ | ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| storage_rg_name          | string      | Outputs resource group name.                                                                                                                                                                                                   |
| storage_account_name     | string      | Outputs storage accounts name.                                                                                                                                                                                                 |
| storage_account_id       | string      | Outputs Storage Account ID.                                                                                                                                                                                                    |
| storage_private_endpoint | map(object) | Outputs Storage Account private endpoint. The key is each storage sub-resource type such as `blob`, `file`, `queue`, `table`, and `web`. The object value of each key contains two string properties: `fqdn` and `ip_address`. |
| primary_blob_endpoint    | string      | Outputs the primary blob endpoint of the Storage Account, the endpoint URL for blob storage in the primary location.                                                                                                           |

## Custom Managed Storage Account Encryption Key in Azure Key Vault

The storage account Terraform module requires a key vault to store the custom managed encryption key (CMK), therefore a couple of `key_vault` features are required in the main AzureRM provider config:

- `recover_soft_deleted_keys = true` is required to allow Core Pipeline re-deploy the storage account idempotently. This is because during the re-deployment, the CMK in the key vault will be deleted and then re-created. The latter step is actually recovering the key from the soft-deleted status.
- `purge_soft_deleted_keys_on_destroy = false` is required to allow Core Pipeline destroy the CMK along with the storage account. Otherwise, Terraform would attempt to purge the key and fail since the key vault has purge-protection enabled.

An example of the main AzureRM provider config could be:

```hcl
provider "azurerm" {
  features {
    key_vault {
      recover_soft_deleted_key_vaults    = true
      recover_soft_deleted_keys          = true
      purge_soft_delete_on_destroy       = false
      purge_soft_deleted_keys_on_destroy = false
    }
  }
}
```

## Validation Rules for `storage_account_config` Input Object

- The allowed values for `account_tier` are either "Standard" or "Premium".
- The allowed values for `account_kind` are "StorageV2", "Storage", "BlobStorage", "BlockBlobStorage", or "FileStorage".
- The allowed values for `account_replication_type` are "LRS", "GRS", "RAGRS", "ZRS", "GZRS", or "RAGZRS".
- When `account_kind` is "BlockBlobStorage", or "FileStorage", `account_tier` must be "Premium".
- When `account_tier` is "Premium", `account_replication_type` must be "LRS".
- Hierarchical namespace can only be enabled when `account_tier` is "Standard", or when `account_tier` is "Premium" and `account_kind` is "BlockBlobStorage".
- The only available `account_tier` is "Standard" for legacy general-purpose "Storage" v1, or legacy "BlobStorage" accounts.
- For legacy general-purpose "Storage" v1, or legacy "BlobStorage", `account_replication_type` must be "LRS", "GRS", or "RAGRS".
- Hierarchical namespace can't be enabled on legacy general-purpose "Storage" v1 and legacy "BlobStorage" accounts.

Please refer to below documentations for the matrix of storage account types, tiers, as well as hierarchical namespace and redundancy options:

- [https://docs.microsoft.com/en-us/azure/storage/common/storage-account-overview#types-of-storage-accounts]
- [https://docs.microsoft.com/en-us/azure/storage/common/storage-redundancy#supported-storage-account-types]
- [https://docs.microsoft.com/en-us/azure/storage/common/storage-account-overview#legacy-storage-account-types]
- [https://registry.terraform.io/providers/hashicorp/azurerm/3.4.0/docs/resources/storage_account#is_hns_enabled]

## Private Endpoints and Private DNS Records for Azure Data Lake Storage Gen2

When the `is_hns_enabled` property is set to `true` in the `storage_account_config` input variable, the storage account's hierarchical namespace is enabled and can be used as Azure Data Lake Storage (ADSL) Gen2.

This also enforces the storage account Terraform module creating two private endpoints along with two private DNS records for both **dfs** and **blob** storage resources, following the [recommended best practices from Microsoft](https://docs.microsoft.com/en-us/azure/storage/common/storage-private-endpoints#creating-a-private-endpoint).

When hierarchical namespace is enabled, **blob versioning** and **blog change feed** are automatically disabled since [those two features are not supported in ADSL Gen2](https://docs.microsoft.com/en-us/azure/storage/blobs/storage-feature-support-in-storage-accounts).

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.18.0 |
| <a name="requirement_corepipeline"></a> [corepipeline](#requirement\_corepipeline) | 2.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >=3.18.0 |
| <a name="provider_azurerm.dns_zone"></a> [azurerm.dns\_zone](#provider\_azurerm.dns\_zone) | >=3.18.0 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | 2.0.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_required_tags"></a> [required\_tags](#module\_required\_tags) | ./common_modules/modules/required_tags | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_access_policy.storage](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_key.storage_key](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key) | resource |
| [azurerm_private_dns_a_record.storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_a_record) | resource |
| [azurerm_private_endpoint.pep](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_storage_account.storage](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_customer_managed_key.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_customer_managed_key) | resource |
| [azurerm_storage_container.container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [random_string.string](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_key_vault.keyvault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault) | data source |
| [azurerm_resource_group.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/resource_group) | data source |
| [azurerm_subnet.pep](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |
| corepipeline_client_registry.client_data | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_code"></a> [app\_code](#input\_app\_code) | The App Code for storage account. | `string` | `""` | no |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | The App Name for storage account. | `string` | `""` | no |
| <a name="input_branch"></a> [branch](#input\_branch) | The branch name (Optional). | `string` | `""` | no |
| <a name="input_compliance"></a> [compliance](#input\_compliance) | RBC data compliance. | `string` | `"N/A"` | no |
| <a name="input_containers"></a> [containers](#input\_containers) | List of the storage account containers 3-63 characters. Lowercase letters, numbers, and hyphens. Access Type: blob, container or private. (Optional) | <pre>list(object({<br>    name         = string<br>    access_type  = string<br>  }))</pre> | `[]` | no |
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | App Code data classfication. | `string` | n/a | yes |
| <a name="input_deployment_number"></a> [deployment\_number](#input\_deployment\_number) | Deployment number. | `string` | `"1"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment where storage account will be deployed. | `string` | `"dev"` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | Extra tags for all resources. | `map(string)` | `{}` | no |
| <a name="input_key_vault_name"></a> [key\_vault\_name](#input\_key\_vault\_name) | The name of the existing application key vault to manage Customer-managed-Encryption Key. | `string` | n/a | yes |
| <a name="input_keyvault_resource_group_name"></a> [keyvault\_resource\_group\_name](#input\_keyvault\_resource\_group\_name) | The name of the resource group of the existing key vault for storing the Customer-managed-Encryption Key. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The Azure region to deploy resources. e.g. canadacentral | `string` | n/a | yes |
| <a name="input_portfolio"></a> [portfolio](#input\_portfolio) | The Application portfolio. | `string` | `"ccoe"` | no |
| <a name="input_private_endpoint_subnet_name"></a> [private\_endpoint\_subnet\_name](#input\_private\_endpoint\_subnet\_name) | The name of the virtual network private endpoint subnet. Defaults to "pep". (Optional) | `string` | `"pep"` | no |
| <a name="input_private_endpoint_subresources"></a> [private\_endpoint\_subresources](#input\_private\_endpoint\_subresources) | Storage Account Private Endpoint subresoruce. Defaults to "blob". (Optional) | `list(string)` | <pre>[<br>  "blob"<br>]</pre> | no |
| <a name="input_service_tier"></a> [service\_tier](#input\_service\_tier) | The service tier where storage account will be deployed. | `string` | `"e"` | no |
| <a name="input_shared_access_key_enabled"></a> [shared\_access\_key\_enabled](#input\_shared\_access\_key\_enabled) | Enable Shared Access Key on Storage account. (Optional) Default: false | `bool` | `true` | no |
| <a name="input_storage_account_config"></a> [storage\_account\_config](#input\_storage\_account\_config) | Storage Account Azure settings. Available account\_tier are "Standard", "Premium" and account\_replication\_type are "LRS", "GRS", "RAGRS", "ZRS", "GZRS", "RAGZRS". Hierarchical namespace is enabled when is\_hns\_enabled is set to `true`, and the storage account can be used as Azure Data Lake Storage Gen2. (Optional) | <pre>object({<br>    account_tier                      = string<br>    account_kind                      = string<br>    account_replication_type          = string<br>    is_hns_enabled                    = bool<br>  })</pre> | <pre>{<br>  "account_kind": "StorageV2",<br>  "account_replication_type": "LRS",<br>  "account_tier": "Standard",<br>  "is_hns_enabled": false<br>}</pre> | no |
| <a name="input_storage_account_name"></a> [storage\_account\_name](#input\_storage\_account\_name) | Name of the storage account 3-24 characters. Lowercase letters and numbers. | `string` | n/a | yes |
| <a name="input_storage_identity"></a> [storage\_identity](#input\_storage\_identity) | Storage Account Managed Identity. Defaults to SystemAssigned. Possible types are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both). (Optional) | <pre>object({<br>    identity_type = string<br>    identity_ids = list(string)<br><br>  })</pre> | <pre>{<br>  "identity_ids": [],<br>  "identity_type": "SystemAssigned"<br>}</pre> | no |
| <a name="input_storage_resource_group_name"></a> [storage\_resource\_group\_name](#input\_storage\_resource\_group\_name) | The name of the resource group of the Storage Account. Must be an existing Resource Group. | `string` | n/a | yes |
| <a name="input_storage_retention_config"></a> [storage\_retention\_config](#input\_storage\_retention\_config) | Storage Account retention config. Blobs delete\_retention\_policy defaults to 7 days. container\_delete\_retention\_policy defaults to 7 days.  (Optional) | <pre>object({<br>    delete_retention_policy           = number<br>    container_delete_retention_policy = number<br>  })</pre> | <pre>{<br>  "container_delete_retention_policy": 7,<br>  "delete_retention_policy": 7<br>}</pre> | no |
| <a name="input_tfe_instance"></a> [tfe\_instance](#input\_tfe\_instance) | TFE instance used to deploy module. | `string` | `"nonp-uat"` | no |
| <a name="input_virtual_network_name"></a> [virtual\_network\_name](#input\_virtual\_network\_name) | The name of the existing virtual network with private endpoint subnet. | `string` | n/a | yes |
| <a name="input_virtual_network_resource_group_name"></a> [virtual\_network\_resource\_group\_name](#input\_virtual\_network\_resource\_group\_name) | The name of the existing resource group of the virtual network with Private endpoint subnet. | `string` | n/a | yes |
| <a name="input_whitelist_subnet_ids"></a> [whitelist\_subnet\_ids](#input\_whitelist\_subnet\_ids) | List of Virtual network Subnet IDs that need direct access to the PaaS in the Vnet. (Optional). | `list(string)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_primary_blob_endpoint"></a> [primary\_blob\_endpoint](#output\_primary\_blob\_endpoint) | The primary blob endpoint of the Storage Account as a string, the endpoint URL for blob storage in the primary location. |
| <a name="output_storage_account_id"></a> [storage\_account\_id](#output\_storage\_account\_id) | ID of the Storage Account created. |
| <a name="output_storage_account_name"></a> [storage\_account\_name](#output\_storage\_account\_name) | Name of the Storage Account created. |
| <a name="output_storage_private_endpoint"></a> [storage\_private\_endpoint](#output\_storage\_private\_endpoint) | Storage Account private endpoint configuration. |
| <a name="output_storage_rg_name"></a> [storage\_rg\_name](#output\_storage\_rg\_name) | Resource Group name for the Storage account. |
| <a name="output_tags"></a> [tags](#output\_tags) | n/a |
<!-- END_TF_DOCS -->