# SQL MI Module Examples

The following examples are available

1. **Simple**. This creates a single SQL MI
   
2. **Failover**. This creates two SQL MI instances in two Azure regions, setting one as the primary and the other as the secondary. The module then configures the secondary as the auto-failover for the primary. Once configured Azure will automatically replicate all writes to the secondary, and perform failovers automatically (by default). A failover should be transparent to applications (as should a failback) -- the DNS records for the listener endpoints are updated automatically by Azure in the event of failovers/failbacks.
