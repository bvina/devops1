# Auto-Failover example

 This example demonstrates how to create a primary and secondary SQL MI and configure them so that the secondary is the auto-failover for the primary.

 The configuration consists of primary.tf, and secondary.tf. Terraform will configure the primary first, then the secondary. It passes the ID of the primary to the secondary and the module will then enable an auto-failover group from the primary to the secondary.
 
See the [README](../../../../README.md) for more information


