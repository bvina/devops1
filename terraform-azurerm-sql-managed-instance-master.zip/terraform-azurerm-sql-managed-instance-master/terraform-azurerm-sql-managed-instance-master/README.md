# 1. Azure SQL Managed Instance - Terraform
    
# Table of Contents <!-- omit in toc -->
- [1. Azure SQL Managed Instance - Terraform](#1-azure-sql-managed-instance---terraform)
- [2. Overview](#2-overview)
- [3. See also:](#3-see-also)
- [4. Resources Overview](#4-resources-overview)
- [5. Identity](#5-identity)
- [6. RBAC](#6-rbac)
  - [6.1. DBA/Admin Access](#61-dbaadmin-access)
    - [6.1.1. Azure Active Directory Integration](#611-azure-active-directory-integration)
    - [6.1.2. SQL Admin Access](#612-sql-admin-access)
    - [6.1.3. Accessing SQL Administrator Login Credentials](#613-accessing-sql-administrator-login-credentials)
    - [6.1.4. Azure Active Directory Integration](#614-azure-active-directory-integration)
- [7. Network Requirements](#7-network-requirements)
  - [7.1. Subnets](#71-subnets)
    - [7.1.1. SQL MI-dedicated Subnet](#711-sql-mi-dedicated-subnet)
    - [7.1.2. Private Endpoint Subnet](#712-private-endpoint-subnet)
  - [7.2. Firewall Rules](#72-firewall-rules)
  - [7.3. Networking Configuration Example](#73-networking-configuration-example)
  - [7.4. SQL MI and Private Endpoints](#74-sql-mi-and-private-endpoints)
  - [7.5. DNS](#75-dns)
- [8. Features and Capabilities](#8-features-and-capabilities)
  - [8.1. Maintenance Window](#81-maintenance-window)
  - [8.2. Logging and Monitoring](#82-logging-and-monitoring)
  - [8.3. Storage Redundancy](#83-storage-redundancy)
  - [8.4. Transparent Data Encryption (TDE)](#84-transparent-data-encryption-tde)
  - [8.5. Auto-Failover Groups](#85-auto-failover-groups)
  - [8.6. Timezones](#86-timezones)
  - [8.7. Vulnerability Assessments](#87-vulnerability-assessments)
  - [8.8. Purview and raiden Integration](#88-purview-and-raiden-integration)
  - [8.9. Architecture Overview](#89-architecture-overview)
  - [8.10. Deployment times](#810-deployment-times)
- [9. Using the Module from Application Terraform Code](#9-using-the-module-from-application-terraform-code)
  - [9.1. Example usage](#91-example-usage)
  - [9.2. Module variables and resources](#92-module-variables-and-resources)
  - [9.3. Requirements](#93-requirements)
  - [9.4. Providers](#94-providers)
  - [9.5. Modules](#95-modules)
  - [9.6. Resources](#96-resources)
  - [9.7. Inputs](#97-inputs)
  - [9.8. Outputs](#98-outputs)
- [10. Diagnostics and Troubleshooting](#10-diagnostics-and-troubleshooting)
  - [10.1. Deployment Already Exists](#101-deployment-already-exists)
# 2. Overview
This module creates and configures an Azure SQL Managed Instance (SQL MI). It provides the following features and capabilites:

* **Automated Backups** Azure SQL Managed Instance use SQL Server technology to create full backups every week, differential backups every 12-24 hours, and transaction log backups every 5 to 10 minutes. The frequency of transaction log backups is based on the compute size and the amount of database activity.
* **Configurable storage redundancy** The module allows the selection of local, zone, or geo-redundant storage, to meet solution resiliency requirements.
* **Transparent Data Encryption (TDE)** TDE is enabled on all databases in the SQL MI and cannot be disabled. 
* **Auto-failover groups**. The auto-failover groups feature allows you to manage the replication and failover of a group of databases on a server or all user databases in a managed instance to another Azure region. For more information, see [Auto-failover groups overview & best practices](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/auto-failover-group-sql-mi?view=azuresql&tabs=azure-powershell).
* **SQL Vulnerability Assessment** Automated scanning of databases to discover, track, and help remediate potential database vulnerabilities. Use it to proactively improve your database security. See [SQL Vulnerability Assessment](https://docs.microsoft.com/en-us/azure/azure-sql/database/sql-vulnerability-assessment?view=azuresql) for more information.
* **Data Scanning** Access to enable Purview data cataloging and scanning of database content.
* **Platform-level management RBAC** The Module uses Azure Active Directory (AAD) to grant access to instance administration DBA functions to authorized principals. Note that it does not provide data plane RBAC -- user access to individual databases -- this capability is managed by DBAs after the module as create the infrastructure.
* **Maintenance Window Selection** Azure provides at least two different maintenance windows to allow application operators to minimize any disruption caused by Azure performing rolling upgrades or other maintance on the managed service.

The module **does not**:
* Manage individual database level lifecycles or RBAC. This function is performed by DBAs using other means once the instance has been created. The expectation is that this will be done using Helios or Kyvos.
* ...

# 3. See also:
* [Azure SQL MI](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/how-to-content-reference-guide)
* [Automated Backups -- Azure SQL MI](https://docs.microsoft.com/en-ca/azure/azure-sql/database/automated-backups-overview?tabs=single-database&view=azuresql#backup-usage)
* [SQL Vulnerability Assessment](https://docs.microsoft.com/en-us/azure/azure-sql/database/sql-vulnerability-assessment?view=azuresql)
* [Terraform Azure Provider](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/sqlmi)
* [Azure Active Directory Authentication for SQL MI](https://docs.microsoft.com/en-us/azure/azure-sql/database/authentication-aad-overview?view=azuresql)
* [Azure SQL MI Connectivity Architecture](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/connectivity-architecture-overview?view=azuresql)


# 4. Resources Overview
The module deploys and manages the following resources

- Azure resource group containing:
  - The managed instance itself. This in turn creates the Virtual Cluster of Windows VMs that run the actual SQL Server software. These resources are fully managed by Azure.
  - Any databases created by DBAs.
  - A storage account with a blob container. This is used for (a) Purview scan outputs and (b) to store transient backups from on-premises SQL Server systems in support of migrations.
  - A Private Endpoint for the storage account
 - Azure resource group containing:
   - An Azure Key Vault to contain the instance SQL administrator credentials.
   - An Azure Key Vault to contain the encryption key that is used to protect the data encryption keys used to provide the Transparent Data Encryption capability.
   - Private endpoints for these two Key Vaults.


The module depends on these resources:
- Networking and firewall rules, currently configured by the Core Pipeline/Cloud Operations team during the onboarding process of the App Code for the application using this module. More specifically:
  - A VNET that is peered with both the Expressroute VNET and the Azure Shared Services VNET containing Core Pipeline resources. This peering enables connectivity between the instance and on-premises users and applications.
  - A subnet within the VNET that hosts the instance's virtual cluster. 
  - Firewall rules as described [here](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/connectivity-architecture-overview?view=azuresql#mandatory-inbound-security-rules-with-service-aided-subnet-configuration) and (for DB mirroring to support HA), [here](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/managed-instance-link-preparation?view=azuresql)
  - A subnet within the VNET that hosts the storage and Key Vault Private Endpoints created by the module.
  - Route table and firewall rules that allow ingress and egress flows between the instance and its users and applications.
- Private DNS zones that host the DNS records for the Key Vault and Storage Private End Points created by the module.
 
Certain of these resources are described in more detail below, and they are all depicted in the [Architecture Overview diagram below](#-architecture-overview)

# 5. Identity
> NOTE: Terraform Azurerm provider versions up to and including 3.14 *do not support* the use of User Assigned Managed Identities for SQL MI. See the section on Azure Active Directory Integration for details on the workaround for this issue.

The instance must be provisioned with a User Assigned Managed Identity (UAMI) as its internal identity. This is required to support Azure Active Directory (AAD) Authentication.

The UAMI must be pre-created and must be granted (by IAM), these permissions:
* User.Read.All
* GroupMemberRead.All
* Application.Read.All

Internally, the module will configure the TDE Key Vault so that the UAMI has Get, WrapKey and UnwrapKey permissions on the TDE key.

The identity model is as follows:

![Identity & RBAC Model](./docs/images/IdentityAndRBACModel.png)

# 6. RBAC

## 6.1. DBA/Admin Access
DBA access to the instance is provided using Azure Active Directory (AAD) Admin, and (pending approval by Security for production environments), SQL Auth.

### 6.1.1. Azure Active Directory Integration
The module accepts an AAD group name and associates this group with the Active Directory Admin feature of the instance. Any member of this group can then act as an instance administrator.

> NOTE: Due to feature lag in the Azurerm provider, this release of the module does not support the asignment of a UAMI directly as an identity of an MI. Instead, the module creates the instance with the default System Assigned Managed Identity (SAMI), and then, once the instance is fully up and running, a Jenkins job is run to associate the UAMI and AAD group with the instance.  This job is located in `./build/jenkins/Jenkinsfile_enable_aad_auth.groovy`, and must be run by the Core Pipeline support of Cloud Operations team after the module has completed its apply run. Once the Azurerm provider has enabled UAMI support, the job can be removed and the module will perform all these assignments internally.

The temporary Jenkins job is located under <Service Tier>/Core Pipeline/Ops/Modules/azurerm-sql-managed-instance/enable_aad_auth

> **WARNING**. After running the separate Jenkins job, the module may not run successfully again on the same instance due to conflicts with the UAMI. This issue will be addressed once Azurerm properly supports UAMIs.
### 6.1.2. SQL Admin Access
 
For DBA-type access to the instance, the initial, non-production version of the module will use [SQL Authentication](https://docs.microsoft.com/en-us/azure/azure-sql/database/logins-create-manage?view=azuresql#authentication-and-authorization) only. Full RBAC using Azure Active Directory, linked to AD will be provided in subsequent releases.

### 6.1.3. Accessing SQL Administrator Login Credentials
The username and password of the SQL administrator are stored in an Azure Key Vault. This Key Vault is created by the module and is dedicated to the SQL MI instance. 

The module will accept these values, or will generate them if not provided. 
These values are stored in the Key Vault as `sqlmi-admin-login` and `sqlmi-admin-password`


### 6.1.4. Azure Active Directory Integration

For more information on AAD Authorization, see
* [Use Azure Active Directory authentication](https://docs.microsoft.com/en-us/azure/azure-sql/database/authentication-aad-overview?view=azuresql)


# 7. Network Requirements
**Note** These requirements are mostly for use by the platform team responsible for configuring your application's networking -- typically as part of the onboarding process. As a module user, you only need to provide the networking values such as the 
subnet address space -- it is not the module user's responsibility to configure these.

The networking configuration for the module's resources must have been perfomed prior to running the module. That is, the module 
expects the necessary subnets, routing and firewall rules will already have been put in place. 

See [Connectivity architecture for Azure SQL Managed Instance](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/connectivity-architecture-overview?view=azuresql) for details on SQL MI's networking requirements.

The module requires the following networking configurations:
## 7.1. Subnets

### 7.1.1. SQL MI-dedicated Subnet
SQL MI required a dedicated subnet where it will place the hosts that constitute the instance's virtual cluster.  Each SQL MI needs a minimum of 32 IP address within that subnet. If you run two SQL MIs, you will need at least 64 IPs. This means that you must plan the subnet size carefully before using the module for the first time or risk running out of address space.

SQL MI will take control over this subnet, and impose firewall rules, routing and hidden intent policies. For this reason, the subnet should be used *only* for SQL MI instances -- any attempt to place other resources in it will likely lead to undefined behaviour. The subnet must be configured to delegate to "Microsoft.Sql/managedInstances".

See [Determine required subnet size and range for Azure SQL Managed Instance](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/vnet-subnet-determine-size?view=azuresql) for more information.

### 7.1.2. Private Endpoint Subnet
The Module's Azure Keyvault and Storage Account resources are both behind Private Endpoints. These reside in a dedicated subnet that is also created by the prior networking configuration step. Note that SQL MI itself does not need a private endpoint. See [Private Endpoints](#sql-mi-and-private-endpoints) below for more information.

## 7.2. Firewall Rules

 The mandatory minimum firewall rules to support SQL MI are described [here](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/connectivity-architecture-overview#mandatory-inbound-security-rules-with-service-aided-subnet-configuration). Additional rules may be required to support features such as replication, SQL MI <-> On Premises SQL Server connectivity etc. 

## 7.3. Networking Configuration Example
An example of a suitable network configuration can be found in [FRM0-Shared/core-pipeline-client-networking/...tf01.json](https://rbcgithub.fg.rbc.com/FRM0-Shared/core-pipeline-client-networking/blob/master/dev/tf01/tf01.json). This example would create the required VNET, peerings, routing, subnets and firewall rules. As a module user, this configuration would be performed for you by the Azure team prior to you using the module.

## 7.4. SQL MI and Private Endpoints 
SQL MI does not need a Private Endpoint for regular user and application access because the Windows VMs that run SQL server and form the virtual cluster of the instance are deployed inside the dedicated subnet, and only have private IPs.

However a Private Endpoint is required to allow raiden/Purview access to the instance in order to scan database content. This Private Endpoint is *not* created or managed by the module, but is owned by the Purview PaaS and created via an API implemented in Kyvos.

The flow to create this Private Endpoint is part of the post-module deployment onboarding steps, along with most RBAC for DB-level access

## 7.5. DNS
Because there are no user-facing private endpoints with SQL MI, there is no need to create DNS records in a private zone in an RBC resource group (as is the case with other services that do use Private Endpoints). Instead, SQL MI creates its own DNS entries in the standard `vnet.database.windows.net` zone, and the FQDN of the instance in this zone must be used by consuming services.

# 8. Features and Capabilities
## 8.1. Maintenance Window
The module accepts Microsoft-provided preconfigured maintenance window values. The currently available values are obtained by running this Azure CLI command:
```
az maintenance public-configuration list \
    --query "[?location=='canadacentral'&&contains(maintenanceScope,'SQLManagedInstance')]" \
    --subscription <your deployment subscription>
```
Note that you must have installed the experimental 'maintenance' extention before running the above command: `az extension add --name maintenance`

See [Maintenance Window FAQs](https://docs.microsoft.com/en-us/azure/azure-sql/database/maintenance-window-faq?view=azuresql) for more information.

## 8.2. Logging and Monitoring
The module configures the managed instance to send log and metric telemetry to a dedicated Azure Log Analytics Workspace (also created by the module). By default, 'allLogs' and 'allMetrics' are enabled, however both log and metric settings are configurable via the sqlmi_log_settings and sqlmi_metric_settings input variables. The list of valid values for logs can change over time so is not enforced by the module, however known available values include: `SQLSecurityAuditEvents`, `ResourceUsageStats`, and `DevOpsOperationsAudit`. 

For more information on available telemetry and log analytics see [Configure streaming export of Azure SQL Database and SQL Managed Instance diagnostic telemetry](https://docs.microsoft.com/en-us/azure/azure-sql/database/metrics-diagnostic-telemetry-logging-streaming-export-configure?view=azuresql&tabs=azure-portal). 

For more information on the meaning of the log object attributes, see Azurerm's [azurerm_monitor_diagnostic_setting resource documentation](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting).

The telemetry stored in this workspace can be consumed by [Azure SQL Analytics](https://docs.microsoft.com/en-us/azure/azure-monitor/insights/azure-sql). This is not configured by the module and must be enabled separately.

## 8.3. Storage Redundancy
The MI's underlying storage can be configured for local, zonal or geographical reducancy. This storage is used for database backups and so the redundency level determines how available the database backups are. If you chose local or zonal and the primary Azure region goes up in smoke, then no backups will be available to restore from into the recovery region.

See [Azure Storage redundancy](https://docs.microsoft.com/en-us/azure/storage/common/storage-redundancy) for more information.

The three levels of storage redundancy are:
1. Locally redundant storage (LRS)
* Design characteristics: replicates your data three times within a single physical location in the primary region. LRS provides at least 99.999999999% (11 9’s) durability of objects over a given year. LRS protects your data against server rack and drive failures. However, if a disaster such as fire or flooding occurs within the data center, all replicas of a storage account using LRS may be lost or unrecoverable.
* Best for: LRS keeps your data in the same region and provides capability of data residency and helping you to stay compliant with regulatory requirements. In addition, LRS is the lowest-cost redundancy option (but offering the least durability compared to other options) which is good fit for dev/test scenarios.
1. Zone-redundant storage (ZRS)
* Design characteristics: replicates your Azure Storage data synchronously across three Azure availability zones in the primary region. Each availability zone is a separate physical location with independent power, cooling, and networking. ZRS offers durability for Azure Storage data objects of at least 99.9999999999% (12 9's) over a given year.
* Best for: ZRS also provides capability of data residency but offers higher durability due to data replicated across availability zones. It is good fit for production scenarios that are cost sensitive.
1. Geo-redundant storage (RA-GRS) 
* Design characteristics: replicates your data synchronously three times within a single physical location in the primary region using LRS. It then copies your data asynchronously to a single physical location in a secondary region that is hundreds of miles away from the primary region. RA-GRS offers durability for Azure Storage data objects of at least 99.99999999999999% (16 9's) over a given year.
* Best for: RA-GRS is best disaster recovery option which gives highest durability. In addition, geo-redundant backup storage enables Geo-restore capability – a cheap and economically efficient disaster recovery option. This is default configuration value and if there is no need for data residency compliance, it is recommended to use RA-GRS backup storage for all production workloads.

## 8.4. Transparent Data Encryption (TDE)
TDE helps protect Azure Azure SQL Managed Instance against the threat of malicious offline activity by encrypting data at rest. It performs real-time encryption and decryption of the database, associated backups, and transaction log files at rest without requiring changes to the application

TDE encrypts the storage of an entire database by using a symmetric key called the Data Encryption Key (DEK). The DEK is used for decryption and re-encryption of the database files in the Server database engine process. The DEK is protected (encrypted) by the TDE protector. In the module, the TDE protector is a asymmetric key stored in Azure Key Vault (known as customer-managed transparent data encryption, also
known as Bring Your Own Key or BYOK).- [1. Azure SQL Managed Instance - Terraform](#1-azure-sql-managed-instance---terraform)

The module enables TDE and via [this Azure policy](https://rbcgithub.fg.rbc.com/AEO0/security-policy/blob/bad510aa594ad88fba0c7fc07076ce393606a701/policies/sqlmi/SC-AZURE-SQLMI-009/SC-AZURE-SQLMI-009.json), will either prevent any attempt to disable it at the database level, or alert when it has been disabled.

See [Transparent data encryption for SQL Database, SQL Managed Instance, and Azure Synapse Analytics](https://docs.microsoft.com/en-us/azure/azure-sql/database/transparent-data-encryption-tde-overview?view=azuresql&tabs=azure-portal) for more information.

## 8.5. Auto-Failover Groups

The module supports auto failover groups to provide automated cross-region failover from the primary to the secondary region in the event that the primary zone or zones becomes unavailable. 

This requires using the module to create and configure two instances of SQL MI -- one acting as the primary, and one as the failover. The Azure ID the secondary is passed to the module when creating the primary (i.e., the secondary must be created first, although Terraform will automatically order the creation for you)

Note that using this option will effectively double the SQL MI cost of the solution and also double the time taken to create the configuration (from about 2-4 hours, to 4-8 hours).

See [Auto-Failover Groups and Best Practices](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/auto-failover-group-sql-mi?view=azuresql&tabs=azure-powershell) for more information.


## 8.6. Timezones
Coordinated Universal Time (UTC) is the recommended time zone for the data tier of cloud solutions. Azure SQL Managed Instance also offers a choice of time zones to meet the needs of existing applications that store date and time values and call date and time functions with an implicit context of a specific time zone.

T-SQL functions like GETDATE() or CLR code observe the time zone set on the instance level. SQL Server Agent jobs also follow schedules according to the time zone of the instance.

See [Time zones in Azure SQL Managed Instance](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/timezones-overview?view=azuresql) for more information, including a list of available time zones. When overriding the default ("UTC"), you must use the exact value from the "Time zone ID" column in the [List of supported time zones](https://docs.microsoft.com/en-us/azure/azure-sql/managed-instance/timezones-overview?view=azuresql#list-of-supported-time-zones) section.

> **Note** The time zone cannot be changed once an instance is created.

## 8.7. Vulnerability Assessments
The module automatically configures SQL Vulnerability Assessments with the results saved in the Azure Storage Account
dedicated to this instance. The module establishes a role assignment to grant SQL MI `Storage Blob Data Contributor` role on 
the Storage Account.

See [SQL Vulnerability Assessments](https://docs.microsoft.com/en-us/azure/azure-sql/database/sql-vulnerability-assessment?view=azuresql&tabs=azure-powershell) for more information.

## 8.8. Purview and raiden Integration
TODO -- document

## 8.9. Architecture Overview

This diagram depicts the structure and relationships of the key Azure resources involved -- both those created and configured by the Terraform module itself, and those the module's resources depend on or interact with in some way.

![Architecture Overview -- Structure](docs/images/AppToTechnology.png)

The source for this diagram is in [FRM0/core-pipeline-model](https://rbcgithub.fg.rbc.com/FRM0/core-pipeline-model)

## 8.10. Deployment times

> **Warning:** Expect the initial creation of the instance to take between 2 and 4 hours, and 4 - 8 hours if configuring two instances for auto-failover.

Initial instance deployments create a [Virtual Cluster](https://techcommunity.microsoft.com/t5/azure-sql-blog/azure-sql-mi-now-removes-virtual-cluster-as-part-of-the-delete/ba-p/2703627) inside the VNET.  This is a long running operation - see 90th percentile durations documented [here](https://docs.microsoft.com/en-ca/azure/azure-sql/managed-instance/management-operations-overview#duration). 


# 9. Using the Module from Application Terraform Code

## 9.1. Example usage

Example code to illustrate how to use the module can be found in the module's [test/resources](test/resources) directory. Examples include:

* [Create a zone-redundant SQL MI with 64GB of storage and 4 CPU cores](./test/resources/main/main.tf)
* [Create a geo-redundant SQL MI with 128GB of storage and 8 CPU cores](./test/resources/main_.tf) (*coming soon*)

To use these examples, copy the code to an already-onboarded Core Pipeline application repository and follow the steps in the [Core Pipeline Quick Start](https://rbcgithub.fg.rbc.com/pages/Innersource-Commons/helios-docs/docs/corepipeline/getting_started/quick_start) documentation.
 
> Remember that once the module has been run successfully, the Jenkins job to assign a UAMI and AD Admin group to the instance must be run separately.

> **WARNING**. After running the separate Jenkins job, the module may not run successfully again on the same instance due to conflicts with the UAMI. This issue will be addressed once Azurerm properly supports UAMIs.

## 9.2. Module variables and resources
The specification for the modules input and output variables is as follows:

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~>3.5.0 |
| <a name="requirement_corepipeline"></a> [corepipeline](#requirement\_corepipeline) | ~>2.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | n/a |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~>3.5.0 |
| <a name="provider_azurerm.dns_zone"></a> [azurerm.dns\_zone](#provider\_azurerm.dns\_zone) | ~>3.5.0 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | ~>2.0.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |
| <a name="provider_time"></a> [time](#provider\_time) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_admin-key-vault-secrets"></a> [admin-key-vault-secrets](#module\_admin-key-vault-secrets) | ./modules/terraform-azurerm-keyvault/modules/keyvault-secrets | n/a |
| <a name="module_admin_key_vault"></a> [admin\_key\_vault](#module\_admin\_key\_vault) | ./modules/terraform-azurerm-keyvault | n/a |
| <a name="module_tde_key_vault"></a> [tde\_key\_vault](#module\_tde\_key\_vault) | ./modules/terraform-azurerm-keyvault | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_key.storage](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key) | resource |
| [azurerm_key_vault_key.tde_key](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key) | resource |
| [azurerm_log_analytics_workspace.law](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_workspace) | resource |
| [azurerm_monitor_diagnostic_setting.sqlmi](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_dns_a_record.storage](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_a_record) | resource |
| [azurerm_private_endpoint.storage](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_resource_group.data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sqlmi](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group_template_deployment.encryption_protector](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_resource_group_template_deployment.encryption_protector_key](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_resource_group_template_deployment.mi](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_resource_group_template_deployment.va](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_role_assignment.va_to_storage](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_storage_account.storage](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_customer_managed_key.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_customer_managed_key) | resource |
| [azurerm_storage_container.storage](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [random_password.password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_string.sqlmi_deployment_name](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [random_string.unique-suffix](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [time_sleep.admin_wait](https://registry.terraform.io/providers/hashicorp/time/latest/docs/resources/sleep) | resource |
| [time_sleep.tde_wait](https://registry.terraform.io/providers/hashicorp/time/latest/docs/resources/sleep) | resource |
| [azuread_client_config.current](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/client_config) | data source |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_mssql_managed_instance.mi](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/mssql_managed_instance) | data source |
| [azurerm_resource_group.network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/resource_group) | data source |
| [azurerm_subnet.pep](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| [azurerm_subnet.sqlmi](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subnet) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |
| corepipeline_client_registry.client_data | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aad_admin_enable"></a> [aad\_admin\_enable](#input\_aad\_admin\_enable) | Enable use of AAD Admin for SQL Managed Instance. | `bool` | `false` | no |
| <a name="input_aad_admin_login"></a> [aad\_admin\_login](#input\_aad\_admin\_login) | Login name of the managed instance administrator. Can be any valid principal, <br>e.g., an AAD group. | `string` | n/a | yes |
| <a name="input_aad_admin_object_id"></a> [aad\_admin\_object\_id](#input\_aad\_admin\_object\_id) | Object ID (SID) of the managed instance administrator. | `string` | n/a | yes |
| <a name="input_aad_admin_tenant_id"></a> [aad\_admin\_tenant\_id](#input\_aad\_admin\_tenant\_id) | Tenant ID of the managed instance administrator. | `string` | n/a | yes |
| <a name="input_akv_user_object_ids"></a> [akv\_user\_object\_ids](#input\_akv\_user\_object\_ids) | A list of object ids that will be granted access to the Admin AKV so that<br>they can access the SQL Auth credentials. | `list(string)` | `[]` | no |
| <a name="input_app_code"></a> [app\_code](#input\_app\_code) | The App Code for SQL Managed Instance. | `string` | n/a | yes |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | The App Name for SQL Managed Instance. | `string` | n/a | yes |
| <a name="input_branch"></a> [branch](#input\_branch) | The VCS branch name (Optional) | `string` | `""` | no |
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | App Code data classfication. | `string` | n/a | yes |
| <a name="input_deployment_number"></a> [deployment\_number](#input\_deployment\_number) | Enables multiple deployments of the resource. deployment\_number <br>is used to ensure unique names when forming names of deployed resources. | `number` | `1` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The runtime environment where SQL Managed Instance will be deployed.<br>Possible values are \"dev\", \"qat\", \"uat\" or \"prod\". | `string` | `"dev"` | no |
| <a name="input_leaf_resources"></a> [leaf\_resources](#input\_leaf\_resources) | This module requires certain resources to be created outside of the module<br>and requires some address information.<br>In particular, it requires the VNET resource group, VNET, and two subnets<br>to be created. This is currently done by the FRM0-Shared/core-pipeline-Gient-networking component.<br>   - **network\_rg\_name** Name of the resource group containing the VNET<br>   - **network\_name** Name of the VNET<br>   - **sqlmi\_subnet\_cidr** CIDR block of the subnet used to contain the SQL MI hosts. This must be *at least* a /26 size<br>   - **pep\_subnet\_cidr** CIDR block of the subnet used to contain Private Endpoints. This should be a /28 size<br>See the README.md section on networking requirements for more information. | <pre>object({<br>    network_rg_name       = string<br>    network_name          = string<br>    pep_subnet_name       = string<br>    pep_subnet_cidr       = string<br>    sqlmi_subnet_name     = string<br>    sqlmi_subnet_cidr     = string<br>    sqlmi_subnet_nsg_name = string<br>  })</pre> | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The Azure location (region) where the SQL MI resource will be deployed. <br>If deploying a zone-redundant configuration, with no auto-failover groups in Canada, this <br>must be `canadacentral`. If deploying two instances *with* auto-failover groups in Canada, then the primary will aways be `canadacentral` and the secondary must be `canadaeast`. | `string` | `"canadacentral"` | no |
| <a name="input_portfolio"></a> [portfolio](#input\_portfolio) | The portfolio for the App Code. e.g., `ccoe` | `string` | `"ccoe"` | no |
| <a name="input_service_tier"></a> [service\_tier](#input\_service\_tier) | The Terraform service tier where SQL Managed Instance will be deployed.<br>Possible values are \"e\", \"n\", or \"p\"<br>> *This variable is likely to be deprecated* | `string` | `"n"` | no |
| <a name="input_sql_mi_user_assigned_identity"></a> [sql\_mi\_user\_assigned\_identity](#input\_sql\_mi\_user\_assigned\_identity) | User Assigned Managed Identity that will be assigned to the instance to become its primary<br>identity. This must have the necessary permissions for the instance to use AAD authentication. See the module's README.md for more information. | <pre>object({<br>    name                = string<br>    resource_group_name = string<br>  })</pre> | n/a | yes |
| <a name="input_sqlmi_admin_login"></a> [sqlmi\_admin\_login](#input\_sqlmi\_admin\_login) | Instance administrator login name. e.g., `dbadmin`. This is stored in <br>the SQL MI Admin Keyvault under the sqlmi-admin-login name. The associated password is auto-generated and stored in the same Keyvault under sqlmi-admin-login-password secret."<br><br>**WARNING** Changing the admin\_login forces a new SQL MI instance to be created and the existing<br>one to be **destroyed**. You have been warned. | `string` | `"dbadmin"` | no |
| <a name="input_sqlmi_admin_password"></a> [sqlmi\_admin\_password](#input\_sqlmi\_admin\_password) | Deprecated and ignored. This is now autogenerated. See sqlmi\_admin\_login variable for more information. | `string` | `"Ignored"` | no |
| <a name="input_sqlmi_license_type"></a> [sqlmi\_license\_type](#input\_sqlmi\_license\_type) | What type of license the Managed Instance will use. Valid values include can be PriceIncluded or BasePrice. | `string` | `"BasePrice"` | no |
| <a name="input_sqlmi_log_settings"></a> [sqlmi\_log\_settings](#input\_sqlmi\_log\_settings) | A list of valid diagnostic log categories and associated settings to enable for the instance.<br>See Logging and Monitoring in the README.md file for more information. | <pre>list(object({<br>    category          = string<br>    enabled           = bool<br>    retention_enabled = bool<br>    retention_days    = number<br>  }))</pre> | <pre>[<br>  {<br>    "category": "ResourceUsageStats",<br>    "enabled": true,<br>    "retention_days": 0,<br>    "retention_enabled": true<br>  }<br>]</pre> | no |
| <a name="input_sqlmi_maintenance_window"></a> [sqlmi\_maintenance\_window](#input\_sqlmi\_maintenance\_window) | One of the preset values that defines when the instance can undergo Azure-managed maintenance. <br>As of May 2022 the available values for Canada Central are:<br> - **SQL\_CanadaCentral\_MI\_1** 10:00 PM to 6:00 AM Eastern Standard Time, Monday to Thursday<br> - **SQL\_CanadaCentral\_MI\_2** 10:00 PM to 6:00 AM Eastern Standard Time, Friday to Sunday<br><br> and for Canada East:<br> - **SQL\_CanadaEast\_MI\_1** 10:00 PM to 6:00 AM Eastern Standard Time, Monday to Thursday<br> - **SQL\_CanadaEast\_MI\_2** 10:00 PM to 6:00 AM Eastern Standard Time, Friday to Sunday<br>See the Module README for more information on how to obtain these values. | `string` | `"SQL_CanadaCentral_MI_2"` | no |
| <a name="input_sqlmi_metric_settings"></a> [sqlmi\_metric\_settings](#input\_sqlmi\_metric\_settings) | A list of valid diagnostic metric categories and associated settings to enable for the instance.<br>See Logging and Monitoring in the README.md file for more information. | <pre>list(object({<br>    category          = string<br>    enabled           = bool<br>    retention_enabled = bool<br>    retention_days    = number<br>  }))</pre> | <pre>[<br>  {<br>    "category": "allMetrics",<br>    "enabled": true,<br>    "retention_days": 0,<br>    "retention_enabled": true<br>  }<br>]</pre> | no |
| <a name="input_sqlmi_name"></a> [sqlmi\_name](#input\_sqlmi\_name) | Name of the managed instance. e.g., "test-mi"<br> The server name can only be made up of lowercase letters 'a'-'z', the numbers 0-9 and the hyphen. The hyphen may not lead or trail in the server name. | `string` | n/a | yes |
| <a name="input_sqlmi_sku_name"></a> [sqlmi\_sku\_name](#input\_sqlmi\_sku\_name) | Specifies the SKU Name for the SQL Managed Instance. Valid values include GP\_Gen4, <br>GP\_Gen5, GP\_G8IM, GP\_G8IH, BC\_Gen4, BC\_Gen5, BC\_G8IM or BC\_G8IH. | `string` | `"GP_Gen5"` | no |
| <a name="input_sqlmi_storage_redundancy"></a> [sqlmi\_storage\_redundancy](#input\_sqlmi\_storage\_redundancy) | Specifies the storage account type used to store backups for this database. <br><br>**WARNING Changing this forces a new resource to be created.**<br>Possible values are "GRS", "LRS" and "ZRS" (Geo, Local and Zonal respectively). | `string` | `"ZRS"` | no |
| <a name="input_sqlmi_storage_size_gb"></a> [sqlmi\_storage\_size\_gb](#input\_sqlmi\_storage\_size\_gb) | Maximum storage space for the SQL Managed instance. This should be a <br>multiple of 32 (GB). | `string` | `"32"` | no |
| <a name="input_sqlmi_timezone"></a> [sqlmi\_timezone](#input\_sqlmi\_timezone) | The time zone of the instance. Applies to all databases.<br>Coordinated Universal Time (UTC) is the recommended and default time zone.<br>See the "Timezones" section of the module's README for more information, and for where to find the list of available time zones names.<br><br>**WARNING: A time zone of a managed instance can be set during instance creation only. Attempts to change the time zone on an existing instance will fail** | `string` | `"UTC"` | no |
| <a name="input_sqlmi_vcores"></a> [sqlmi\_vcores](#input\_sqlmi\_vcores) | Number of cores that should be assigned to the SQL Managed Instance. Values can be 8, <br>16, or 24 for Gen4 SKUs, or 8, 16, 24, 32, or 40 for Gen5 SKUs. | `string` | `"4"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for all resources. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_admin_key_vault_id"></a> [admin\_key\_vault\_id](#output\_admin\_key\_vault\_id) | The ID of the Admin Azure Key vault |
| <a name="output_admin_key_vault_ip_address"></a> [admin\_key\_vault\_ip\_address](#output\_admin\_key\_vault\_ip\_address) | The IP address of the Admin Key Vault's private endpoint |
| <a name="output_admin_key_vault_name"></a> [admin\_key\_vault\_name](#output\_admin\_key\_vault\_name) | The name of the Admin Azure Key vault |
| <a name="output_fqdn"></a> [fqdn](#output\_fqdn) | n/a |
| <a name="output_id"></a> [id](#output\_id) | n/a |
| <a name="output_identity_id"></a> [identity\_id](#output\_identity\_id) | n/a |
| <a name="output_log_analytics_workspace"></a> [log\_analytics\_workspace](#output\_log\_analytics\_workspace) | Log Analytics Workspace |
| <a name="output_storage_account"></a> [storage\_account](#output\_storage\_account) | Storage Account configuration. |
| <a name="output_storage_account_primary_blob_endpoint"></a> [storage\_account\_primary\_blob\_endpoint](#output\_storage\_account\_primary\_blob\_endpoint) | Storage primary blob endpoint. |
| <a name="output_storage_account_primary_web_endpoint"></a> [storage\_account\_primary\_web\_endpoint](#output\_storage\_account\_primary\_web\_endpoint) | Storage primary web endpoint. |
| <a name="output_tde_key_vault_id"></a> [tde\_key\_vault\_id](#output\_tde\_key\_vault\_id) | The ID of the TDE Azure Key vault |
| <a name="output_tde_key_vault_ip_address"></a> [tde\_key\_vault\_ip\_address](#output\_tde\_key\_vault\_ip\_address) | The IP address of the TDE Key Vault's private endpoint |
| <a name="output_tde_key_vault_name"></a> [tde\_key\_vault\_name](#output\_tde\_key\_vault\_name) | The name of the TDE Azure Key vault |
<!-- END_TF_DOCS -->

# 10. Diagnostics and Troubleshooting

This module is complex, with a substantial number of dependencies, interactions and dependant resources so it is not uncommon to encounter various problems during deployment. Here are some of the known ones:

## 10.1. Deployment Already Exists
To meet security and other requirements, the module relies on ARM templates to provision the resources such as the actual SQL MI instance. This can result in drift from Terraform's view of the world compared to reality. One symptom of this is a Terraform Apply error in the workspace that will look something like:
```
Error: A resource with the ID "/subscriptions/122da5fb-febd-4286-b5b4-83ad3ef75655/resourceGroups/
e-dev-ccoe-tf01-tim-sqlmi8-sqlmi-mi-rg-cac-1/providers/Microsoft.Resources/deployments/ \
sqlmi-deployment-zJwXf8A5" already exists - to be managed via Terraform this resource \
needs to be imported into the State. Please see the resource documentation for \
"azurerm_template_deployment" for more information.
```

The solution to this is to delete the deployment and start another run in the workspace. To delete the deployment, in the Azure portal, navigate to the resource group created by the module (`e-dev-ccoe-tf01-tim-sqlmi8-sqlmi-mi-rg-cac-1` in the example above, select 'Deployments', and delete the deployment in question (`sqlmi-deployment-zJwXf8A5` in this example.) You should also be able to do this from the Azure CLI. This is a non-destructive action so don't worry about it affecting any existing resources, including any partially or fully provisioned SQL MI instances. Once you've deleted the deployment, use the Terraform console to start a new plan and apply run.
