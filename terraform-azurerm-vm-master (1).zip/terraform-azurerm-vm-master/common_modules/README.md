# Azure Core Common feature

A Terraform modules composition (feature) which includes services needed for Core/Terraform Pipeline.

It includes:
* Azure Regions module
* Resource Group module with locking mechanism

## Requirements

* [PowerShell with Az module](https://docs.microsoft.com/en-us/powershell/azure/install-Az-ps?view=azps-3.6.1) >= 3.6 is mandatory and is used to configure IIS logs collect in Azure Monitor

## Using sub-modules

### Regions

See `regions` sub-module [README](modules/regions/README.md).


### Resource Group

See `resource_group` sub-module [README](./modules/resource_group/README.md).


### Tags

See `tags` sub-module [README](./modules/required_tags/README.md).

<!-- BEGIN_TF_DOCS -->
## Global versioning rule for Core/Terraform Azure modules


## Usage

See example [main.tf](./test/resources/main/main.tf) for the usage of common module

## Providers

| Name | Version |
|------|---------|
| azurerm | >= 2.90 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| regions | ./modules/regions | n/a |
| resource_group | ./modules/resource_group | n/a |

## Resources

n/a


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| default\_tags\_enabled | Option to enable or disable default tags | `bool` | `true` | no |
| environment | Environment name | `string` | n/a | yes |
| extra\_tags | Extra tags to add | `map(string)` | `{}` | no |
| location | Azure location. | `string` | n/a | yes |
| location\_short | Short string for Azure location. | `string` | n/a | yes |
| service_tier | Service Tier name | `string` | n/a | yes |
| app_code | App Code | `string` | n/a | yes |
| app_name | App Name | `string` | n/a | yes |
| tenant\_id | Tenant ID | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|

<!-- END_TF_DOCS -->
## Related documentation
