# Azure required tags module

Common Azure terraform module to create required tags for resources and resource groups.



<!-- BEGIN_TF_DOCS -->
## Usage

[How to use required_tags module](https://rbc-confluence.fg.rbc.com/display/AR/Core+Pipeline%3A+Azure+Tagging+Standards)
[How to create subtree for common module](https://rbc-confluence.fg.rbc.com/display/AR/Core+Pipeline+-+Subtree+creation+for+common+modules)


## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.5.0 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | 2.0.0 |


## Modules

No modules.


## Resources

| Name | Type |
|------|------|
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/data-sources/subscription) | data source |
| corepipeline_client_registry.client_info | data source |


## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 3.5.0 |
| <a name="requirement_corepipeline"></a> [corepipeline](#requirement\_corepipeline) | 2.0.0 |


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_code"></a> [app\_code](#input\_app\_code) | The App Code for RG. | `string` | `""` | no |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | The App Name for RG. | `string` | `""` | no |
| <a name="input_compliance"></a> [compliance](#input\_compliance) | RBC data compliance. | `string` | `"N/A"` | no |
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | RBC data classification. | `string` | `"internal"` | no |
| <a name="input_portfolio"></a> [portfolio](#input\_portfolio) | The RG portfolio. | `string` | `"ccoe"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_required_tags"></a> [required\_tags](#output\_required\_tags) | required tags value |
<!-- END_TF_DOCS -->