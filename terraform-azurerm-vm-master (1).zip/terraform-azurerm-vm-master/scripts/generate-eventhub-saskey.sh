#!/bin/bash

function error_exit() {
  echo "$1" 1>&2
  exit 1
}

function check_deps() {
  test -f $(which jq) || error_exit "jq command not detected in path, please install it"
  test -f $(which openssl) || error_exit "openssl command not detected in path, please install it"
}

function parse_input() {
  # jq reads from stdin so we don't have to set up any inputs, but let's validate the outputs
  eval "$(jq -r '@sh "export EVENTHUB_NAMESPACE=\(.eventhub_namespace_name) EVENTHUB_NAME=\(.eventhub_name) EVENTHUB_SAS_POLICY_NAME=\(.eventhub_authorization_rule_name) SHARED_ACCESS_KEY=\(.eventhub_key)"')"
  if [[ -z "${EVENTHUB_NAMESPACE}" ]]; then export EVENTHUB_NAMESPACE=none; fi
  if [[ -z "${EVENTHUB_NAME}" ]]; then export EVENTHUB_NAME=none; fi
  if [[ -z "${EVENTHUB_SAS_POLICY_NAME}" ]]; then export EVENTHUB_SAS_POLICY_NAME=none; fi
  if [[ -z "${SHARED_ACCESS_KEY}" ]]; then export SHARED_ACCESS_KEY=none; fi
}

function generate_sas_token() {
    local EVENTHUB_URI="${EVENTHUB_NAMESPACE}.servicebus.windows.net/${EVENTHUB_NAME}"
    local EXPIRY=${EXPIRY:=$((60 * 60 * 24 * 360))}

    local ENCODED_URI=$(echo -n $EVENTHUB_URI | jq -s -R -r @uri)
    local TTL=$(($(date +%s) + $EXPIRY))
    local UTF8_SIGNATURE=$(printf "%s\n%s" $ENCODED_URI $TTL | iconv -t utf8)

    local HASH=$(echo -n "$UTF8_SIGNATURE" | openssl sha256 -hmac $SHARED_ACCESS_KEY -binary | base64)
    local ENCODED_HASH=$(echo -n $HASH | jq -s -R -r @uri)
    unset EVENTHUB_SASKEY
    EVENTHUB_SASKEY="https://${EVENTHUB_NAMESPACE}.servicebus.windows.net/${EVENTHUB_NAME}?sr=$ENCODED_URI&sig=$ENCODED_HASH&se=$TTL&skn=$EVENTHUB_SAS_POLICY_NAME"
    jq -n --arg EVENTHUB_SASKEY "$EVENTHUB_SASKEY" '{"eventhub_saskey":$EVENTHUB_SASKEY}'
}

check_deps
parse_input
generate_sas_token
