package test

import (
	"fmt"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/gruntwork-io/terratest/modules/files"
	http_helper "github.com/gruntwork-io/terratest/modules/http-helper"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestModule(t *testing.T) {
	t.Parallel()

	testFolder, err := files.CopyTerraformFolderToTemp("./resources/main", t.Name())
	if err != nil {
		t.Fatal(err)
	}
	options := &terraform.Options{
		TerraformDir: testFolder,
		EnvVars: map[string]string{
			"TF_CLI_CONFIG_FILE":  "./terraform.tfrc",
			"PORTFOLIO":           os.Getenv("PORTFOLIO"),
			"APP_CODE":            os.Getenv("APP_CODE"),
			"APP_NAME":            os.Getenv("APP_NAME"),
			"BRANCH":              os.Getenv("BRANCH"),
			"SERVICE_TIER":        os.Getenv("SERVICE_TIER"),
			"ENVIRONMENT":         os.Getenv("ENVIRONMENT"),
			"API_HOSTNAME":        os.Getenv("API_HOSTNAME"),
			"ARM_TENANT_ID":       os.Getenv("ARM_TENANT_ID"),
			"ARM_SUBSCRIPTION_ID": os.Getenv("ARM_SUBSCRIPTION_ID"),
			"ARM_CLIENT_ID":       os.Getenv("ARM_CLIENT_ID"),
			"ARM_CLIENT_SECRET":   os.Getenv("ARM_CLIENT_SECRET"),
			"AZURE_TENANT_ID":     os.Getenv("ARM_TENANT_ID"),
			"AZURE_CLIENT_ID":     os.Getenv("ARM_CLIENT_ID"),
			"AZURE_CLIENT_SECRET": os.Getenv("ARM_CLIENT_SECRET"),
			"ONBOARD_AUTH_ID":     os.Getenv("ONBOARD_AUTH_ID"),
			"TF_LOG":              os.Getenv("TF_LOG"),
			"TF_CLI_ARGS":         os.Getenv("-plugin-dir=/home/jenkins2/.terraform.d/plugins"),
		},
		NoColor: true,
	}
	_mainOpts := terraform.WithDefaultRetryableErrors(t, options)
	print("\n\n\n\t***** Terraform PLAN Phase. *****\n\n\n")
	fmt.Printf("\n\n\nTF_LOG set as %v\n\n\n", os.Getenv("TF_LOG"))
	terraform.InitAndPlan(t, _mainOpts)

	runApplyOnly := os.Getenv("APPLY_ONLY")
	if len(runApplyOnly) != 0 && runApplyOnly == "true" {
		print("\n\n\t***** WARNING: Terraform Destroy phase is disabled. *****\n\n")
	} else {
		defer print("\n\n\n\t***** Terraform DESTROY Phase. *****\n\n\n")
		defer terraform.Destroy(t, _mainOpts)
	}
	print("\n\n\n\t***** Terraform APPLY Phase. *****\n\n\n")
	terraform.Apply(t, _mainOpts)

	print("\n\n\n\t***** Terraform APPLY Completed. *****\n\n\n")
	time.Sleep(120)

	// Collect output and run assertions.
	output := make(map[string]interface{})
	terraform.OutputStruct(t, options, "", &output)

	assert.NotNil(t, output)

	assert.NotEmpty(t, output["location"])
	assert.NotEmpty(t, output["location_short"])
	assert.NotEmpty(t, output["location_cli"])

	assert.NotEmpty(t, output["linux_vm_id"])
	assert.NotEmpty(t, output["linux_vm_private_ip"])
	assert.NotEmpty(t, output["linux_vm_identity"])
	assert.NotEmpty(t, output["linux_vm_tags"])

	LinuxVmPrivateIpAddress := terraform.Output(t, options, "linux_vm_private_ip")
	linuxUrl := fmt.Sprintf("http://%s", LinuxVmPrivateIpAddress)

	print("\n Verify Linux App endpoint: ", linuxUrl, "\n")
	http_helper.HttpGetWithRetryWithCustomValidation(t, linuxUrl, nil, 60, 6*time.Second, func(status int, content string) bool {
		return status == 200 &&
			strings.Contains(content, "HELLO WORLD!")
	})

	// Get the values of output variables for VM tags
	outputLinuxTags := terraform.Output(t, options, "linux_vm_tags")
	fmt.Println("output Tags:", outputLinuxTags)
	// Define expected tags value
	expectedLinuxTags := map[string]string{"Appcode": "frm0-shared", "AppName": "vm", "portfolio": "ccoe", "serviceTier": "ENG", "environment": "Dev", "DataClassification": "internal", "Compliance": "N/A", "test": "Maggie"}
	fmt.Println("expected Tags:", expectedLinuxTags)
	// Compare the output values with expected values
	assert.Equal(t, fmt.Sprint(expectedLinuxTags), outputLinuxTags, "Tags mismatch.")

	assert.NotEmpty(t, output["windows_vm_id"])
	assert.NotEmpty(t, output["windows_vm_private_ip"])
	assert.NotEmpty(t, output["windows_vm_identity"])
	assert.NotEmpty(t, output["windows_vm_tags"])

	vmPrivateIpAddress := terraform.Output(t, options, "windows_vm_private_ip")
	windowsUrl := fmt.Sprintf("http://%s", vmPrivateIpAddress)

	print("\n Verify Windows App endpoint: ", windowsUrl, "\n")
	http_helper.HttpGetWithRetryWithCustomValidation(t, windowsUrl, nil, 60, 6*time.Second, func(status int, content string) bool {
		return status == 200 &&
			strings.Contains(content, "Hello World!")
	})

	// Get the values of output variables for VM tags
	outputWindowsTags := terraform.Output(t, options, "windows_vm_tags")
	fmt.Println("output Tags:", outputWindowsTags)
	// Define expected tags value
	expectedWindowsTags := map[string]string{"Appcode": "frm0-shared", "AppName": "vm", "portfolio": "ccoe", "serviceTier": "ENG", "environment": "Dev", "DataClassification": "internal", "Compliance": "N/A", "test": "Maggie"}
	fmt.Println("expected Tags:", expectedWindowsTags)
	// Compare the output values with expected values
	assert.Equal(t, fmt.Sprint(expectedWindowsTags), outputWindowsTags, "Tags mismatch.")

}
