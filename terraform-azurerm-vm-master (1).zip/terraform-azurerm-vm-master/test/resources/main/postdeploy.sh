#!/bin/sh

mkdir -p httpdir

cd httpdir

echo 'HELLO WORLD!' > index.html

nohup python -m SimpleHTTPServer 80 </dev/null &>/dev/null &
