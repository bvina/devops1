<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 3.18.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm.dns_zone"></a> [azurerm.dns\_zone](#provider\_azurerm.dns\_zone) | 3.18.0 |
| <a name="provider_azurerm.eng_c1_dns_zone"></a> [azurerm.eng\_c1\_dns\_zone](#provider\_azurerm.eng\_c1\_dns\_zone) | 3.18.0 |
| <a name="provider_azurerm.nonp_c1_dns_zone"></a> [azurerm.nonp\_c1\_dns\_zone](#provider\_azurerm.nonp\_c1\_dns\_zone) | 3.18.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_private_dns_a_record.eng_dns_record](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/private_dns_a_record) | resource |
| [azurerm_private_dns_a_record.nonp_dns_record](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/private_dns_a_record) | resource |
| [azurerm_private_dns_a_record.prod_dns_record](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/private_dns_a_record) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_client_subscription_service_tier"></a> [client\_subscription\_service\_tier](#input\_client\_subscription\_service\_tier) | n/a | `string` | n/a | yes |
| <a name="input_dns_record_ip"></a> [dns\_record\_ip](#input\_dns\_record\_ip) | n/a | `string` | n/a | yes |
| <a name="input_dns_record_name"></a> [dns\_record\_name](#input\_dns\_record\_name) | n/a | `string` | n/a | yes |
| <a name="input_dns_zone_name"></a> [dns\_zone\_name](#input\_dns\_zone\_name) | n/a | `string` | n/a | yes |
| <a name="input_zone_resource_group_name"></a> [zone\_resource\_group\_name](#input\_zone\_resource\_group\_name) | n/a | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
