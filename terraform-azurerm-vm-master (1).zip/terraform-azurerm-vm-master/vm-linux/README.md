# Linux Virtual Machine Module

####  Logging Data Source Configuration
Linux Diagnostics agent collects File Logs content based on the defined data sources. 
The File log paths can be passed in as part of the Logging Export Configuration. Syslogs and audit logs are exported by default. However, if the user wishes to export additional Application logs they can be defined as follow: 

```
logging_export_config = {
    storage_account_name    = module.storage_account.storage_account_name
    storage_account_rg_name = module.storage_account.storage_rg_name
    data_sources        = [
      "/var/log/application.log"
    ]
  }
```
 
- Default security events that are captured by default are the following:
```
[
  "/var/log/messages",
  "/var/log/messages"
]
```

####  Log Export Verification
Verify logs in Splunk by running the following search:
    - `index=*azure* source=<subscription name> sourcetype="azure:vm"`
- or You can verify the logs are being captured by logging into the VM and checking the agent logs:
    - `tail -f /var/log/azure/Microsoft.Azure.Diagnostics.LinuxDiagnostic/extension.log`
    - `tail -f /var/log/waagent.log`
    - `tail -f /var/opt/microsoft/omsagent/LAD/log/omsagent.log`

#### Custom Script Extension
- The Custom Script is downloaded to `/var/lib/waagent/custom-script/download/0` on the VM
- Logs can be found in:
  - `/var/log/azure/custom-script/handler.log`
  - `/var/log/waagent.log`

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 3.18.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.18.0 |
| <a name="provider_tls"></a> [tls](#provider\_tls) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_secret.ssh_private_key](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.ssh_public_key](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/key_vault_secret) | resource |
| [azurerm_linux_virtual_machine.vm](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/linux_virtual_machine) | resource |
| [azurerm_virtual_machine_extension.logs](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.vm_postdeploy](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/virtual_machine_extension) | resource |
| [tls_private_key.ssh_key](https://registry.terraform.io/providers/hashicorp/tls/latest/docs/resources/private_key) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_computer_name"></a> [computer\_name](#input\_computer\_name) | n/a | `string` | n/a | yes |
| <a name="input_disk_encryption_set_id"></a> [disk\_encryption\_set\_id](#input\_disk\_encryption\_set\_id) | n/a | `string` | n/a | yes |
| <a name="input_keyvault_id"></a> [keyvault\_id](#input\_keyvault\_id) | n/a | `string` | n/a | yes |
| <a name="input_linux_vm_ssh_key_secret_names"></a> [linux\_vm\_ssh\_key\_secret\_names](#input\_linux\_vm\_ssh\_key\_secret\_names) | (Optional) Name of the secret to store SSH Key Pair. Used for Linux operating systems. | <pre>object(<br>    {<br>      public_key_secret_name  = string<br>      private_key_secret_name = string<br>  })</pre> | <pre>{<br>  "private_key_secret_name": "",<br>  "public_key_secret_name": ""<br>}</pre> | no |
| <a name="input_location"></a> [location](#input\_location) | The Azure region to deploy resources. e.g. canadacentral | `string` | n/a | yes |
| <a name="input_log_export"></a> [log\_export](#input\_log\_export) | (Optional) Exporting VM Logs configuration. file logs should be stored in /var/log/* directory. | <pre>object(<br>    {<br>      storage_account_name    = string<br>      storage_account_sas_key = string<br>      eventhub_sas_key        = string<br>      data_sources            = list(string)<br>  })</pre> | <pre>{<br>  "data_sources": [],<br>  "eventhub_sas_key": "",<br>  "storage_account_name": "",<br>  "storage_account_sas_key": ""<br>}</pre> | no |
| <a name="input_managed_identity"></a> [managed\_identity](#input\_managed\_identity) | Enable Managed identity. Type can be set to UserAssigned or SystemAssigned, UserAssigned. With UserAssigned identity, you must provide a list of MSI IDs. | <pre>object(<br>    {<br>      enabled      = bool<br>      type         = string<br>      identity_ids = list(string)<br>  })</pre> | <pre>{<br>  "enabled": false,<br>  "identity_ids": [],<br>  "type": "SystemAssigned"<br>}</pre> | no |
| <a name="input_network_interface_nic_id"></a> [network\_interface\_nic\_id](#input\_network\_interface\_nic\_id) | n/a | `string` | n/a | yes |
| <a name="input_os_disk_config"></a> [os\_disk\_config](#input\_os\_disk\_config) | VM OS Disk Configuration. https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_virtual_machine#os_disk | <pre>object(<br>    {<br>      caching              = string<br>      disk_size_gb         = string<br>      storage_account_type = string<br>  })</pre> | <pre>{<br>  "caching": "ReadWrite",<br>  "disk_size_gb": "32",<br>  "storage_account_type": "Standard_LRS"<br>}</pre> | no |
| <a name="input_pd_script"></a> [pd\_script](#input\_pd\_script) | n/a | `string` | `"post deploy script that runs as a custom script extension on the VM after deployment. postdeploy.sh"` | no |
| <a name="input_public_ssh_key_path"></a> [public\_ssh\_key\_path](#input\_public\_ssh\_key\_path) | (Optional) Local path to a public SSH key used for Linux VM Creation. If not provided, a new Key Pair is genearted and saved to keyvault. | `string` | `""` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | n/a | `string` | n/a | yes |
| <a name="input_source_image_id"></a> [source\_image\_id](#input\_source\_image\_id) | n/a | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for all resources. | `map(string)` | `{}` | no |
| <a name="input_vm_admin_username"></a> [vm\_admin\_username](#input\_vm\_admin\_username) | n/a | `string` | n/a | yes |
| <a name="input_vm_name"></a> [vm\_name](#input\_vm\_name) | The name of the Virtual Machine. | `string` | `"default"` | no |
| <a name="input_vm_size"></a> [vm\_size](#input\_vm\_size) | The SKU which should be used for the Virtual Machine. Default value is Standard\_B1s. Azure VM Sizes: https://docs.microsoft.com/en-us/azure/virtual-machines/sizes-general | `string` | `"Standard_B1s"` | no |
| <a name="input_zone"></a> [zone](#input\_zone) | Availability Zone | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_linux_identity"></a> [linux\_identity](#output\_linux\_identity) | Linux Virtual machine VM Managed Identity. |
| <a name="output_linux_vm_id"></a> [linux\_vm\_id](#output\_linux\_vm\_id) | Linux Virtual machine Resource ID. |
| <a name="output_linux_vm_private_ip"></a> [linux\_vm\_private\_ip](#output\_linux\_vm\_private\_ip) | Linux Virtual machine Private IP. |
<!-- END_TF_DOCS -->
