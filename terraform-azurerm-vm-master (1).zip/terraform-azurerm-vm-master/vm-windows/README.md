# Windows Virtual Machine Module

####  Logging Data Source Configuration
Windows Diagnostics agent collects windows Event Logs based on the defined data sources. 
The Windows VM Event Logs can be passed in as part of the Logging Export Configuration. Important Security logs are exported by default. However, if the user wishes to export additional Application logs they can be defined as follow: 

```
logging_export_config = {
    storage_account_name    = module.storage_account.storage_account_name
    storage_account_rg_name = module.storage_account.storage_rg_name
    data_sources        = [
      {
          "name": "Application!*[System[(Level=1 or Level=2 or Level=3)]]"
      }
    ]
  }
```
 
- Default security events that are captured by default are the following:
```
[
  {
    "name" : "System!*[System[(Level=1  or Level=2)]]"
  },
  {
    "name" : "Security!*[System[(Level=1  or Level=2)]]"
  }
]
```


####  Log Export Verification
Verify logs in Splunk by running the following search:
- index=*azure* source=e0042 sourcetype="azure:vm"| spath "records{}.category" | search "records{}.category"=WindowsEventLogsTable
Where `source` is the subscription name.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 3.18.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | n/a |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.18.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_secret.vm_password](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/key_vault_secret) | resource |
| [azurerm_storage_blob.app_data](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/storage_blob) | resource |
| [azurerm_storage_container.app](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/storage_container) | resource |
| [azurerm_virtual_machine_extension.vm](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.windows_logs](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/virtual_machine_extension) | resource |
| [azurerm_windows_virtual_machine.vm](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/resources/windows_virtual_machine) | resource |
| [random_password.admin_passowrd](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [archive_file.zip](https://registry.terraform.io/providers/hashicorp/archive/latest/docs/data-sources/file) | data source |
| [azurerm_key_vault_secret.existing_vm_password](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/data-sources/key_vault_secret) | data source |
| [azurerm_storage_account.app](https://registry.terraform.io/providers/hashicorp/azurerm/3.18.0/docs/data-sources/storage_account) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_computer_name"></a> [computer\_name](#input\_computer\_name) | n/a | `string` | n/a | yes |
| <a name="input_custom_script_extension_config"></a> [custom\_script\_extension\_config](#input\_custom\_script\_extension\_config) | Custom Script Extension configuration for running scripts on Windows VMs.<br>  storage\_account\_name: Storage Account name where the application files are stored in.<br>  storage\_account\_rg\_name: Storage Account Resource Group name where the application files are stored in.<br>  startup\_script\_name: Name of the Application Startup Powershell Script. The script will be downloaded onto the VM and will be run with powershell.exe.<br>  application\_packages\_dir\_name: Application packages directory name. the directory/folder must be at the root level of the client repository. | <pre>object(<br>    {<br>      storage_account_name          = string<br>      storage_account_rg_name       = string<br>      startup_script_name           = string<br>      application_packages_dir_name = string<br>    }<br>  )</pre> | `null` | no |
| <a name="input_disk_encryption_set_id"></a> [disk\_encryption\_set\_id](#input\_disk\_encryption\_set\_id) | n/a | `string` | n/a | yes |
| <a name="input_existing_windows_vm_password_secret_name"></a> [existing\_windows\_vm\_password\_secret\_name](#input\_existing\_windows\_vm\_password\_secret\_name) | (Optional) Name of an existing AKV secret for the password of the local administrator account of the Virtual Machine. <br>  If this value is passed, the module will look up the secret in the key Vault defined by keyvault variable and uses the value as the VM Passowrd.<br>  Used for Windows operating systems. | `string` | `""` | no |
| <a name="input_keyvault_id"></a> [keyvault\_id](#input\_keyvault\_id) | n/a | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The Azure region to deploy resources. e.g. canadacentral | `string` | n/a | yes |
| <a name="input_log_export"></a> [log\_export](#input\_log\_export) | (Optional) Exporting VM Logs configuration. file logs should be stored in /var/log/* directory. | <pre>object(<br>    {<br>      storage_account_name    = string<br>      storage_account_key     = string<br>      eventhub_name           = string<br>      namespace_name          = string<br>      eventhub_key            = string<br>      authorization_rule_name = string<br>      data_sources            =list(string)<br>  })</pre> | <pre>{<br>  "authorization_rule_name": "",<br>  "data_sources": [],<br>  "eventhub_key": "",<br>  "eventhub_name": "",<br>  "namespace_name": "",<br>  "storage_account_key": "",<br>  "storage_account_name": ""<br>}</pre> | no |
| <a name="input_managed_identity"></a> [managed\_identity](#input\_managed\_identity) | Enable Managed identity. Type can be set to UserAssigned or SystemAssigned, UserAssigned. With UserAssigned identity, you must provide a list of MSI IDs. | <pre>object(<br>    {<br>      enabled      = bool<br>      type         = string<br>      identity_ids = list(string)<br>  })</pre> | <pre>{<br>  "enabled": false,<br>  "identity_ids": [],<br>  "type": "SystemAssigned"<br>}</pre> | no |
| <a name="input_network_interface_nic_id"></a> [network\_interface\_nic\_id](#input\_network\_interface\_nic\_id) | n/a | `string` | n/a | yes |
| <a name="input_os_disk_config"></a> [os\_disk\_config](#input\_os\_disk\_config) | VM OS Disk Configuration. https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_virtual_machine#os_disk | <pre>object(<br>    {<br>      caching              = string<br>      disk_size_gb         = string<br>      storage_account_type = string<br>  })</pre> | <pre>{<br>  "caching": "ReadWrite",<br>  "disk_size_gb": "32",<br>  "storage_account_type": "Standard_LRS"<br>}</pre> | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | n/a | `string` | n/a | yes |
| <a name="input_source_image_id"></a> [source\_image\_id](#input\_source\_image\_id) | n/a | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for all resources. | `map(string)` | `{}` | no |
| <a name="input_vm_admin_username"></a> [vm\_admin\_username](#input\_vm\_admin\_username) | n/a | `string` | n/a | yes |
| <a name="input_vm_name"></a> [vm\_name](#input\_vm\_name) | The name of the Virtual Machine. | `string` | `"default"` | no |
| <a name="input_vm_size"></a> [vm\_size](#input\_vm\_size) | The SKU which should be used for the Virtual Machine. Default value is Standard\_B1s. Azure VM Sizes: https://docs.microsoft.com/en-us/azure/virtual-machines/sizes-general | `string` | `"Standard_B1s"` | no |
| <a name="input_windows_vm_password_secret_name"></a> [windows\_vm\_password\_secret\_name](#input\_windows\_vm\_password\_secret\_name) | (Optional) Name of the secret to store the password of the local administrator account of the Virtual Machine. Used for Windows operating systems. | `string` | `""` | no |
| <a name="input_zone"></a> [zone](#input\_zone) | Availability Zone | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_windows_identity"></a> [windows\_identity](#output\_windows\_identity) | Windows Virtual machine VM Managed Identity. |
| <a name="output_windows_vm_id"></a> [windows\_vm\_id](#output\_windows\_vm\_id) | Windows Virtual machine Resource ID. |
| <a name="output_windows_vm_private_ip"></a> [windows\_vm\_private\_ip](#output\_windows\_vm\_private\_ip) | Windows Virtual machine Private IP. |
<!-- END_TF_DOCS -->
