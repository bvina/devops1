# Virtual Machine consumable
Terraform module for creating Azure Virtual Machines with Windows or Linux operating systems.

## Usage Guide
For sample deployment refer to the [Terratest module](test/resources/main) that deploys a Virtual Machine using the terraform-azurerm-vm-account module.

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 3.5.0 |
| <a name="requirement_corepipeline"></a> [corepipeline](#requirement\_corepipeline) | 2.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | n/a |
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | n/a |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.5.0 |
| <a name="provider_corepipeline"></a> [corepipeline](#provider\_corepipeline) | 2.0.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |
| <a name="provider_template"></a> [template](#provider\_template) | n/a |
| <a name="provider_tls"></a> [tls](#provider\_tls) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_disk_encryption_set.main](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/disk_encryption_set) | resource |
| [azurerm_key_vault_access_policy.encryption](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_key.cmk](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/key_vault_key) | resource |
| [azurerm_key_vault_secret.ssh_private_key](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.ssh_public_key](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.vm_password](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/key_vault_secret) | resource |
| [azurerm_linux_virtual_machine.vm](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/linux_virtual_machine) | resource |
| [azurerm_network_interface.nic](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/network_interface) | resource |
| [azurerm_storage_blob.app_data](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/storage_blob) | resource |
| [azurerm_storage_container.app](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/storage_container) | resource |
| [azurerm_virtual_machine_extension.vm](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/virtual_machine_extension) | resource |
| [azurerm_windows_virtual_machine.vm](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/resources/windows_virtual_machine) | resource |
| [random_password.admin_passowrd](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [tls_private_key.ssh_key](https://registry.terraform.io/providers/hashicorp/tls/latest/docs/resources/private_key) | resource |
| [archive_file.zip](https://registry.terraform.io/providers/hashicorp/archive/latest/docs/data-sources/file) | data source |
| [azuread_client_config.current](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/client_config) | data source |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/data-sources/client_config) | data source |
| [azurerm_key_vault.keyvault](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/data-sources/key_vault) | data source |
| [azurerm_key_vault_secret.existing_vm_password](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/data-sources/key_vault_secret) | data source |
| [azurerm_resource_group.main](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/data-sources/resource_group) | data source |
| [azurerm_storage_account.app](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/data-sources/storage_account) | data source |
| [azurerm_subnet.vm](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/data-sources/subnet) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/3.5.0/docs/data-sources/subscription) | data source |
| corepipeline_client_registry.client_data | data source |
| [template_file.boot_command_script](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_code"></a> [app\_code](#input\_app\_code) | The App Code for storage account. | `string` | `""` | no |
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | The App Name for storage account. | `string` | `""` | no |
| <a name="input_boot_command"></a> [boot\_command](#input\_boot\_command) | Startup command. This command will run on Linux Virtual Machine startup. | `string` | `null` | no |
| <a name="input_branch"></a> [branch](#input\_branch) | The branch name (Optional). | `string` | `""` | no |
| <a name="input_computer_name"></a> [computer\_name](#input\_computer\_name) | (Optional) Specifies the Hostname which should be used for this Virtual Machine. If unspecified this defaults to the value for the name field. If the value of the name field is not a valid computer\_name, then you must specify computer\_name. Changing this forces a new resource to be created. | `string` | `""` | no |
| <a name="input_custom_script_extension_config"></a> [custom\_script\_extension\_config](#input\_custom\_script\_extension\_config) | Custom Script Extension configuration for running scripts on Windows VMs.<br>  storage\_account\_name: Storage Account name where the application files are stored in.<br>  storage\_account\_rg\_name: Storage Account Resource Group name where the application files are stored in.<br>  startup\_script\_name: Name of the Application Startup Powershell Script. The script will be downloaded onto the VM and will be run with powershell.exe.<br>  application\_packages\_dir\_name: Application packages directory name. the directory/folder must be at the root level of the client repository. | <pre>object(<br>    {<br>        storage_account_name          = string<br>        storage_account_rg_name       = string<br>        startup_script_name           = string<br>        application_packages_dir_name = string<br>    }<br>  )</pre> | `null` | no |
| <a name="input_data_classification"></a> [data\_classification](#input\_data\_classification) | App data classfication. | `string` | n/a | yes |
| <a name="input_deployment_number"></a> [deployment\_number](#input\_deployment\_number) | Deployment number. | `string` | `"1"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | The environment where storage account will be deployed. | `string` | `"dev"` | no |
| <a name="input_existing_windows_vm_password_secret_name"></a> [existing\_windows\_vm\_password\_secret\_name](#input\_existing\_windows\_vm\_password\_secret\_name) | (Optional) Name of an existing AKV secret for the password of the local administrator account of the Virtual Machine. <br>  If this value is passed, the module will look up the secret in the key Vault defined by keyvault variable and uses the value as the VM Passowrd.<br>  Used for Windows operating systems. | `string` | `""` | no |
| <a name="input_keyvault"></a> [keyvault](#input\_keyvault) | Client Keyvault information to be used for VM secrets and storing Customer-Managed-Key for VM Disk. | <pre>object(<br>    {<br>      name = string<br>      resource_group_name = string<br>    })</pre> | n/a | yes |
| <a name="input_linux_vm_ssh_key_secret_names"></a> [linux\_vm\_ssh\_key\_secret\_names](#input\_linux\_vm\_ssh\_key\_secret\_names) | (Optional) Name of the secret to store SSH Key Pair. Used for Linux operating systems. | <pre>object(<br>  {<br>      public_key_secret_name  = string<br>      private_key_secret_name = string<br>  })</pre> | <pre>{<br>  "private_key_secret_name": "",<br>  "public_key_secret_name": ""<br>}</pre> | no |
| <a name="input_location"></a> [location](#input\_location) | The Azure region to deploy resources. e.g. canadacentral | `string` | n/a | yes |
| <a name="input_managed_identity"></a> [managed\_identity](#input\_managed\_identity) | Enable Managed identity. Type can be set to UserAssigned or SystemAssigned, UserAssigned. With UserAssigned identity, you must provide a list of MSI IDs. | <pre>object(<br>    {<br>      enabled      = bool<br>      type         = string<br>      identity_ids = list(string)<br>    })</pre> | <pre>{<br>  "enabled": false,<br>  "identity_ids": [],<br>  "type": "SystemAssigned"<br>}</pre> | no |
| <a name="input_networking"></a> [networking](#input\_networking) | Client Network information to be used for VM interface. | <pre>object(<br>    {<br>      subnet_name = string<br>      virtual_network_name = string<br>      resource_group_name = string<br>    })</pre> | n/a | yes |
| <a name="input_os_disk_config"></a> [os\_disk\_config](#input\_os\_disk\_config) | VM OS Disk Configuration. https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_virtual_machine#os_disk | <pre>object(<br>    {<br>      caching              = string<br>      disk_size_gb         = string<br>      storage_account_type = string<br>    })</pre> | <pre>{<br>  "caching": "ReadWrite",<br>  "disk_size_gb": "32",<br>  "storage_account_type": "Standard_LRS"<br>}</pre> | no |
| <a name="input_portfolio"></a> [portfolio](#input\_portfolio) | The Application portfolio. | `string` | `"ccoe"` | no |
| <a name="input_public_ssh_key_path"></a> [public\_ssh\_key\_path](#input\_public\_ssh\_key\_path) | (Optional) Local path to a public SSH key used for Linux VM Creation. If not provided, a new Key Pair is genearted and saved to keyvault. | `string` | `""` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group. | `string` | n/a | yes |
| <a name="input_service_tier"></a> [service\_tier](#input\_service\_tier) | The service tier where storage account will be deployed. | `string` | `"n"` | no |
| <a name="input_soe_distribution"></a> [soe\_distribution](#input\_soe\_distribution) | The SOE image distribution. options are: "rhel\_7" "windows\_2012\_r2" | `string` | `"rhel_7"` | no |
| <a name="input_soe_image_version"></a> [soe\_image\_version](#input\_soe\_image\_version) | SOE Image Version from Shared Image Gallery | `string` | `"latest"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for all resources. | `map(string)` | `{}` | no |
| <a name="input_vm_admin_username"></a> [vm\_admin\_username](#input\_vm\_admin\_username) | The username of the local administrator used for the Virtual Machine. Length between 8 - 20. | `string` | `""` | no |
| <a name="input_vm_name"></a> [vm\_name](#input\_vm\_name) | The name of the Virtual Machine. | `string` | `"default"` | no |
| <a name="input_vm_size"></a> [vm\_size](#input\_vm\_size) | The SKU which should be used for the Virtual Machine. Default value is Standard\_B1s. Azure VM Sizes: https://docs.microsoft.com/en-us/azure/virtual-machines/sizes-general | `string` | `"Standard_B1s"` | no |
| <a name="input_windows_vm_password_secret_name"></a> [windows\_vm\_password\_secret\_name](#input\_windows\_vm\_password\_secret\_name) | (Optional) Name of the secret to store the password of the local administrator account of the Virtual Machine. Used for Windows operating systems. | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_identity"></a> [identity](#output\_identity) | Virtual machine VM Managed Identity. |
| <a name="output_vm_id"></a> [vm\_id](#output\_vm\_id) | Virtual machine Resource ID. |
| <a name="output_vm_private_ip"></a> [vm\_private\_ip](#output\_vm\_private\_ip) | Virtual machine Private IP. |
