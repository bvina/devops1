# Azure Managed PostgreSQL Flex Server

This module creates an [Azure PostgreSQL Flexible Server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server)
with [databases](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mysql_flexible_database) along with logging activated,
[firewall rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mysql_flexible_server_firewall_rule) and
[virtual network rules](https://www.terraform.io/docs/providers/azurerm/r/postgresql_virtual_network_rule.html).

<!-- BEGIN_TF_DOCS -->
## Global versioning rule for Core Pipeline Azure modules

| Module version | Terraform version | AzureRM version |
|----------------|-------------------|-----------------|
| >= 1.0.x       | 1.1.x             | >= 3.5.0        |
|                |                   |                 |


## Private access, VNet integration

You can deploy a flexible server into your Azure virtual network (VNet). Azure virtual networks provide private and secure network communication. Resources in a virtual network can communicate through private IP addresses that were assigned on this network.

This approach enables the following capabilities:

- Connect from Azure resources in the same virtual network to your flexible server by using private IP addresses.
- Use VPN or Azure ExpressRoute to connect from non-Azure resources to your flexible server.
- Ensure that the flexible server has no public endpoint that's accessible through the internet.


![](./docs/flexible-pg-vnet-diagram.png)

In the preceding diagram:

- Flexible servers are injected into subnet 10.0.1.0/24 of the VNet-1 virtual network.
- Applications that are deployed on different subnets within the same virtual network can access flexible servers directly.
- Applications that are deployed on a different virtual network (VNet-2) don't have direct access to flexible servers. You have to perform virtual network peering for a private DNS zone before they can access the flexible server.


### Network requirements:

**Delegated subnet.** A virtual network contains subnets (sub-networks). Subnets enable you to segment your virtual network into smaller address spaces. Azure resources are deployed into specific subnets within a virtual network.
Your flexible server must be in a subnet that's delegated. That is, only Azure Database for PostgreSQL - Flexible Server instances can use that subnet. No other Azure resource types can be in the delegated subnet. You delegate a subnet by assigning its delegation property as Microsoft.DBforPostgreSQL/flexibleServers. The smallest CIDR range you can specify for a subnet is /28, which provides fourteen IP addresses, however the first and last address in any network or subnet can't be assigned to any individual host. Azure reserves five IPs to be utilized internally by Azure networking, which include two IPs that cannot be assigned to host, mentioned above. This leaves you eleven available IP addresses for /28 CIDR range, whereas a single Flexible Server with High Availability features utilizes 4 addresses.

**Private DNS zone integration.** Azure private DNS zone integration allows you to resolve the private DNS within the current virtual network or any in-region peered virtual network where the private DNS zone is linked.


