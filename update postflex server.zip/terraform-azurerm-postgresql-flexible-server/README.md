# Azure Managed PostgreSQL Flex Server

This module creates an [Azure PostgreSQL Flexible Server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server)
with [databases](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mysql_flexible_database) along with logging activated,
[firewall rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mysql_flexible_server_firewall_rule) and
[virtual network rules](https://www.terraform.io/docs/providers/azurerm/r/postgresql_virtual_network_rule.html).

<!-- BEGIN_TF_DOCS -->
## Global versioning rule for Core Pipeline Azure modules

| Module version | Terraform version | AzureRM version |
|----------------|-------------------|-----------------|
| >= 1.0.x       | 1.1.x             | >= 3.5.0        |
|                |                   |                 |

