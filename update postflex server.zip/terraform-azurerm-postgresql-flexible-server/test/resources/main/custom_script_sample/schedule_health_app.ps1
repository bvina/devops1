$Now = Get-Date
$Trigger = New-ScheduledTaskTrigger -At $Now -Once
$Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "C:\custom_script_sample\health_web_app.ps1"
Register-ScheduledTask -TaskName "webapp" -Trigger $Trigger -User "NT AUTHORITY\SYSTEM" -Action $Action -Force -AsJob
# Allow some time to register the scheduled task before starting it.
Start-Sleep -Seconds 5
Start-ScheduledTask "webapp"
